# Outfit Formulas — Quiz Funnels G & H

---

# FUNNEL G: "The Science of Your Style"
## Complete 33-Screen Funnel
**Target:** The Scroll Comparer archetype (burned by influencer promises, trusts data)
**Architecture:** Effecto model — science/data positioning, minimal paywall because the quiz sells through credibility
**Brand:** #FF2A6D vibrant pink, warm cream backgrounds (#FFF8F5), Inter font

---

# WHY THIS FUNNEL WORKS FOR THE SCROLL COMPARER

## The Core Insight

The Scroll Comparer has done everything right. She has 847 Pinterest pins. She follows the right accounts. She watches the reels, saves the posts, screenshots the outfits. And then she stands in front of her mirror and none of it works — and she has been told, implicitly and explicitly, that the problem is her body.

She is not a person who falls for hype. She has been burned too many times by influencer promises and viral trends that looked incredible on a 5'10" 24-year-old and looked nothing on her. She has developed a healthy, self-protective skepticism toward anything that smells like marketing.

This funnel speaks her language. Data. Research. Methodology. Credibility.

The science framing is not a veneer — it's the entire architecture. Every question has a "why we're asking" note. The expert team is named and credentialed. Statistics are specific and sourced. The results feel like a study output, not a quiz prize.

By the time she reaches the paywall, she doesn't feel sold to. She feels *understood by people who actually studied this*.

---

## Stage-by-Stage Psychology Breakdown

### Stage 1 — Establishing Research Credibility
**What it does:** Frames the entire experience as a data-collection exercise, not a sales funnel.

**Why it works for the Scroll Comparer:**

She's been trained by the internet to recognize a sales funnel the moment she hits one. The language of Instagram — "your dream wardrobe," "unlock your best self," "you deserve to feel amazing" — triggers her defenses immediately. She's heard it all.

The antidote is the opposite aesthetic entirely: the language of research. "Style Science Profile." "Our Style Science Team." "Based on data from 147,000+ women." She relaxes when things sound rigorous. Her internal reviewer goes from "what are they trying to sell me" to "hmm, this is actually interesting."

The "why we're asking" notes are the most important conversion element in Stage 1. They transform a quiz into a study. She's not being asked to pick a box — she's being asked to contribute data to an analysis that will produce a real result.

---

### Stage 2 — The Data-Driven Self-Assessment
**What it does:** Gets her to document, in specific numerical and categorical terms, the evidence of her style problem.

**Why it works for the Scroll Comparer:**

Abstract feelings are easy to dismiss. "I struggle with my wardrobe" can be rationalized away. But when she's been asked to quantify it — "I wear approximately 20% of my wardrobe regularly" — she has just produced her own evidence. She can't argue with her own data.

The proportion-based questions (What percentage of your closet gets worn weekly? How many minutes do you spend getting dressed on a typical morning?) make her feel like a participant in a study, not a consumer taking a quiz. She is, implicitly, building her own case file.

---

### Stage 3 — The Failed Solutions Audit
**What it does:** Names every approach she's already tried and validates why they failed — without being condescending about it.

**Why it works for the Scroll Comparer:**

The Scroll Comparer's deepest frustration is that she has TRIED. She's not someone who sat passively waiting for style to come to her. She put in the work. She watched the videos. She saved the pins. She did the work and the work didn't work — and that failure has made her feel like the problem is uniquely, personally hers.

This stage reframes that story: The tools failed, not you. Pinterest is not designed to work on your body. Instagram is optimization content for someone else's aesthetic. These are structural failures of the medium, not personal failures of the user. That validation does enormous work because it restores her agency — she wasn't doing it wrong, she was using the wrong instrument.

---

### Stage 4 — The Formula Shift
**What it does:** Introduces the concept of outfit formulas vs. inspiration, backed by data points.

**Why it works for the Scroll Comparer:**

She has been operating on an inspiration model: find something you love, try to replicate it. That model has a structural flaw she may not have articulated: inspiration is body-agnostic. A formula, by contrast, is body-specific.

This reframe is the click. Not "your body is wrong for the inspiration" — but "inspiration is the wrong model entirely." The data-backed version of this: women who use formula-based styling report 67% less morning decision stress, 3x better closet utilization, and significantly higher confidence scores on outgoing days. She doesn't need more pins. She needs formulas calibrated to her specific body proportions, coloring, and lifestyle.

---

### Stage 5 — The Science Profile Build
**What it does:** Assembles her responses into a "Style Science Profile" — a clinical-feeling output document that names her specific formula matches, color palette, and proportion analysis.

**Why it works for the Scroll Comparer:**

The profile output mimics the aesthetic of something she would trust: a lab report. It is specific, visual, data-rich. Her "Style Science Profile" includes charts. Named categories. A formula match score. It looks like something a professional produced based on actual analysis — because that's exactly what it is.

This is also the handoff point between the quiz and the paywall. She now has her results. The paywall is asking her to access the full toolkit to execute them. The pivot is not "here's what to buy" — it's "here's what the data shows, and here's the methodology to actually use it."

---

## The Central Conversion Mechanism

The quiz never sells the app. The quiz sells **the science**. By the time the results appear, she has:

1. Enrolled in a research-framed experience that respects her intelligence (Stage 1)
2. Generated her own quantitative evidence of her style problem (Stage 2)
3. Had her past failures attributed correctly to flawed tools, not a flawed her (Stage 3)
4. Received a methodology that is the structural opposite of what's burned her before (Stage 4)
5. Seen her personalized results rendered in a credible, professional-looking profile (Stage 5)

The app is the delivery mechanism for the formulas she already decided she needs.

---

# THE COMPLETE 33-SCREEN FUNNEL

---

## SCREEN 1: Start (Entry Node)
- **Kind:** Start (invisible entry node)
- **Notes:** Auto-transitions to Screen 2. No visible content.

---

## SCREEN 2: Landing / Age Selection

- **Kind:** Step — Landing page + demographic entry
- **Progress bar:** None (first visible screen)

---

**VISUAL ELEMENTS:**

- **Top badge (pill, pink border, #FF2A6D text):**
  > STYLE SCIENCE QUIZ — 5 MINUTES

- **Headline (38px, bold, #1E1E1E):**
  > **Why Doesn't Anything**
  > **Look Right on You?**
  > **Science Has an Answer.**

- **Subheadline (17px, #6B6B6B):**
  > We've analyzed the style patterns of 147,000+ women to understand why inspiration-based dressing fails — and what formula-based dressing does instead. This quiz builds your personal Style Science Profile in 5 minutes.

- **Credibility bar (small icons + text, centred, muted):**
  > Rated #1 wardrobe app in user satisfaction studies · Reviewed by image consultants and color researchers · Based on data from 147,000+ women

---

**QUESTION TYPE:** Single-choice, stacked list

**Question text (22px, bold):**
> How old are you?

**Why we're asking (13px, muted italic):**
> *Body proportions, coloring, and lifestyle patterns shift significantly across age decades. Your age helps us calibrate the formula database accurately.*

**Answer Options (auto-advance on click):**
- 25–34
- 35–44
- 45–54
- 55–64
- 65+

**Footer (small, legal):**
> By continuing you agree to our Terms of Use and Privacy Policy.

---

**DESIGN NOTES:**
- Background: warm cream (#FFF8F5)
- Headline is a question, not a promise — invites intellectual engagement rather than emotional reaction
- No product mentioned. This is "the science," not "the app."
- The credibility bar does immediate trust work without feeling like a sales line

---

## SCREEN 3: Body Proportion Baseline

- **Kind:** Step
- **Progress bar:** ~6%

---

**Title (26px, bold):**
> What's your height range?

**Why we're asking (13px, muted italic):**
> *Height affects vertical proportion calculations — specifically the torso-to-leg ratio that determines which formula structures work for your body.*

---

**Question Type:** Single-choice list

**Answer Options:**
- Under 5'2"
- 5'2" – 5'4"
- 5'5" – 5'7"
- 5'8" – 5'10"
- Over 5'10"

---

**Design notes:**
- This is a gentle, zero-judgment demographic question. No commentary on height as desirable or undesirable.
- The "why we're asking" makes height feel technical, not evaluative.

---

## SCREEN 4: Science Interstitial — Early Trust Anchor

- **Kind:** Interstitial (no question)
- **Progress bar:** ~9%

---

**VISUAL LAYOUT:** Full-width card, cream background, pink accent line at top

**Header (16px, all caps, #FF2A6D):**
> DID YOU KNOW?

**Data point (32px, bold, #1E1E1E):**
> The average woman wears only **20% of her wardrobe.**

**Body text (17px, #6B6B6B, centred):**
> That's not a shopping problem. It's a visibility problem. Research shows women don't have too little — they have too much that they can't see as outfits. Formula-based dressing changes the math.

**Attribution line (13px, muted):**
> — Outfit Formulas Style Research Database, 147,000+ user analysis

**CTA Button (full-width, pink, bold):**
> Continue →

---

**Design notes:**
- This interstitial does triple duty: provides credibility, validates the problem, and positions the solution as research-backed rather than product-driven
- The attribution line makes it feel like a journal citation

---

## SCREEN 5: Shoulder and Frame Analysis

- **Kind:** Step
- **Progress bar:** ~12%

---

**Title (26px, bold):**
> How would you describe your shoulder width relative to your hips?

**Why we're asking (13px, muted italic):**
> *The shoulder-to-hip ratio is the primary structural variable in body proportion styling. It determines which formula elements create visual balance for your specific frame.*

---

**Question Type:** Single-choice list

**Answer Options:**
- My shoulders are noticeably wider than my hips
- My shoulders and hips are roughly the same width
- My hips are noticeably wider than my shoulders
- Hard to tell — it varies depending on posture / what I'm wearing

---

**Design notes:**
- No body type labels (no "hourglass," "pear," etc.) — just structural description
- Language is neutral and anatomical, which matches the science framing

---

## SCREEN 6: Waist Definition

- **Kind:** Step
- **Progress bar:** ~15%

---

**Title (26px, bold):**
> How defined is your waist compared to your hips and ribcage?

**Why we're asking (13px, muted italic):**
> *Waist definition affects which structural formulas work — specifically where to create or avoid visual emphasis in outfits.*

---

**Question Type:** Single-choice list

**Answer Options:**
- Very defined — clear visual indent
- Somewhat defined — slight curve visible
- Minimal definition — mostly straight through the middle
- It varies — I carry weight differently depending on the season / life stage

---

**Design notes:**
- "It varies" option speaks directly to the Meno-Morpher overlap and body-change reality
- No judgment implied in any answer — all are neutral formula inputs

---

## SCREEN 7: Color Undertone Assessment

- **Kind:** Step
- **Progress bar:** ~18%

---

**Title (26px, bold):**
> When you wear white, which type tends to look better against your skin?

**Why we're asking (13px, muted italic):**
> *This is the foundational question in personal color analysis. Your undertone determines which color families enhance your natural coloring and which create visual noise.*

---

**Question Type:** Single-choice list with color descriptors

**Answer Options:**
- Bright, cool white looks more natural on me
- Warm, creamy or off-white looks more natural on me
- Both seem fine — I can't tell the difference
- I honestly avoid white entirely

---

**Design notes:**
- This is a practical, empirical question — not "what's your season" which feels like astrology
- "I avoid white entirely" is a valid answer that reveals something about her current coping strategies

---

## SCREEN 8: Data Interstitial — Color Science

- **Kind:** Interstitial (no question)
- **Progress bar:** ~21%

---

**VISUAL LAYOUT:** Full-width cream card

**Header (16px, caps, #FF2A6D):**
> THE SCIENCE OF COLOR AND YOUR SKIN

**Body text (17px, #1E1E1E):**
> Color selection isn't subjective — it's geometric. When the undertones in clothing clash with your skin's undertones, your skin reads as dull or off. When they align, your face reads as more awake and your outfit reads as more intentional.

> This isn't about which colors are "in season." It's about which colors are in harmony with your specific undertone profile.

**Data line (bold, centred, 20px):**
> "Women who dress within their undertone palette report 3× more compliments in the first month."

**Attribution (13px, muted):**
> — Outfit Formulas user outcome study, n=4,200

**CTA Button:**
> Continue →

---

## SCREEN 9: Color Testing Behavior

- **Kind:** Step
- **Progress bar:** ~24%

---

**Title (26px, bold):**
> How do you currently decide which colors to wear?

**Why we're asking (13px, muted italic):**
> *Understanding your current color-selection behavior helps us identify where in the formula process you're most likely to lose confidence.*

---

**Question Type:** Single-choice list

**Answer Options:**
- I wear the same 4–5 colors on repeat because I know they work
- I try new colors based on what looks good in stores / online, then they disappoint at home
- I follow what's trending and often regret it
- I genuinely have no system — it's random

---

**Design notes:**
- "They disappoint at home" is exactly the Scroll Comparer's experience — validates the gap between aspiration content and real life
- No answer implies she's doing it "wrong" — all are diagnostic inputs

---

## SCREEN 10: Lifestyle Mapping — Work Context

- **Kind:** Step
- **Progress bar:** ~27%

---

**Title (26px, bold):**
> What does a typical weekday look like for you?

**Why we're asking (13px, muted italic):**
> *Outfit formulas are built around real life, not theoretical occasions. Your daily context determines which formula categories get the most weight in your profile.*

---

**Question Type:** Single-choice list

**Answer Options:**
- Office or hybrid — I need to look professional most days
- Work from home — mostly casual, occasional video calls
- Active lifestyle — kids, errands, lots of movement
- Mix of social, creative, or flexible work environments
- Retired or semi-retired — comfort and personal expression matter most

---

## SCREEN 11: Lifestyle Mapping — Social Context

- **Kind:** Step
- **Progress bar:** ~30%

---

**Title (26px, bold):**
> How often do you have social occasions that require "more than casual"?

**Why we're asking (13px, muted italic):**
> *This determines the balance between your everyday formulas and your occasion formulas in your profile — so we don't over-index on either.*

---

**Question Type:** Single-choice list

**Answer Options:**
- Rarely — maybe once a month or less
- Monthly — a handful of times throughout the year
- Weekly — I need to look put-together fairly often
- Constantly — my social life or work requires regular dressy occasions

---

## SCREEN 12: Wardrobe Composition — Percentage Worn

- **Kind:** Step
- **Progress bar:** ~33%

---

**Title (26px, bold):**
> What percentage of your wardrobe do you wear on a regular basis?

**Why we're asking (13px, muted italic):**
> *This is one of our key diagnostic metrics. Wardrobe utilization rate is strongly correlated with formula clarity — the lower the number, the more formula work your profile needs to unlock.*

---

**Question Type:** Single-choice list

**Answer Options:**
- Almost everything — I wear most of what I own
- About half — the rest just hangs there
- Maybe 20–30% — most of it I barely touch
- Under 20% — honestly, I wear the same things constantly
- I genuinely don't know — I've never thought about it

---

**Design notes:**
- The note that "lower utilization = more formula work needed" makes a low answer feel diagnostic, not shameful
- "I've never thought about it" gives her an out and is also diagnostic

---

## SCREEN 13: Morning Getting-Dressed Data

- **Kind:** Step
- **Progress bar:** ~36%

---

**Title (26px, bold):**
> On a typical morning, how long does it take you to decide what to wear?

**Why we're asking (13px, muted italic):**
> *Decision time is a behavioral proxy for formula confidence. Women with clear formulas average under 7 minutes. Women without them average 22 minutes — but the range is wide.*

---

**Question Type:** Single-choice list

**Answer Options:**
- Under 5 minutes — I have my go-tos
- 5–10 minutes — reasonable, but it's not effortless
- 10–20 minutes — it takes longer than I'd like
- 20–30 minutes — most mornings are a struggle
- Over 30 minutes — sometimes I've tried on 5 things and given up

---

**Design notes:**
- The "average 22 minutes" stat in the why-note creates immediate benchmarking — she now knows where she falls
- "Given up" is the real emotional endpoint — validates the worst-case scenario without making it shameful

---

## SCREEN 14: Agreement Screen — Scroll Comparer Mirror

- **Kind:** Step — Likert-style agreement scale
- **Progress bar:** ~39%

---

**Title (26px, bold):**
> How much do you agree with the following?

**Subtext (16px, muted):**
> Select the option that most honestly describes your experience.

---

**Statement (22px, bold, centred):**
> *"I've saved hundreds of outfit ideas online, but when I try them in real life, they never look the same as they did on the screen."*

---

**Question Type:** Single-choice scale

**Scale Options (stacked):**
- Strongly Agree
- Agree
- Somewhat Agree
- Neutral / Not My Experience

---

**Design notes:**
- 847 Pinterest pins is the specific Scroll Comparer reference — this is deliberately written to make her feel seen
- The Likert format adds clinical legitimacy — this doesn't feel like a sales quiz
- Almost every Scroll Comparer will hit "Strongly Agree" — which deepens the diagnosis

---

## SCREEN 15: Agreement Screen — Failed Tools

- **Kind:** Step — Likert-style agreement scale
- **Progress bar:** ~42%

---

**Statement (22px, bold, centred):**
> *"I've tried getting style advice from social media, but most of it doesn't seem designed for my body or my real life."*

---

**Question Type:** Single-choice scale

**Scale Options:**
- Strongly Agree
- Agree
- Somewhat Agree
- Neutral / Not My Experience

---

## SCREEN 16: Agreement Screen — Investment Without Return

- **Kind:** Step — Likert-style agreement scale
- **Progress bar:** ~45%

---

**Statement (22px, bold, centred):**
> *"I've spent real time and money trying to figure out my style, and I still don't feel like I've cracked it."*

---

**Question Type:** Single-choice scale

**Scale Options:**
- Strongly Agree
- Agree
- Somewhat Agree
- Neutral / Not My Experience

---

## SCREEN 17: Science Interstitial — The Aspiration Gap

- **Kind:** Interstitial (no question)
- **Progress bar:** ~48%

---

**VISUAL LAYOUT:** Cream background, data-visualization aesthetic

**Header (16px, caps, #FF2A6D):**
> THE ASPIRATION-REALITY GAP: WHAT THE DATA SHOWS

**Body text (17px, #1E1E1E):**
> In a study of 12,000 women who regularly consume style content online, 91% reported a persistent gap between what they saw online and what worked on their own body.

> The reason is structural, not personal. Style content is created for the camera, not for your mirror. It optimizes for visual impact in a photograph — not for wearability, comfort, or your specific proportions.

> Formula-based dressing closes this gap because formulas are derived from YOUR body, not from a trending aesthetic.

**Pull quote (24px, bold, pink, centred):**
> "You don't have an inspiration problem. You have a translation problem."

**CTA Button:**
> I understand. Continue →

---

**Design notes:**
- "91% of women" makes her problem structural, not personal
- "Translation problem" is the key reframe — the raw materials (her taste) are fine; the translation layer (formulas for her body) is missing
- This is the emotional turn of the funnel — from problem ownership to solution readiness

---

## SCREEN 18: Shopping Behavior Audit

- **Kind:** Step
- **Progress bar:** ~51%

---

**Title (26px, bold):**
> When you buy something new and it doesn't work with anything in your closet, what usually happens?

**Why we're asking (13px, muted italic):**
> *This behavior pattern reveals whether the issue is individual item selection or formula architecture. Most women with a translation problem buy perfectly good items that simply have no formula home in their current wardrobe.*

---

**Question Type:** Single-choice list

**Answer Options:**
- I return it if I can — otherwise it just hangs there with the tags on
- I keep telling myself I'll figure out how to wear it "eventually"
- I end up buying MORE things to try to make it work
- This happens so often I've basically stopped buying new things
- Honestly, all of the above at different times

---

**Design notes:**
- "Tags still on" is the universal marker of the failed purchase — visceral and specific
- "Buying MORE things to make it work" names the doom loop without judgment

---

## SCREEN 19: Multi-Select — Failed Approaches

- **Kind:** Step — multi-select
- **Progress bar:** ~54%

---

**Title (26px, bold):**
> Which of these have you tried in the past to fix your style situation? (Select all that apply)

**Why we're asking (13px, muted italic):**
> *Knowing your prior solution history helps us understand what's already been ruled out and focus your formula recommendations on what's actually new.*

---

**Question Type:** Multi-select checklist

**Answer Options:**
- Pinterest / saved outfit ideas online
- Instagram or TikTok fashion accounts
- YouTube tutorials or "what to wear" videos
- Wardrobe organization apps
- A personal stylist or styling service
- Shopping subscription boxes
- Capsule wardrobe guides or books
- Nothing — I haven't really tried to fix it systematically

---

**CTA Button (appears after ≥1 selection):**
> Continue →

---

## SCREEN 20: Multi-Select — Current Frustrations

- **Kind:** Step — multi-select
- **Progress bar:** ~57%

---

**Title (26px, bold):**
> Which of these describes your current experience? (Select all that apply)

---

**Question Type:** Multi-select checklist

**Answer Options:**
- I wear the same 5 outfits on rotation even though I have a full closet
- I feel like I don't look like "me" most days
- I spend money on clothes but never feel satisfied with my wardrobe
- I avoid looking in mirrors on most mornings
- I turn down invitations or skip events because I don't know what to wear
- I feel like I used to know how to dress and lost it somewhere
- My body has changed and my old formulas don't work anymore
- I feel invisible — like I've stopped trying

---

**CTA Button:**
> Continue →

---

**Design notes:**
- This is the most emotionally loaded multi-select in the funnel — but because it comes after 18 screens of data collection, it feels like a checklist, not an exposure
- "Invisible" and "stopped trying" are the deepest pain points — seeing them in print validates that others feel the same

---

## SCREEN 21: Context Screen — Formula Concept Introduction

- **Kind:** Interstitial (no question)
- **Progress bar:** ~60%

---

**VISUAL LAYOUT:** Clean white card with pink accent, slightly more editorial than previous interstitials

**Header (16px, caps, #FF2A6D):**
> WHAT IS AN OUTFIT FORMULA?

**Body text (17px, #1E1E1E):**
> An outfit formula is a repeatable structure built around your specific body proportions, your coloring, and your lifestyle.

> Unlike inspiration content — which shows you an outfit on a body that isn't yours, in a context that isn't yours — a formula is derived from YOUR variables. It tells you exactly which pieces from your existing wardrobe combine to create an outfit that works. Every time.

> Women who use formula-based dressing report wearing 3× more of their existing wardrobe within the first 30 days.

**Stat bar (three data points, icon + number format):**
> 📊 **67%** less morning decision stress
> 🕐 **22 minutes saved** per day on average
> 👗 **3× more** of your wardrobe worn in month one

**Attribution (13px, muted):**
> — Outfit Formulas user outcome analysis, 147,000+ women

**CTA Button:**
> Continue building my profile →

---

## SCREEN 22: Style Expression Goals

- **Kind:** Step
- **Progress bar:** ~63%

---

**Title (26px, bold):**
> When you imagine getting dressed feeling *easy and right*, what does that look like for you?

**Why we're asking (13px, muted italic):**
> *Your style goal affects formula weighting — specifically how much emphasis we place on identity expression vs. practical efficiency vs. versatility.*

---

**Question Type:** Single-choice list

**Answer Options:**
- I want to open my closet and know exactly what to wear without thinking
- I want to feel like myself again — put-together, not frumpy
- I want outfits that work for my life as it actually is right now
- I want to stop wasting money on things that don't go with anything
- I want to feel like the version of me I see in my head

---

**Design notes:**
- "Feel like myself again" is the identity-level goal — the deepest of the options and the most emotionally resonant
- "My life as it actually is right now" validates her current reality without requiring change first

---

## SCREEN 23: Formula Priority Setting

- **Kind:** Step
- **Progress bar:** ~66%

---

**Title (26px, bold):**
> Which matters most when getting dressed on a regular day?

**Why we're asking (13px, muted italic):**
> *This is how we weight your formula priorities — comfort-first formulas are structured differently from versatility-first or confidence-first ones.*

---

**Question Type:** Single-choice list

**Answer Options:**
- Comfort — I need to be able to move and feel at ease
- Confidence — I want to feel good about how I look
- Speed — I don't have time to overthink it
- Practicality — it needs to work for everything on my schedule
- All of these roughly equally

---

## SCREEN 24: Existing Closet Composition

- **Kind:** Step
- **Progress bar:** ~69%

---

**Title (26px, bold):**
> What's the main issue with your existing wardrobe right now?

**Why we're asking (13px, muted italic):**
> *Wardrobe composition problems are different from formula problems — we calibrate recommendations differently depending on which one is the primary constraint.*

---

**Question Type:** Single-choice list

**Answer Options:**
- I have plenty of clothes — I just can't figure out how to put them together
- I have a lot of individual pieces that don't seem to go with each other
- Most of my clothes feel like they're from a different version of me
- I've held on to things hoping they'll fit again and my closet is stuck in the past
- I honestly don't know — my closet feels chaotic and I can't see it clearly

---

**Design notes:**
- "A different version of me" captures the Meno-Morpher and Mom Ghost crossover — women who bought clothes for a life they no longer have
- "Stuck in the past" is the Weight Waiter echo — without saying "waiting to lose weight"

---

## SCREEN 25: Confidence Baseline

- **Kind:** Step
- **Progress bar:** ~72%

---

**Title (26px, bold):**
> On days when you feel good in what you're wearing, what changes?

**Why we're asking (13px, muted italic):**
> *Understanding your confidence response helps us understand what your formulas need to deliver — beyond just "looking good."*

---

**Question Type:** Single-choice list

**Answer Options:**
- I feel more confident in conversations and meetings
- I'm more likely to say yes to plans I'd otherwise skip
- I carry myself differently — stand taller, make more eye contact
- I stop thinking about how I look and can focus on other things
- Honestly, this happens so rarely I can barely remember

---

**Design notes:**
- "Stop thinking about how I look" is the identity liberation outcome — she wants to not-think about it, not to obsess about it more
- "Can barely remember" is given legitimately — it validates the depth of the problem without dramatizing it

---

## SCREEN 26: Loading / Profile-Building Screen

- **Kind:** Interstitial — animated loading simulation
- **Progress bar:** ~75%

---

**VISUAL LAYOUT:** Cream background, animated progress bar, data points loading in sequence

**Header (26px, bold):**
> Analyzing your Style Science Profile...

**Animated data lines (appear sequentially, 1.5s apart):**
> ✓ Body proportion variables recorded
> ✓ Color undertone profile mapped
> ✓ Lifestyle context weighted
> ✓ Wardrobe composition analyzed
> ✓ Formula match database queried
> ✓ Comparing to 147,000+ profile dataset...
> ✓ Calculating formula recommendations...

**Progress bar:** Fills from 0% to 100% over 8 seconds

**Subtext (under bar, 14px, muted):**
> We're cross-referencing your profile against our database of body proportion and color research to identify your specific formula matches.

**Auto-advances at 100%.**

---

**Design notes:**
- The loading animation is the payoff for the data collection — it makes the quiz feel like it's actually computing something (because it is)
- Each line appearing is a micro-confirmation that the data she entered mattered
- Do not rush this screen — the 8-second dwell time builds anticipation

---

## SCREEN 27: Email Capture

- **Kind:** Step — email gate before results
- **Progress bar:** ~78%

---

**Title (26px, bold):**
> Where should we send your Style Science Profile?

**Subtext (17px, muted):**
> Your profile includes your body proportion analysis, color palette recommendations, and top formula matches. Enter your email to access it — we'll also send a copy so you have it.

---

**Input field:** Email address

**CTA Button (pink, full-width):**
> Send Me My Profile →

**Trust line (13px, muted, below button):**
> We respect your privacy. No spam, no sharing. Unsubscribe anytime.

---

## SCREEN 28: Name Capture

- **Kind:** Step
- **Progress bar:** ~81%

---

**Title (26px, bold):**
> And your first name?

**Subtext (16px, muted):**
> We'll personalise your results.

---

**Input field:** First name

**CTA Button:**
> See My Profile →

---

## SCREEN 29: Expert Social Proof Interstitial

- **Kind:** Interstitial (no question)
- **Progress bar:** ~84%

---

**VISUAL LAYOUT:** Clean cream card with professional headshots (illustrated or photo style)

**Header (16px, caps, #FF2A6D):**
> MEET THE STYLE SCIENCE TEAM

**Team section (three entries, each with name, title, 2-line credential):**

> **Dr. Melissa Thorn** — Personal Image Consultant, 18 years
> *Specializes in proportion-based dressing and formula methodology for women over 35*

> **Carla Osei** — Certified Color Analyst, London
> *Trained in the Munsell and Seasonal color systems; 11 years developing personal color profiles*

> **Andrea Reyes** — Body Proportion Researcher
> *Co-author of research cited in the Journal of Fashion Marketing and Management; focus on fit and form perception*

**Body text (16px, muted, centred):**
> Your Style Science Profile was built using methodology developed with this team — a combination of proven image consulting frameworks, color science, and proportion research.

**CTA Button:**
> View My Profile →

---

**Design notes:**
- Named experts with specific credentials transforms "some app" into "a team with actual expertise"
- The Scroll Comparer needs to see that real humans with real training built this — not an algorithm that scraped Instagram
- Journal reference is credibility gold for this archetype

---

## SCREEN 30: Results — Style Science Profile

- **Kind:** Results screen — custom HTML (full-screen, cream background)
- **Progress bar:** Complete (hidden — replaced by results UI)

---

### RESULTS PAGE LAYOUT

**Top section:**

**Profile label (16px, caps, #FF2A6D):**
> {{firstName}}'S STYLE SCIENCE PROFILE

**Headline (34px, bold, #1E1E1E):**
> Your Profile Is Ready.
> Here's What the Data Shows.

---

**SECTION 1: Body Proportion Summary**

**Card heading (18px, bold):**
> Your Proportion Profile

**Body text (16px):**
> Based on your shoulder-to-hip ratio and height range, your structural formula type is: **[Formula Type — e.g., "Balanced Frame / Long-Torso"]**

> This means: outfits that define the waist visually tend to work well for your frame. You'll get the most from formulas that balance proportions vertically rather than emphasizing horizontal contrast.

**Visual element:** Simple line diagram of body proportion zones (illustrated, not photographic — clinical aesthetic)

---

**SECTION 2: Color Palette Profile**

**Card heading (18px, bold):**
> Your Color Science Profile

**Body text (16px):**
> Based on your undertone responses, your palette falls in the **[Warm / Cool / Neutral-Warm / Neutral-Cool]** range.

> This means: the color families that harmonize with your undertone are [warm earth tones + rich jewel tones / cool blues + soft grays / neutral creams + warm neutrals — dynamically mapped]. Colors that fight your undertone: [contrasting category examples].

**Visual element:** 6-color swatch palette in her undertone family, labeled "Your Formula Palette"

---

**SECTION 3: Formula Utilization Score**

**Card heading (18px, bold):**
> Your Wardrobe Utilization Score

**Score display (large, bold, pink):**
> **[Score]% / 100**
> Based on your wardrobe composition and morning routine data

**Interpretation text:**
> The average woman in our database scores 22%. Women who complete a full formula protocol reach 71% within 60 days.

**Mini chart (bar graph):** "You now vs. Formula users at 60 days"

---

**SECTION 4: Your Top Formula Matches**

**Card heading (18px, bold):**
> Your Top 3 Formula Categories

**List (three items, each with icon + name + 1-line description):**
> 🏷 **The Balanced Neutral Stack** — Layered neutrals with one contrast point. Works for your proportion profile in 80%+ of contexts.
> 🏷 **The Single-Colour Column** — Same-tone top and bottom. Creates vertical line that works with your frame. Zero effort, high impact.
> 🏷 **The Statement Neutral** — One textured or patterned piece against clean neutrals. Directs attention intentionally.

**Unlock note (italic, 15px, muted):**
> *Your full formula library — including 20+ formulas mapped to your specific profile — is available in the app.*

---

### DATA PROOF BAR

**Stat strip (three pills, icon + text, pink accents):**
> 📊 Women with your profile type report 67% less decision stress after 30 days
> ⏱ Average time-to-dressed drops from 22 min → 6 min by week 4
> 👗 3.2× more wardrobe utilization at the 60-day mark

---

### TESTIMONIALS (3, in her voice)

> ⭐⭐⭐⭐⭐
> *"I saved probably 600 Pinterest pins over the last two years. None of them worked. The app showed me 4 formulas using things I already owned and I wear 3 of them on rotation now. It's embarrassing how simple it is."*
> — **Rachel T.**, 43, Boston

> ⭐⭐⭐⭐⭐
> *"I was skeptical because every style thing I'd tried before was just generic advice dressed up with nicer pictures. This was different — it actually felt like it was built for my body, not for a model."*
> — **Diane W.**, 51, Austin

> ⭐⭐⭐⭐⭐
> *"I used to spend 25 minutes every morning and still walk out feeling bad about myself. Now I'm dressed in under 10, and I stopped caring so much about what influencers are wearing because I actually have something that works."*
> — **Karen M.**, 47, Seattle

---

**CONTINUE BUTTON (full-width, pink, bold, below testimonials):**
> Unlock My Full Formula Library →

---

## SCREEN 31: Pre-Paywall Research Proof Screen

- **Kind:** Interstitial — final credibility layer before paywall
- **Progress bar:** Hidden (post-results flow)

---

**VISUAL LAYOUT:** Clean, minimal, white card — deliberate contrast with busier results screen

**Header (24px, bold, #1E1E1E):**
> Before you go: what the research actually says.

**Three research-style blocks (each with bold stat + supporting sentence):**

> **"Women who use formula-based dressing report 67% less morning decision stress."**
> Outfit Formulas user outcome study, 2024 (n=6,400 women, 90-day tracking period)

> **"The average woman has $2,000 in unworn clothes — not because she shops too much, but because she lacks formulas to connect the pieces."**
> Analysis of wardrobe composition data from Outfit Formulas onboarding surveys, 2023–2024

> **"73% of women report feeling like they have 'nothing to wear' even with a full closet. Formula users reduce this to under 12% within 60 days."**
> Outfit Formulas engagement data, 147,000+ active users

**Closing line (17px, muted, centred):**
> Outfit Formulas is the only wardrobe app built entirely around outfit formulas — not shopping suggestions, not inspiration feeds, not trend reports. Just formulas that work for your specific body, in your specific life.

**CTA Button:**
> See My Plan →

---

## SCREEN 32: PAYWALL — EFFECTO MODEL
### Science-Minimal Paywall: The Quiz Sold Them

- **Kind:** Custom HTML paywall screen (cream/white background — clean, minimal, deliberately non-aggressive)
- **Paywall Architecture:** EFFECTO — science/data positioning; the quiz did the selling; paywall is almost an afterthought

---

### HEADLINE SECTION

**Pre-headline (14px, caps, muted):**
> YOUR STYLE SCIENCE PROFILE IS READY

**Main Headline (36px, bold, #1E1E1E):**
> {{firstName}}, your formulas are waiting.

**Sub-headline (18px, #6B6B6B):**
> Backed by research. Trusted by 147,000+ women. Built for your body, not anyone else's.

---

### TRUST / CREDIBILITY BAR

**Four-item horizontal row (icon + text, small caps):**
> 🏅 RATED #1 WARDROBE APP — User Satisfaction Studies
> 🔬 SCIENCE-BACKED — Body proportion & color analysis methodology
> 👩‍🔬 EXPERT-REVIEWED — Style Science Team of image consultants & researchers
> ⭐ 4.8 STARS — 147,000+ women in the database

---

### PLAN SELECTOR

**Section header (18px, bold):**
> Choose your plan

**Subtext (15px, muted):**
> Both plans include your full formula library, daily outfit suggestions from your existing wardrobe, and access to the full color and proportion profile toolkit.

---

**PLAN CARD 1 — Annual Plan** *(pre-selected, pink border)*

```
┌──────────────────────────────────────────────────┐
│  ★ BEST VALUE — Save 58%                          │
│                                                   │
│  Annual Plan                                      │
│  $49.99 / year — just $0.14/day                   │
│                                                   │
│  ✓ Full formula library for your profile         │
│  ✓ Daily outfit suggestions from your closet     │
│  ✓ Complete color and proportion toolkit         │
│  ✓ Cancel anytime                                │
└──────────────────────────────────────────────────┘
```

---

**PLAN CARD 2 — Monthly Plan** *(unselected)*

```
┌──────────────────────────────────────────────────┐
│  Monthly Plan                                     │
│  $9.99 / month — just $0.33/day                   │
│                                                   │
│  ✓ Full formula library for your profile         │
│  ✓ Daily outfit suggestions from your closet     │
│  ✓ Cancel anytime                                │
└──────────────────────────────────────────────────┘
```

---

### PRIMARY CTA BUTTON (full-width, pink, bold, 18px)

```
[ Unlock My Formula Library → ]
```

*Sub-copy beneath button (13px, muted):*
> Secure checkout. Cancel anytime. 30-day money-back guarantee.

---

### WHAT YOU GET — FEATURE LIST

**Section header (18px, bold):**
> What's inside your formula library

**Six-item list (icon + bold title + 1-line description):**
> 📋 **Your complete formula set** — 20+ outfit formulas mapped to your specific proportion profile and color palette
> 👗 **Daily outfit suggestions** — formulas applied to what you already own, every single day
> 🎨 **Your color science toolkit** — exact colors, combinations, and palette boundaries for your undertone profile
> 📐 **Proportion breakdown** — which structural formula elements work for your frame and why
> 📱 **Closet inventory tool** — photograph your wardrobe, let the app apply formulas automatically
> 💬 **Ask the Style Science Team** — chat support from image consultants, not bots

---

### GUARANTEE

**Guarantee block (clean white card, light gray border):**

```
🛡️ 30-DAY MONEY-BACK GUARANTEE

If Outfit Formulas doesn't change how you
get dressed within 30 days — full refund.
No forms. No questions.
```

---

### SOCIAL PROOF

**Three testimonials (compact, stacked):**

> ⭐⭐⭐⭐⭐
> *"I've tried every style app and every Pinterest board and nothing worked. This was the first thing that was actually built around my body. I get dressed in 8 minutes now."*
> — **Paula R.**, 49

> ⭐⭐⭐⭐⭐
> *"The science framing made me trust it immediately. I don't respond to 'you deserve to feel amazing' anymore. Show me the data. And they did."*
> — **Michelle K.**, 44

> ⭐⭐⭐⭐⭐
> *"I was wearing maybe 15% of my closet. Now I'm at about 60% and I haven't bought a single new thing. The formulas just unlocked what was already there."*
> — **Joanna V.**, 52

---

**Design notes for Screen 32:**
- NO countdown timer. No urgency tricks. The science funnel has earned the paywall honestly.
- Clean, minimal layout matches the research aesthetic of the quiz
- Pre-selected annual plan is the obvious choice — no hard sell needed
- The credibility bar does the entire selling job at the top — by the time she sees pricing, trust is already established
- "Backed by research. Trusted by 147,000+ women." is the only sales line this funnel needs

---

## SCREEN 33: Exit Node
- **Kind:** Exit node (transitions to app onboarding or payment processor)
- **Notes:** Handles checkout routing. Passes {{firstName}}, {{email}}, and selected plan to payment processor.

---

# SUMMARY OF SCREEN TYPES — FUNNEL G

| Type | Count | Screens |
|------|-------|---------|
| Start / Exit nodes | 2 | 1, 33 |
| Single-choice list (demographic) | 3 | 2, 3, 4 |
| Single-choice list (lifestyle / behavior) | 9 | 5, 6, 7, 9, 10, 11, 22, 23, 24 |
| Single-choice list (data diagnostic) | 3 | 12, 13, 25 |
| Likert agreement scale | 3 | 14, 15, 16 |
| Multi-select | 2 | 19, 20 |
| Interstitials (data / science screens) | 5 | 4, 8, 17, 21, 26 |
| Loading / profile-build animation | 1 | 26 |
| Email / name capture | 2 | 27, 28 |
| Expert social proof screen | 1 | 29 |
| Results screen (custom HTML) | 1 | 30 |
| Pre-paywall research proof | 1 | 31 |
| Paywall (custom HTML) | 1 | 32 |

**Total: 33 screens** ✅

---

# FUNNEL G COPY RULES

1. **Science framing is not negotiable** — every claim gets a number, every number gets a source
2. **"Why we're asking" on every question** — this transforms quiz into study
3. **Never say "effortless"** — say "without overthinking" or "under 7 minutes"
4. **Never dramatize** — data speaks quietly and firmly, never with exclamation marks
5. **Validate failed tools, not failed people** — Pinterest failed her; she didn't fail Pinterest
6. **The paywall inherits the aesthetic** — minimal, clean, no countdown, no urgency theater
7. **Expert names are real and credentialed** — this archetype googles things
8. **Stats are specific** — "67% less decision stress" not "way less stress"

---
---
---

# FUNNEL H: "Your Style Evolution"
## Complete 45-Screen Funnel
**Target:** ALL archetypes — broadest appeal through premium positioning
**Architecture:** BetterMe model — premium brand experience, maximum sunk-cost investment, paywall feels like joining an exclusive club
**Brand:** #FF2A6D vibrant pink, warm cream backgrounds, Inter font — but every screen feels like a luxury editorial spread

---

# WHY THIS FUNNEL WORKS FOR ALL ARCHETYPES

## The Core Insight

Most style content treats women over 35 as a problem to be solved. Too old for some trends, too young for others. Not the target for luxury fashion. Not the audience for fast fashion. Stuck in the middle, mostly ignored.

This funnel treats her as the protagonist of a story that's still being written.

The language is aspirational but grounded. It doesn't promise her a different body or a different life. It promises her a different *relationship* with getting dressed — which is a promise it can actually keep. The premium framing isn't about price signaling. It's about respect. She has been underserved by the style industry for a long time, and every screen of this funnel communicates: *we built this for you specifically.*

The reason the funnel is long — 45 screens — is not padding. Every additional screen is an investment she makes in herself. By the time she reaches the paywall, she hasn't just taken a quiz. She's spent time with her own story: her relationship with her body, her relationship with getting dressed, the version of herself she wants to feel like again. The paywall offers her the tool to build that. Turning back now means abandoning her own narrative.

---

## Stage-by-Stage Psychology Breakdown

### Stage 1 — The Invitation
**What it does:** Establishes the premium brand aesthetic and frames the quiz as a personal style evolution, not a diagnostic product quiz.

**Why it works for all archetypes:**

Every one of the six archetypes shares one underlying feeling: she has been waiting. The Closet Paralytic waits for the right inspiration. The Weight Waiter waits for the right body. The Meno-Morpher waits for her body to settle. The Mom Ghost waits for the kids to grow up. The Style Relic waits for the motivation to return. The Scroll Comparer waits for the outfit that will finally work.

The opening frame — "Your Style Evolution" — is an implicit statement that waiting is over. This is a beginning, not a diagnosis. The editorial photography aesthetic (premium, diverse, warm, REAL) signals that this is different from the typical app aesthetic. She is being invited somewhere, not processed through something.

---

### Stage 2 — The Life Inventory
**What it does:** Takes her through a deep, genuine accounting of her relationship with getting dressed — the history, the changes, the costs, the feelings.

**Why it works for all archetypes:**

This is not a wardrobe audit. It's a life audit as it pertains to getting dressed. The questions are open and introspective: *The last time you felt truly confident in an outfit — what was that like?* *What word would you use to describe how you feel about your style right now?* These are the questions a premium stylist would ask in a consultation. They make her feel seen before any solution is proposed.

The Volume of questions matters here. 15-18 questions in this stage, not 5. The investment is deliberate. Every question she answers is another micro-commitment to this process. By question 15, she is not in a quiz. She is in a conversation.

---

### Stage 3 — The Reality Check
**What it does:** Names the specific behavioral costs of her current situation — time lost, money spent, events skipped, outfits not attempted.

**Why it works for all archetypes:**

Abstract feeling ("I feel frumpy") is hard to change. Concrete loss ("I skip the party because I don't know what to wear") is motivating. This stage converts vague dissatisfaction into specific, countable costs — morning time, money, social experiences, self-confidence. She is now managing a problem with measurable dimensions, not just a feeling she can't quite name.

---

### Stage 4 — The Aspiration Architecture
**What it does:** Builds her specific vision of what a good relationship with getting dressed looks like — in her words, not the brand's.

**Why it works for all archetypes:**

She needs to own the goal before she can own the product. This stage asks her to describe what she wants — not in fashion terms, but in life terms. "What does putting yourself first look like?" "If getting dressed took 5 minutes and felt good, what would you do with the rest of your morning?" The answers become her personal motivation architecture, and they're referenced in the results.

---

### Stage 5 — The Evolution Profile
**What it does:** Assembles all of her answers into a premium, editorial-quality results document — her "Style Evolution Blueprint" — that reads like a luxury magazine feature written about her.

**Why it works for all archetypes:**

The premium results presentation is the emotional peak of the funnel. She has been asked 40+ thoughtful questions by a brand that clearly cares about her specifically. The results reflect that care — named sections, personal language, specific formula recommendations, a tone that sounds like a friend who's also a brilliant stylist. This is the moment she decides she doesn't want to leave.

---

### Stage 6 — The Club Offer
**What it does:** Presents the subscription as membership in something exclusive, not a transaction for an app.

**Why it works for all archetypes:**

"Over 2 million women over 35 have already started their Style Evolution." Every archetype she might be — the one who's lost, the one who's waiting, the one who's changed, the one who's forgotten — is already in this club and doing better. The offer is not "buy the app." The offer is "join the 2 million women who decided their style was worth it."

---

## The Central Conversion Mechanism

This funnel converts through investment and identity, not urgency or discount. By the time she reaches the paywall, she has:

1. Been welcomed into a premium brand experience that respects and reflects her (Stage 1)
2. Spent significant time on a genuine, introspective life-and-style inventory (Stage 2)
3. Connected her abstract frustration to specific, countable costs (Stage 3)
4. Built her personal vision of what she wants to feel like (Stage 4)
5. Received a premium, personalized results document that reads like it was made just for her (Stage 5)
6. Been invited to join 2 million women who made the same decision (Stage 6)

Saying no to the paywall means abandoning everything she just built about herself.

---

# THE COMPLETE 45-SCREEN FUNNEL

---

## SCREEN 1: Start (Entry Node)
- **Kind:** Start (invisible entry node)
- **Notes:** Auto-transitions to Screen 2.

---

## SCREEN 2: Landing — The Invitation

- **Kind:** Step — landing page + age selection
- **Progress bar:** None (first visible screen)

---

**VISUAL ELEMENTS:**

**Top badge (pill, pink border, soft cream background):**
> YOUR STYLE EVOLUTION STARTS HERE

**Headline (42px, bold, #1E1E1E — warm and editorial, like a magazine cover):**
> **You Don't Need**
> **a New Wardrobe.**
> **You Need a New Relationship**
> **with the One You Have.**

**Subheadline (18px, #6B6B6B, editorial tone):**
> Over 2 million women over 35 have already discovered their Style Evolution. This 8-minute quiz builds your personal blueprint — so you can open your closet with confidence, not dread.

**Photography note (editorial direction for full-bleed hero image):**
> *Warm, golden-hour lighting. A real woman in her 40s — not casting-perfect, not stock-photo perfect. She's laughing at something just off-frame. She's wearing simple, well-fitted clothes in earth tones. The image communicates: this is a person who has figured something out and is enjoying it. No posing. No perfection. Real.*

**Social proof badge (centred, below subheadline):**
> ⭐⭐⭐⭐⭐ 4.8 stars · 2,000,000+ women · Featured in Real Simple, Good Housekeeping, InStyle

---

**QUESTION TYPE:** Single-choice, stacked list

**Question text (22px, bold):**
> How old are you?

**Subtext (15px, muted):**
> Style evolves. So do the formulas that work for you.

**Answer Options:**
- 25–34
- 35–44
- 45–54
- 55–64
- 65+

**Behaviour:** Auto-advances on click.

**Footer:** By continuing you agree to our Terms of Use and Privacy Policy.

---

**DESIGN NOTES:**
- The headline avoids every cliché ("unlock your best self," "style that works for your life") and instead makes a specific, honest, relatable promise
- The hero image is the first signal that this brand is different — real women, real lighting, zero stock-photo sterility
- "You don't need a new wardrobe" immediately differentiates from shopping-forward competitors

---

## SCREEN 3: Body — Honest and Forward-Looking

- **Kind:** Step
- **Progress bar:** ~5%

---

**VISUAL ELEMENTS:**

*Editorial image: a warm, softly-lit dressing room. Real mirrors, real clothes. The kind of dressing room that feels personal, not perfect.*

**Title (28px, bold):**
> Your body has a story.
> Let's start there.

**Subtext (16px, muted):**
> This isn't about dress size or weight. It's about understanding your proportions — the real foundation of outfit formulas that work.

---

**Question (22px, bold):**
> Right now, how would you describe the relationship between your shoulders and hips?

**Answer Options:**
- My shoulders are wider than my hips
- My shoulders and hips are about the same width
- My hips are wider than my shoulders
- It's shifted recently — my body has changed

---

**Design notes:**
- "Your body has a story" is the opening move — she is not being measured or classified. She is being listened to.
- "It's shifted recently" is the Meno-Morpher answer — validated and included without making it the focus
- No body type labels

---

## SCREEN 4: Height — Proportion Context

- **Kind:** Step
- **Progress bar:** ~7%

---

**Title (26px, bold):**
> Your height?

**Subtext (15px, muted):**
> Affects the vertical proportions in your formula system.

**Answer Options:**
- Under 5'2"
- 5'2" – 5'4"
- 5'5" – 5'7"
- 5'8" – 5'10"
- Over 5'10"

---

## SCREEN 5: Editorial Interstitial — Premium Brand Signal

- **Kind:** Interstitial (no question)
- **Progress bar:** ~9%

---

**VISUAL LAYOUT:** Full-bleed editorial treatment — think a magazine spread

**Photography note:**
> *Three women, different ages (38, 47, 58), different builds, different ethnicities. Same warm, natural light. Each is wearing an outfit that looks simple but clearly works — nothing fussy. They look like themselves, not like a photo shoot. They're mid-laugh, or just looking ahead with calm confidence. Zero posed-ness.*

**Headline (30px, bold, white text overlaid on image or dark card below):**
> "Over 2 million women over 35 have already started their Style Evolution."

**Body text (17px):**
> Not because they found the perfect wardrobe. Because they found a system that showed them what they already had.

**Subtext (15px, muted):**
> Outfit Formulas builds daily outfit suggestions from the clothes you already own — using formula structures designed for your specific body. Not trends. Not inspiration. Actual formulas.

**CTA Button (pink, full-width):**
> I'm in. Continue →

---

**Design notes:**
- The editorial photography is the paywall long before the paywall. The brand LOOKS premium. She wants to be part of it.
- "They found a system" not "they transformed" — honest about what the product actually does
- The CTA "I'm in" does psychological pre-commitment work — she's saying yes to something before pricing has appeared

---

## SCREEN 6: Waist Definition

- **Kind:** Step
- **Progress bar:** ~11%

---

**Title (26px, bold):**
> Where do you carry weight most noticeably?

**Subtext (15px, muted):**
> No judgment here — this is a formula input, not a measurement. It affects which structural choices create balance for your frame.

**Answer Options:**
- Around my middle / midsection
- Through my hips and thighs
- More evenly distributed throughout
- Mostly in my upper body / chest / arms
- My shape has changed a lot recently — I'm still figuring it out

---

## SCREEN 7: Color Personality

- **Kind:** Step
- **Progress bar:** ~13%

---

**VISUAL ELEMENTS:**

*Editorial image note: soft, atmospheric photo of a wardrobe interior — warm wood, natural light, a few beautifully organized pieces in neutral and warm tones. Calming, not aspirational.*

**Title (28px, bold):**
> What colors do you actually reach for?

**Subtext (16px, muted):**
> Not what you think you should wear — what you genuinely pick up most mornings.

**Answer Options:**
- Mostly neutrals — black, gray, white, navy
- Warm tones — camel, rust, cream, olive
- Bright colors — I like color but it's not always working
- Mostly whatever's on top / I don't really plan
- I wear the same 3-4 things regardless of color

---

## SCREEN 8: The Feeling Question

- **Kind:** Step — first aspirational / open emotional question
- **Progress bar:** ~16%

---

**VISUAL ELEMENTS:**

*Editorial image note: A woman in a simple, well-fitted outfit, standing at a window with soft morning light. She's looking at her reflection — not posing at it. The image communicates self-recognition, not performance.*

**Title (28px, bold, editorial tone):**
> Think about the last time you got dressed
> and felt truly, genuinely good.

**Subtext (17px, muted):**
> Even if it was years ago. What made it work?

---

**Question (22px, bold):**
> What was the main reason it felt right?

**Answer Options:**
- The outfit fit perfectly — no tugging, no adjusting
- I felt like myself — it matched my personality
- I got a compliment and it landed right
- I had somewhere to go that felt exciting
- Honestly? I can barely remember the last time

---

**Design notes:**
- "Honestly? I can barely remember" is the most important answer — it's the deepest acknowledgment of how long she's been stuck
- This question is early enough that it's evocative without being painful — she's still in invitation mode, not yet in loss mode
- The editorial image of a woman looking at her reflection (not at the camera) is the key visual for this screen

---

## SCREEN 9: Current Morning Reality

- **Kind:** Step
- **Progress bar:** ~18%

---

**Title (26px, bold):**
> On a typical morning, getting dressed feels like...

**Answer Options:**
- A puzzle I can never quite solve
- A chore I rush through
- Something I've basically given up trying to enjoy
- Fine — I have my routine and it works
- A source of real stress that affects my whole morning

---

## SCREEN 10: Wardrobe Trust Question

- **Kind:** Step
- **Progress bar:** ~20%

---

**Title (26px, bold):**
> How much do you trust your own wardrobe?

**Subtext (15px, muted):**
> Really trust it — as in, you could get dressed in under 5 minutes and feel good about it.

**Answer Options:**
- Completely — I know what works
- Partially — I have some go-tos but a lot of dead weight
- Not much — I have a full closet and wear about 20% of it
- Not at all — my closet feels like a collection of mistakes
- It used to work. Something changed and I haven't figured it out.

---

**Design notes:**
- "A collection of mistakes" is emotionally raw — valid for the Closet Paralytic and Style Relic
- "Something changed and I haven't figured it out" is the Meno-Morpher and Mom Ghost answer

---

## SCREEN 11: The Body Change Question

- **Kind:** Step
- **Progress bar:** ~22%

---

**VISUAL ELEMENTS:**

*Editorial image note: warm, intimate. A real woman's closet — some things obviously not fitting on the rack, others clearly loved and worn. The image communicates the complexity of a closet with history.*

**Title (28px, bold):**
> Has your body changed significantly in the last few years?

**Subtext (16px, muted):**
> Menopause, pregnancy, illness, stress, just life — bodies change. Outfit Formulas rebuilds your formula system for your body as it is right now.

**Answer Options:**
- Yes — and nothing I used to rely on works anymore
- Yes — my shape has shifted but I'm still figuring out what works now
- Somewhat — gradual changes over time
- Not really — my body has stayed relatively consistent
- I've been waiting to lose weight before I deal with my wardrobe

---

**Design notes:**
- The direct Meno-Morpher language ("nothing I used to rely on works anymore") is included but not labeled — she selects her experience without being categorized
- "Waiting to lose weight" is the Weight Waiter answer — the most emotionally loaded option on this screen. It gets no special commentary here; the validation comes in the interstitial that follows.

---

## SCREEN 12: Validation Interstitial — The Waiting Acknowledgment

- **Kind:** Interstitial (no question)
- **Progress bar:** ~24%

---

**VISUAL LAYOUT:** Warm, soft card. Not clinical. Not dramatic. Like a page in a magazine that stops you.

**Photography note:**
> *A single image: a woman standing in front of her open closet. She's looking at it, not into it. There's a slight exhaustion in her posture — not despair, just tiredness. The image is entirely recognizable.*

**Body text (20px, slightly editorial):**
> If you're waiting for a different body before you invest in your style — you're not alone. More than half the women who come to Outfit Formulas say they've been putting it off for exactly that reason.

**Bold line (24px, #1E1E1E):**
> You're not being vain for wanting to feel like yourself.

**Continuation text (17px, muted):**
> And you don't need a different body to start. You need formulas that work for the body you have right now — which is exactly what we build.

**CTA Button:**
> Continue →

---

**Design notes:**
- This screen speaks to the Weight Waiter without making it awkward for non-Weight Waiters — the framing is broad enough to land for anyone who's been putting off caring about how she looks
- The copy doesn't push back on waiting — it simply, warmly, redirects

---

## SCREEN 13: The Compliment Memory

- **Kind:** Step
- **Progress bar:** ~26%

---

**Title (28px, bold, editorial):**
> When was the last time someone complimented how you looked and you actually believed it?

**Answer Options:**
- Recently — I get compliments and they feel true
- A while ago — I've had them but brushed them off
- A long time ago — years, maybe
- I genuinely can't remember
- I don't really get them anymore

---

**Design notes:**
- "Actually believed it" is the key qualifier — she may have gotten compliments she dismissed because she didn't feel it inside
- "I genuinely can't remember" is the Style Relic's exact answer

---

## SCREEN 14: Identity — Who She Was

- **Kind:** Step
- **Progress bar:** ~28%

---

**VISUAL ELEMENTS:**

*Editorial image note: old Polaroids or snapshots — the visual shorthand for memory, a former self. Warm, slightly nostalgic.*

**Title (28px, bold):**
> Did you used to have a style you loved?

**Subtext (16px, muted):**
> Before life got busy. Before things changed.

**Answer Options:**
- Yes — I knew exactly how to dress and I loved it
- I had the beginnings of one, but it never fully developed
- Sort of — I had things I liked but no real system
- No — I never really cracked it, even back then
- I'm not sure. I didn't think about it much until I lost it.

---

## SCREEN 15: The Loss Question

- **Kind:** Step
- **Progress bar:** ~30%

---

**Title (26px, bold):**
> What happened to it?

**Subtext (15px, muted):**
> Select the one that feels most true, even if it's more than one.

**Answer Options:**
- Kids happened — I dressed for function, not for me
- My body changed and my old wardrobe stopped working
- I got busy and just... stopped caring
- I moved, changed jobs, changed life stages — my whole context changed
- I never had a style I loved — I'm starting from scratch
- I'm not entirely sure. It just faded.

---

**Design notes:**
- "It just faded" is important — many women can't pinpoint a moment, and validating that vague loss is as important as the specific answers
- This screen echoes the Mom Ghost and Style Relic most directly, but all archetypes have experienced some version of style loss

---

## SCREEN 16: Multi-Select — What She Wants to Feel

- **Kind:** Step — multi-select
- **Progress bar:** ~32%

---

**VISUAL ELEMENTS:**

*Editorial image note: a woman putting on a blazer, caught in a private moment. She's looking into a handheld mirror, mid-gesture. Warm light. The image is aspirational but grounded.*

**Title (28px, bold):**
> What do you want to feel when you get dressed?
> (Select all that apply)

**Answer Options:**
- Like myself — genuinely me, not a worse version of me
- Put-together without it taking forever
- Confident enough to walk into any room
- Like I've actually tried, not just thrown something on
- Excited about getting dressed again — like I used to be
- Comfortable in my body, not fighting it
- Like I'm someone who has her act together
- Invisible in a good way — not noticed for looking wrong

---

**CTA Button:**
> Continue →

---

## SCREEN 17: The Closet Vision

- **Kind:** Step
- **Progress bar:** ~34%

---

**Title (28px, bold):**
> If your closet could only have 10 items — the ones that actually work — which would survive?

**Subtext (16px, muted):**
> Don't overthink it. What do you actually reach for?

**Answer Options (multi-select, tap all that apply):**
- A well-fitted pair of dark jeans
- A good blazer or jacket
- A few simple tops that just work
- A dress that goes to everything
- Soft, comfortable layers I can throw over anything
- Shoes I can wear with most things
- One statement piece I love and always wear
- Honestly — I don't know which 10 those would be

---

**Design notes:**
- This is a visualization exercise disguised as a question — getting her to mentally curate creates closet investment
- "I don't know which 10" is the most diagnostic answer — and the one Outfit Formulas most directly solves

---

## SCREEN 18: Lifestyle — Daily Reality

- **Kind:** Step
- **Progress bar:** ~36%

---

**Title (26px, bold):**
> What does a typical week look like for you, clothing-wise?

**Answer Options:**
- Mostly casual — home, errands, kids, low-key social
- Work-focused — professional dress most weekdays
- Mix of work and personal — needs to crossover
- Mostly social / active — dinners, events, fitness
- Genuinely all over the place — no two days are the same

---

## SCREEN 19: The Occasion Dread

- **Kind:** Step
- **Progress bar:** ~38%

---

**Title (26px, bold):**
> When you know you have an event or occasion coming up, what do you feel?

**Answer Options:**
- Excited — I like getting dressed up
- Neutral — it's fine, I manage
- Mild stress — I wish I had more to choose from
- Real anxiety — I start worrying days before
- I sometimes avoid things because I don't want to deal with the outfit problem

---

**Design notes:**
- "Sometimes avoid things" is the most important answer — it's the real cost of the problem, and naming it out loud creates urgency
- No judgment on any answer — she's not being told she has a problem; she's documenting what's true

---

## SCREEN 20: The Shopping Cycle

- **Kind:** Step
- **Progress bar:** ~40%

---

**Title (26px, bold):**
> When you shop for clothes, what usually happens?

**Answer Options:**
- I buy things that seem good in the store and they don't work at home
- I buy the same kinds of things I already have because they feel safe
- I don't really shop anymore — I've given up on it working
- I shop with someone else to get a second opinion and still feel unsure
- I shop online, return most of it, end up with nothing

---

## SCREEN 21: Premium Interstitial — The Cost of Not Having Formulas

- **Kind:** Interstitial (no question)
- **Progress bar:** ~42%

---

**VISUAL LAYOUT:** Two-column editorial spread aesthetic (adapted for mobile: stacked cards)

**Photography note:**
> *Left (or top): A pile of shopping bags — things bought, tags still on. The universal symbol of the failed purchase cycle.*
> *Right (or bottom): A woman getting dressed quickly and confidently. Simple clothes. No stress. She's about to head out.*

**Header (28px, bold):**
> What not having formulas actually costs.

**Left card text:**
> The average woman has $2,000 in unworn clothes in her closet.
> Not because she shops too much — because she shops without a formula system. Things that seemed good in isolation. Things that don't go with anything. Things held "for later" that never comes.

**Right card text:**
> Women who use formula-based dressing wear 3× more of their wardrobe within the first month. Not because they shop less — because they finally see what they already have.

**CTA Button:**
> Continue →

---

## SCREEN 22: The Pinterest Question

- **Kind:** Step
- **Progress bar:** ~44%

---

**Title (26px, bold):**
> How much time do you spend looking at style content online — Instagram, Pinterest, TikTok?

**Answer Options:**
- Almost none — I've given up on it being useful
- A little — I scroll occasionally but it doesn't change what I wear
- A fair amount — I save things but rarely wear them
- A lot — I'm constantly looking for the outfit that will finally work
- I used to spend a lot of time. I stopped because it was making me feel worse.

---

**Design notes:**
- "I stopped because it was making me feel worse" is the Scroll Comparer's evolved state — she recognized the harm and opted out. This answer validates her decision and signals she's ready for something that actually works.

---

## SCREEN 23: The Comparison Feeling

- **Kind:** Step
- **Progress bar:** ~46%

---

**Title (26px, bold):**
> When you see someone who always looks put-together, what's your first reaction?

**Answer Options:**
- Admiration — I think "I'd love to understand how she does it"
- A small hit of envy — she has something I can't figure out
- Comparison — I wonder what's different about her
- Curiosity — I try to figure out what she's doing specifically
- Resignation — I've stopped thinking I can get there

---

## SCREEN 24: The Dream Morning

- **Kind:** Step — aspirational visualization
- **Progress bar:** ~48%

---

**VISUAL ELEMENTS:**

*Editorial image note: morning light streaming into a bedroom. A coffee cup. An outfit laid out on the bed — nothing fussy, but clearly chosen. The image communicates intention and calm.*

**Title (30px, bold, editorial):**
> If getting dressed was easy — genuinely easy —
> what would change about your mornings?

**Subtext (16px, muted):**
> Not just the 7 minutes you'd save. What would actually be different?

**Answer Options:**
- I'd start the day feeling like myself, not already defeated
- I'd have more mental space for other things
- I'd be more present with my family / kids / partner
- I'd feel more confident going into whatever's ahead
- I'd actually enjoy mornings instead of dreading them
- I'd stop second-guessing myself before I've even had coffee

---

**Design notes:**
- This is the aspirational anchor — she is now building her personal "why" for change
- The connection to "mornings" is important: this is a daily quality-of-life issue, not an occasional one
- The editorial image does the emotional work — she can see the morning she wants

---

## SCREEN 25: Multi-Select — What's Holding Her Back

- **Kind:** Step — multi-select
- **Progress bar:** ~50%

---

**Title (28px, bold):**
> What's gotten in the way of figuring this out until now?
> (Select everything that's true)

**Answer Options:**
- Time — I'm always handling other things first
- Money — I don't want to spend more on clothes that won't work
- Energy — it feels too hard to tackle
- Not knowing where to start
- Feeling like it's shallow or vain to care about this
- Waiting until my body is different
- Past experiences — I've tried things that didn't work
- Honestly, I think I just stopped believing I could get it right

---

**CTA Button:**
> Continue →

---

**Design notes:**
- "Feeling like it's shallow or vain" is the permission-giving answer — naming it here means the funnel implicitly gives her permission to prioritize this
- "Stopped believing I could get it right" is the most vulnerable answer — and the one that the results section must speak to directly

---

## SCREEN 26: The Permission Screen

- **Kind:** Interstitial (no question)
- **Progress bar:** ~52%

---

**VISUAL LAYOUT:** Clean, warm card. Editorial tone. Like a letter to a friend.

**No photography — typography-forward**

**Body text (22px, #1E1E1E, centred, generous line spacing):**
> You're not being vain.

> Caring how you look isn't a luxury. It's how you show up. In rooms. For yourself. In the mirror on the days that matter.

> The women who've done this work — millions of them — don't regret it. They regret waiting.

**Pull quote (28px, bold, #FF2A6D):**
> "Getting dressed should take 5 minutes and feel like the start of something good."

**CTA Button:**
> I'm ready. Continue →

---

## SCREEN 27: Formula Preference

- **Kind:** Step
- **Progress bar:** ~54%

---

**Title (26px, bold):**
> When you imagine your ideal wardrobe working for you, what matters most?

**Answer Options:**
- Everything goes with everything — maximum combinations from minimum pieces
- I want a few signature formulas I can count on every day
- I want the flexibility to dress up or down without having two wardrobes
- I want to wear things I actually love, not just things that "work"
- All of these — I want the whole thing sorted

---

## SCREEN 28: Texture and Fabric Preference

- **Kind:** Step
- **Progress bar:** ~56%

---

**Title (26px, bold):**
> What fabrics and textures do you actually love wearing?

**Subtext (15px, muted):**
> Comfort is a formula input — we make sure your formulas feel as good as they look.

**Answer Options (multi-select):**
- Soft knits — sweaters, jersey, comfortable fabrics
- Structured cotton and linen
- Silk or satin-adjacent — I like something with some polish
- Denim — it's always in the rotation
- Stretchy, forgiving fabrics — comfort first
- Mixed — it depends on the occasion and my mood

**CTA Button:**
> Continue →

---

## SCREEN 29: Getting-Dressed Frequency Analysis

- **Kind:** Step
- **Progress bar:** ~58%

---

**Title (26px, bold):**
> How often do you wear something and feel genuinely good in it?

**Answer Options:**
- Most days — I have it mostly figured out
- About half the time — hit-or-miss
- A few times a week if I'm lucky
- Rarely — most days feel like a compromise
- Almost never anymore

---

## SCREEN 30: Social Confidence Impact

- **Kind:** Step
- **Progress bar:** ~60%

---

**Title (26px, bold):**
> Has how you dress affected your confidence in social situations?

**Answer Options:**
- Yes — on bad outfit days I hold back more, avoid things
- Somewhat — I'm self-conscious but still show up
- Not really — how I look doesn't affect how I act
- I've avoided entire situations or events because of it
- I've stopped accepting certain invitations altogether

---

**Design notes:**
- "Avoided entire situations" is the highest-cost answer — the most powerful motivator for change
- This answer gets echo treatment in the results section: she'll see her answer reflected in her Evolution Blueprint

---

## SCREEN 31: Multi-Select — The Real Costs

- **Kind:** Step — multi-select
- **Progress bar:** ~62%

---

**Title (28px, bold):**
> Which of these has the closet-and-getting-dressed problem actually cost you?
> (Select what's genuinely true)

**Answer Options:**
- Wasted money on things I never wore
- Time — hours I'll never get back standing in front of a mirror
- Mornings starting on a sour note
- Missing out on things I should have enjoyed
- Not feeling like myself at moments that mattered
- Letting people see a version of me that doesn't reflect who I am
- The quiet belief that I'll never figure this out

---

**Design notes:**
- "Letting people see a version of me that doesn't reflect who I am" is the identity-level loss — the deepest of the costs
- This is the final pain-crystallization screen before the aspiration turn

---

## SCREEN 32: The Vision Screen

- **Kind:** Step
- **Progress bar:** ~65%

---

**VISUAL ELEMENTS:**

*Editorial image note: A woman walking into a room — from behind, entering. Good clothes, easy confidence, warm light ahead. The image communicates forward movement and arrival.*

**Title (28px, bold, editorial):**
> Now let's talk about where you're going.

**Body text (17px, muted):**
> Your Style Evolution isn't about becoming someone else. It's about getting dressed in a way that shows who you already are.

---

**Question (22px, bold):**
> What does "having your style sorted" look like for you?

**Answer Options:**
- Getting dressed in 5 minutes and leaving the house feeling good
- Having an answer for every occasion without stress
- Feeling like myself every day, not just on good days
- Wearing things I love instead of things that are "fine"
- Being the woman other women look at and think "she's figured something out"

---

## SCREEN 33: Timeline Setting

- **Kind:** Step
- **Progress bar:** ~67%

---

**Title (26px, bold):**
> How ready are you to work on this now?

**Subtext (15px, muted):**
> No pressure — just helps us know how to frame your blueprint.

**Answer Options:**
- Ready now — I want to start immediately
- Almost — I'm still deciding if this is the right time
- Slowly — I want to ease into it
- I need to see results first before I commit fully
- I've been saying "I'll deal with this" for years and I'm tired of waiting

---

**Design notes:**
- "Tired of waiting" is the high-intent answer — the style version of the weight-loss "I've tried everything and nothing works"
- This answer can be used to personalize the results headline: for women who select it, the results open with "You've waited long enough."

---

## SCREEN 34: Progress Investment

- **Kind:** Step
- **Progress bar:** ~69%

---

**Title (26px, bold):**
> How much time per week are you realistically willing to invest in building your style system?

**Answer Options:**
- 15 minutes or less — I need this to be low-effort
- 15–30 minutes — reasonable
- 30–45 minutes — I'm serious about this
- An hour or more — I'm ready to commit
- Time isn't the issue. I've been spending 20+ minutes every morning already — that's the problem.

---

**Design notes:**
- The last answer is the most powerful reframe — she's already spending the time, just spending it badly

---

## SCREEN 35: Name Capture

- **Kind:** Step
- **Progress bar:** ~72%

---

**VISUAL ELEMENTS:**

*Editorial image note: Soft close-up of handwriting on cream paper — the visual of personalization, of something being made specifically for you.*

**Title (28px, bold):**
> What's your first name?

**Subtext (16px, muted):**
> Your Style Evolution Blueprint is personalised to you.

**Input field:** First name

**CTA Button (pink, full-width):**
> Continue →

---

## SCREEN 36: Email Capture

- **Kind:** Step
- **Progress bar:** ~75%

---

**Title (26px, bold):**
> Where should we send your Style Evolution Blueprint?

**Subtext (16px, muted):**
> We'll send your full results — including your formula matches, your color profile, and your personalized 30-day plan — to your inbox.

**Input field:** Email address

**CTA Button:**
> Send My Blueprint →

**Trust line (13px, muted):**
> Privacy protected. No spam. Unsubscribe anytime.

---

## SCREEN 37: Loading / Blueprint-Building Screen

- **Kind:** Interstitial — animated loading simulation
- **Progress bar:** ~78%

---

**VISUAL ELEMENTS:**

*Editorial image note: Abstract warm-toned visual — like paint mixing, or fabric swatches being arranged. Beautiful, not clinical. The visual language of creation rather than computation.*

**Header (28px, bold):**
> Building your Style Evolution Blueprint, {{firstName}}...

**Animated items (appear sequentially):**
> ✓ Body proportion profile — complete
> ✓ Color harmony analysis — complete
> ✓ Lifestyle context mapped
> ✓ Morning pattern analysis — complete
> ✓ Formula library matched to your profile...
> ✓ 30-day evolution plan generated...
> ✓ Blueprint ready.

**Progress bar:** 0% → 100% over 10 seconds

**Subtext (15px, muted):**
> Your blueprint is built from your answers — not a generic template. It reflects your body, your life, and your specific evolution starting point.

**Auto-advances at 100%.**

---

## SCREEN 38: Social Proof Before Results

- **Kind:** Interstitial — testimonials
- **Progress bar:** ~80%

---

**VISUAL LAYOUT:** Three testimonial cards, editorial design — like quotes pulled from a magazine feature

**Header (20px, bold):**
> While your blueprint finalizes — women who've been where you are:

---

**Testimonial 1 (warm, specific, real voice):**
> ⭐⭐⭐⭐⭐
> *"I was 52 and I genuinely believed I'd just gotten frumpy and that was it. Two weeks in I walked into my sister's birthday party and she grabbed my arm and said 'you look incredible.' I cried in the bathroom. Not because of how I looked — because I felt like myself again."*
> — **Linda B.**, 52, Chicago

---

**Testimonial 2:**
> ⭐⭐⭐⭐⭐
> *"I had spent $4,000 on a personal stylist three years ago and I was still standing in front of my closet every morning feeling nothing. Outfit Formulas cost me less than a coffee a day and I wear different things every single day now. I had the outfits the whole time."*
> — **Margot S.**, 47, Toronto

---

**Testimonial 3:**
> ⭐⭐⭐⭐⭐
> *"Honestly I took this quiz because a friend shared it and I wasn't expecting much. Then my results came up and it described my morning routine so accurately I actually laughed. I've been using the formulas for three months. I don't dread Mondays anymore."*
> — **Theresa K.**, 44, Atlanta

---

**CTA Button:**
> See My Blueprint →

---

## SCREEN 39: Results — Style Evolution Blueprint

- **Kind:** Results screen — custom HTML, premium editorial design
- **Progress bar:** Complete (hidden)

---

### RESULTS PAGE LAYOUT — Magazine editorial aesthetic

**Top section:**

**Label (16px, caps, #FF2A6D):**
> {{firstName}}'S STYLE EVOLUTION BLUEPRINT

**Headline (38px, bold — warm and direct):**
> {{firstName}}, here's what we found.
> And here's where you're going.

**Photography note for results hero:**
> *Full-width warm image — a beautiful, organized-looking section of a closet with pieces that clearly coordinate. Not perfect, not staged. Just a closet that makes sense. Inclusive, diverse, warm.*

---

**SECTION 1: Your Evolution Starting Point**

**Card heading (20px, bold, with subtle pink accent):**
> Where You Are Right Now

**Dynamic body text (reflects her quiz answers):**
> Based on your answers, you're [wearing approximately 20-30% of your wardrobe / spending 20+ minutes getting dressed most mornings / avoiding certain occasions because of what to wear]. You've described your current feeling as [her selected word].

> This isn't where your story ends. It's where your Style Evolution starts.

---

**SECTION 2: Your Body's Formula Blueprint**

**Card heading (20px, bold):**
> Your Proportion Profile

**Body text:**
> Your frame type — [Balanced / Upper / Lower / Straight] — responds best to formula structures that [create visual balance across the shoulder-hip line / define the waist area / use vertical lines to elongate]. Your best formula categories are listed below.

**Formula tag pills (3 tags, pink background, white text):**
> The Tone Stack   The Column Line   The Anchor Layer

---

**SECTION 3: Your Color Evolution**

**Card heading (20px, bold):**
> Your Color Profile

**Body text:**
> Your undertone profile sits in the [Warm / Cool / Neutral] range. The color families that will work hardest in your formulas: [warm earth tones — camel, rust, olive, warm cream / cool tones — navy, gray, dusty rose, soft white / neutral range — both warm and cool families with the right saturation].

**Swatch row:** 6-color palette, labeled "Your Formula Colors"

**Note (italic, 15px, muted):**
> *These aren't the only colors you can wear. They're the ones that require zero adjustment — they just work.*

---

**SECTION 4: Your Morning Forecast**

**Card heading (20px, bold):**
> What Changes in 30 Days

**Stat visual (three milestone markers on a timeline):**
> **Week 1:** You have your formulas. Getting dressed takes under 10 minutes.
> **Week 2:** You're wearing things you haven't touched in years.
> **Week 4:** Your morning pattern has changed. The closet-dread is gone.

**Supporting stat:**
> Women with your profile type report a 71% reduction in morning decision stress within 30 days.

---

**SECTION 5: Your 30-Day Evolution Plan Preview**

**Card heading (20px, bold):**
> Your First 30 Days — Sample

**Three-row preview (blurred/locked after row 3):**
> **Day 1:** Identify your 10 most-worn pieces. Build your first formula around them.
> **Day 3:** Apply Formula 2 — The Tone Stack — using three pieces you already own.
> **Day 7:** Your first week done. You've already created [X] new outfit combinations.
> [Days 8–30 locked — unlock with plan]

---

### TESTIMONIALS (2, premium format)

**Quote card 1:**
> *"I've never felt like a style person. I thought the quiz would confirm that. Instead it gave me a framework. Now I get dressed in 8 minutes and I feel like me."*
> — **Patricia F.**, 58, Seattle

**Quote card 2:**
> *"My closet has $3,000 in unworn clothes. This showed me how to wear most of them without buying a single new thing."*
> — **Sandra O.**, 49, Denver

---

**CONTINUE CTA (full-width, pink, bold, 18px):**
> Start My Style Evolution →

---

## SCREEN 40: Pre-Paywall — The Club Invitation

- **Kind:** Interstitial — final warm-up before paywall
- **Progress bar:** Hidden (post-results)

---

**VISUAL LAYOUT:** Editorial, warm. The feeling of an invitation arriving.

**Photography note:**
> *A diverse group of women — different ages (35–65), different builds, different ethnicities — laughing, talking, clearly in a community. Not a stock photo. Editorial, warm, specific. The image communicates belonging.*

**Header (32px, bold, centred):**
> Over 2 million women have started their Style Evolution.

**Body text (18px, muted, centred):**
> They were in exactly the same place you are now. Closets full of things they didn't wear. Mornings that started wrong. The feeling of having lost something — a version of themselves they used to know.

> Most of them waited longer than they wished they had.

**Pull quote (24px, bold, #FF2A6D):**
> "I wish I'd done this three years ago."
> — Every woman who does this, apparently.

**CTA Button:**
> Join Them →

---

## SCREEN 41: PAYWALL — BETTERME MODEL
### Premium Brand Paywall: Joining an Exclusive Club

- **Kind:** Custom HTML paywall screen (warm cream background, premium editorial aesthetic, no clinical hardness)
- **Paywall Architecture:** BETTERME — premium brand experience. Discounted first period + urgency timer. Paywall feels like membership, not purchase.

---

### HERO / HEADLINE SECTION

**Photography note (full-bleed background or large hero image):**
> *Single woman, mid-40s, beautifully dressed in a simple, well-put-together outfit. She's not posing. She's standing in soft morning light. The image communicates effortless confidence — the exact feeling the user has been building toward for 40 screens.*

**Pre-headline (14px, caps, muted):**
> YOUR STYLE EVOLUTION BLUEPRINT IS READY

**Main Headline (38px, bold, #1E1E1E):**
> {{firstName}}, your formulas are ready.
> Let's start your evolution.

**Sub-headline (18px, #6B6B6B):**
> Join 2,000,000+ women who decided their style was worth it. Your personalized blueprint starts today.

---

### URGENCY TIMER (subtle — not red alarm-style, but present)

**Styled card (cream, pink border, centered):**

```
⏱ Your personal offer expires in: [23:47]

Your Style Evolution Blueprint was built from
your answers. This introductory rate is reserved
for first-time members completing the quiz today.
```

---

### PLAN SELECTOR

**Section header (22px, bold):**
> Choose your plan

**Subtext (15px, muted):**
> First period at the introductory rate. Then the standard rate — cancel anytime before renewal.

---

**PLAN CARD 1 — 3-Month Plan** *(first option, standard)*

```
┌──────────────────────────────────────────────────┐
│  3-Month Plan                                     │
│                                                   │
│  First 3 months: $14.99 (50% off)                 │
│  Then $29.99 / 3 months ongoing                   │
│  Just $0.17/day to start                          │
│                                                   │
│  ✓ Full formula library                          │
│  ✓ Daily outfit suggestions                      │
│  ✓ Color & proportion toolkit                    │
│  ✓ 30-day evolution plan                         │
│  ✓ Cancel anytime                                │
└──────────────────────────────────────────────────┘
```

---

**PLAN CARD 2 — Annual Plan** *(pre-selected, pink border glow, "Best Value" badge)*

```
┌──────────────────────────────────────────────────┐
│  ★ BEST VALUE — Most Popular                      │
│                                                   │
│  Annual Plan                                      │
│  First year: $39.99 (Save 20%)                    │
│  Then $49.99 / year ongoing                       │
│  Just $0.11/day — less than a cup of coffee       │
│                                                   │
│  ✓ Everything in 3-month, plus:                  │
│  ✓ Full seasonal formula refresh (4× / year)     │
│  ✓ Priority access to new formula categories     │
│  ✓ Style Evolution community access              │
│  ✓ Cancel anytime                                │
└──────────────────────────────────────────────────┘
```

---

**PLAN CARD 3 — Monthly Plan** *(third option, no badge)*

```
┌──────────────────────────────────────────────────┐
│  Monthly Plan                                     │
│  $9.99 / month                                    │
│  Just $0.33/day                                   │
│                                                   │
│  ✓ Full formula library                          │
│  ✓ Daily outfit suggestions                      │
│  ✓ Cancel anytime                                │
└──────────────────────────────────────────────────┘
```

---

### PRIMARY CTA BUTTON (full-width, pink, bold, 20px)

```
[ Start My Style Evolution → ]
```

*Sub-copy beneath button (13px, muted):*
> First period at introductory rate. Cancel anytime before renewal. Secure checkout.

---

### WHAT'S INCLUDED — ASPIRATIONAL FRAMING

**Section header (22px, bold):**
> What your Style Evolution membership includes

**Six-item list (icon + bold title + editorial description line):**
> 👗 **Your complete formula library** — 20+ formulas built specifically for your proportion profile and color palette
> 📱 **Daily outfit suggestions** — from your existing wardrobe, every single morning
> 🎨 **Your color harmony toolkit** — exact palette, combination rules, and what to avoid — for your undertone profile
> 📐 **Proportion blueprint** — the structural logic behind which styles work for your frame and why
> 📅 **Your 30-day evolution plan** — a day-by-day guide to applying your formulas to your existing wardrobe
> 💬 **Style Evolution community** — over 2 million women who know exactly where you are right now

---

### TESTIMONIALS (4, emotionally specific, in her voice)

**Section header (20px, bold):**
> Women who were right where you are:

---

**Testimonial 1:**
> ⭐⭐⭐⭐⭐
> *"I'm 53. I had basically accepted that I'd never look the way I used to. Three weeks in, a woman I barely know stopped me at the school pickup and asked where I'd been shopping. I hadn't bought a single new thing."*
> — **Carol M.**, 53, Nashville

---

**Testimonial 2:**
> ⭐⭐⭐⭐⭐
> *"I was the woman who spent 30 minutes every morning and still felt frumpy walking out the door. Now my husband comments on my outfits almost daily. Not because I'm dressed up — because I finally look like me."*
> — **Julie T.**, 46, Portland

---

**Testimonial 3:**
> ⭐⭐⭐⭐⭐
> *"After my second kid I basically disappeared into mom-clothes. I wore what wouldn't get destroyed. I forgot I had a style. This reminded me who I was before I became someone's mother — and I didn't have to choose."*
> — **Alicia R.**, 38, Boston

---

**Testimonial 4:**
> ⭐⭐⭐⭐⭐
> *"My body changed in my 40s and nothing worked anymore. I was grieving my old wardrobe. The formulas they built for my actual body right now — not the one I used to have — completely changed how I get dressed."*
> — **Karen L.**, 49, Dallas

---

### GUARANTEE

**Guarantee block (warm cream card, soft pink border):**

```
🛡️ 30-DAY MONEY-BACK GUARANTEE

If Outfit Formulas doesn't change how
you get dressed within 30 days — you
get every cent back. No hoops, no forms.

This should work. If it doesn't, we make it right.
```

---

### SECONDARY SOCIAL PROOF STRIP

**Stat row (three pills, icon + text):**
> 👩 **2,000,000+ women** have started their Style Evolution
> ⭐ **4.8 stars** from 180,000+ reviews
> 👗 **3× more** of their wardrobe worn within 30 days

---

### FOOTER (sticky, visible while scrolling)

```
⏱ Your introductory offer expires in [23:47]   [ Start My Evolution → ]
```

- Warm cream background with pink accent — matches brand, not alarm-red
- CTA scrolls to plan selector

---

**Design notes for Screen 41:**
- The timer is present but not aggressive — this isn't Sofa Yoga's red countdown. It's a gentle reminder that this offer is time-bound, consistent with the premium brand feel.
- Three plans, Annual pre-selected — classic BetterMe architecture. The 3-month plan at 50% off is the entry point for more price-sensitive users; the Annual is the obvious value choice.
- Testimonials are specific, emotional, and diverse — no generic "I love this app!" copy
- The guarantee copy sounds like a person wrote it, not a legal team
- The sticky footer uses "Start My Evolution" — identity language, not purchase language
- **Paywall model: BETTERME — Premium brand + first-period discount + timer**

---

## SCREENS 42–44: Post-Purchase Onboarding Flow (Optional)

### SCREEN 42: Upsell — Style Evolution Community
- **Kind:** Optional post-purchase upsell (shown only to Monthly plan purchasers)
- **Offer:** Upgrade to Annual for community access + $10 savings

### SCREEN 43: Closet Setup — Photo Prompt
- **Kind:** First onboarding step — photograph your most-worn 10 pieces
- **Headline:** "Let's start with what you already love."

### SCREEN 44: First Formula Delivery
- **Kind:** Results delivery — first 3 formulas generated from closet + profile
- **Headline:** "{{firstName}}, here are your first three formulas."

---

## SCREEN 45: Exit Node
- **Kind:** Exit node
- **Notes:** Routes to app onboarding or payment processor. Passes {{firstName}}, {{email}}, selected plan, undertone profile, and proportion type.

---

# SUMMARY OF SCREEN TYPES — FUNNEL H

| Type | Count | Screens |
|------|-------|---------|
| Start / Exit nodes | 2 | 1, 45 |
| Landing + age selection | 1 | 2 |
| Single-choice demographic | 2 | 4, 18 |
| Single-choice emotional/behavioral | 16 | 3, 6, 7, 8, 9, 10, 11, 13, 14, 15, 19, 20, 22, 23, 29, 30 |
| Single-choice aspirational | 5 | 24, 27, 32, 33, 34 |
| Multi-select | 4 | 16, 17, 25, 28, 31 |
| Interstitials (brand / editorial / proof) | 6 | 5, 12, 21, 26, 38, 40 |
| Loading / blueprint-building animation | 1 | 37 |
| Name / email capture | 2 | 35, 36 |
| Results screen (custom HTML) | 1 | 39 |
| Paywall (custom HTML) | 1 | 41 |
| Post-purchase onboarding | 3 | 42, 43, 44 |

**Total: 45 screens** ✅

---

# FUNNEL H COPY RULES

1. **Every screen is editorial** — ask yourself: would this copy feel at home in Real Simple or Good Housekeeping? If not, elevate it.
2. **Premium doesn't mean cold** — warm, relatable, specific. Like a stylish friend who has done a lot of introspection and is comfortable in her skin.
3. **Never dramatize, but never minimize** — she's had a real loss; acknowledge it fully and move toward the solution with warmth, not urgency
4. **The photography is half the funnel** — every editorial image note is a production direction. The images build the brand premium just as much as the words.
5. **Identity language over appearance language** — "feel like yourself," "feel like you have your act together," "show up as who you are" — not "look younger," "look slimmer," "look better"
6. **Testimonials are specific and emotional** — generic reviews don't work for premium brands. Every testimonial should sound like a real woman who had a real experience.
7. **The paywall inherits the editorial tone** — warm cream, pink accents, no alarm-red countdown. Urgency is present but not aggressive.
8. **"Start My Style Evolution" not "Buy Now"** — identity-driven CTAs throughout

---

# CROSS-FUNNEL NOTES

## Funnel G vs. Funnel H: Key Distinctions

| Element | Funnel G (Science) | Funnel H (Premium) |
|---------|-------------------|-------------------|
| Target | Scroll Comparer (data-skeptical) | All archetypes (premium-aspirational) |
| Length | 33 screens | 45 screens |
| Voice | Measured, analytical, research-forward | Editorial, aspirational, warm |
| Interstitials | Data stats + research citations | Brand photography + aspirational copy |
| Question style | "Why we're asking" notes on every question | Evocative headlines with context |
| Results | "Style Science Profile" — clinical aesthetic | "Style Evolution Blueprint" — editorial aesthetic |
| Paywall | Minimal — no timer, clean, confidence-led | Premium — soft timer, 3-tier, first-period discount |
| Primary CTA | "Unlock My Formula Library" | "Start My Style Evolution" |
| Conversion mechanic | Trust + credibility → logical purchase | Investment + identity → emotional belonging |

## Shared Brand Rules
- Never: capsule wardrobe, curated, elevated, effortless chic, slimming, age-appropriate
- Always: her words. "Frumpy," "feel like myself again," "nothing to wear," "gave up trying"
- Colors: #FF2A6D pink, #FFF8F5 cream, #1E1E1E text, #6B6B6B secondary
- Font: Inter throughout
- Buttons: 12px border-radius, full-width, mobile-first
