# Outfit Formulas — Quiz Funnels A & B
## Complete Screen-by-Screen Specifications

---

# FUNNEL A: "What's Your Hidden Outfit Score?"
## SmartyMe Paywall Architecture — The Closet Paralytic
**Target Archetype:** The Closet Paralytic
**Quiz Length:** 27 screens
**Paywall:** SmartyMe — Countdown discount timer (10 min) + hybrid trial

---

# WHY THIS FUNNEL WORKS FOR THE CLOSET PARALYTIC

## The Core Insight

The Closet Paralytic doesn't think she has a style problem. She thinks she has a closet problem. Or a money problem. Or a body problem. Or — and this is the one she circles back to at 7am with wet hair and three rejected outfits on the bed — a motivation problem.

She's wrong on all counts. She has a **visibility problem**. There are 50+ outfits in her closet right now that she cannot see. Not because she's lazy or disorganized or has bad taste. Because she has no system for seeing them.

This funnel's entire job is to:
1. Mirror her exact morning experience so precisely she feels caught
2. Count the evidence of the visibility problem as she answers each question
3. Convert that count into a score — **her Hidden Outfit Score**
4. Show her the score is fixable in 10 minutes a day
5. Create urgency around acting on this insight NOW, before she closes the tab and goes back to the same jeans

The score mechanic is the conversion engine. She doesn't just feel seen — she sees a number. A number that tells her exactly how many outfits she's missing. That number is solvable. The app solves it.

---

## Stage-by-Stage Psychology Breakdown

### Stage 1 — The Recognition Trap
**Screens 2–7 | What it does:** Gets her to self-label as a Closet Paralytic through low-stakes demographic questions that rapidly escalate into mirror moments.

**Why it works:**

The opening questions feel like registration. Age, lifestyle, how she'd describe her current style situation. By the time she's answering whether she reaches for the same 5 things every week, she's not answering a quiz — she's confessing something she's never said out loud. And she clicked the answer herself.

The zero-friction principle matters here: she's already in the habit of tapping answers by the time the emotionally loaded questions arrive. The habit of honesty is set.

The early interstitial — "73% of women say the same thing. You're not alone in this." — does two things simultaneously: it normalizes her experience AND implies that 73% of women have a shared underlying problem that has a shared underlying solution.

She's now curious.

---

### Stage 2 — The Agreement Barrage
**Screens 8–13 | What it does:** Forces her to confirm, in her own clicks, the specific behaviors that define closet paralysis.

**Why it works:**

Each question in Stage 2 is written to be impossible to answer "no" to honestly. Does she try things on and put them back? Yes. Does she have clothes she's never worn with the tags still on? Yes. Does she own things she bought hoping she'd figure out "how to wear it someday"? Of course.

Every "yes" is a micro-commitment. Every confirmed behavior adds to her Hidden Outfit Score invisibly. She can feel the score building even before she sees it. By question 13, she's confirmed six specific behaviors that prove the problem is real and specific.

The Likert-style screens (How often do you walk out in your "whatever, fine" outfit?) carry clinical weight. This isn't an ad. This is a diagnostic.

---

### Stage 3 — Cost Expansion
**Screens 14–18 | What it does:** Moves the pain from abstract frustration to concrete, real-world cost — time, money, emotional energy, missed opportunities.

**Why it works:**

"I have nothing to wear" is a feeling. Ignorable. Manageable. Something she's been managing for years.

"You've spent 120+ hours this year standing at a full closet feeling bad" is not ignorable. That's a weekend. That's three full workdays. That's time she'll never get back.

The shopping guilt question is a turning point. She didn't just buy things she doesn't wear — she feels bad every time she opens the closet and sees them. The closet isn't just unhelpful. It's actively costing her confidence every single morning.

The multi-select frustration screen is the mirror at full resolution. She checks every box. And each box checked means: this is the cost of not having a system.

---

### Stage 4 — Hope Injection + Score Preview
**Screens 19–22 | What it does:** Pivots from pain to possibility. Introduces the Hidden Outfit Score concept. Reframes the problem.

**Why it works:**

The reframe is everything: "You don't have a wardrobe problem. You have a visibility problem."

This is not toxic positivity. It's a diagnosis shift. The Closet Paralytic has spent years blaming herself — her taste, her body, her budget. The funnel tells her the problem was never her. It was the absence of a system for seeing what's already there.

The "women with similar closets" interstitial makes the solution feel proven, not aspirational: women who answered the same way as her unlocked an average of 51 outfit combinations. Not hypothetical. Based on her specific closet profile.

Loading screen with animated counter builds anticipation. By the time the score appears, she's been waiting for it. She wants it.

---

### Stage 5 — Score Reveal + Future Cast
**Screens 23–26 | What it does:** Delivers the Hidden Outfit Score. Makes the transformation specific, tangible, and personal. Creates identity-level change in how she sees her closet.

**Why it works:**

The score is not bad news. It's good news dressed as revelation. "You have 47 outfits hiding in your closet" is not a judgment — it's a treasure map.

The before/after is emotional, not physical. It's not about how she looks. It's about how she feels walking out the door. That's the promise: "5 minutes. Done. Out the door feeling like yourself."

Testimonials from women who used to be her — same words, same morning, same jeans — and now aren't. The transformation is credible because it's specific.

The paywall arrives when she's at peak hope. She just found out she has 47 hidden outfits. The app finds them. The timer says act now.

---

## The Central Conversion Mechanism

The quiz never sells the app. The quiz builds a **score**. By the time the paywall appears, she has:

1. Self-identified as a Closet Paralytic (Stage 1)
2. Confirmed 6+ specific closet paralysis behaviors (Stage 2)
3. Connected those behaviors to real cost — time, money, confidence, identity (Stage 3)
4. Learned her problem is a visibility problem, not a taste problem (Stage 4)
5. Seen her personalized Hidden Outfit Score and the specific number of outfits she's missing (Stage 5)

The app is just the tool that reveals the outfits she already has. She's not buying hope. She's buying access to what's already hers.

---

# THE COMPLETE 27-SCREEN FUNNEL

---

## SCREEN 1: Start (Entry Node)

- **Kind:** Start (invisible entry node)
- **Notes:** Automatically transitions to Screen 2. No visible content. Platform handles routing.

---

## SCREEN 2: Landing / Style Situation Selection

- **Kind:** Step — Landing page + primary self-identification
- **Progress bar:** None (this is the first screen)

---

**VISUAL ELEMENTS:**

- **Top badge:** `HIDDEN OUTFIT SCORE QUIZ` — pill/badge style, pink (#FF2A6D) fill, white text
- **Headline (large, 36–40px, bold, dark charcoal):**
  > **FIND OUT HOW MANY OUTFITS**
  > **ARE HIDING IN YOUR CLOSET**

- **Subheadline (18px, secondary grey):**
  > Get your personalized Hidden Outfit Score in 4 minutes. Built for women who have a full closet and nothing to wear.

- **Badge:** `⏱ 4-MINUTE QUIZ · 147,000+ WOMEN HAVE TAKEN THIS` — centred, cream background, pink text

- **Trust line (small, below badge):**
  > No shopping required. We work with what you already own.

---

**QUESTION TYPE:** Single-choice, 2-column image grid

**Question text (20px, bold, centred):**
> Which of these sounds most like you right now?

**Answer Options (image cards with short labels, auto-advance on click):**
- 🖼️ **"Full closet, nothing to wear"** — illustration of overstuffed closet
- 🖼️ **"Same 5 outfits on rotation"** — illustration of repeated outfits
- 🖼️ **"Clothes I've never worn"** — illustration of tags-on items in closet
- 🖼️ **"I used to know how to dress"** — illustration of woman looking confused at closet

**Behaviour:** Auto-advances on click. No separate button. Response stored for personalization.

**Footer text (small, legal grey):**
> By continuing you agree to our Terms of Use and Privacy Policy.

---

**DESIGN NOTES:**
- Background: Warm cream (#FFF8F5) — this is a friend's space, not a clinical quiz
- Headline font: Inter bold — warm but sharp
- No mention of Outfit Formulas yet. This is "your quiz."
- The 4 answer options are ALL closet paralytic variants — she clicks whichever one fits, she's already self-labelled

---

## SCREEN 3: Age Selection

- **Kind:** Step
- **Progress bar:** ~8%

---

**Title (28px, bold):**
> How old are you?

**Subtitle (16px, secondary grey):**
> Outfit formulas work differently depending on your life stage — we personalize your score based on this.

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance on click):**
- Under 30
- 30–39
- 40–49
- 50–59
- 60+

**Design notes:**
- The subtitle neutralizes age anxiety immediately — "life stage" signals she's not being sorted into a category, she's being understood
- No ages are wrong here. Every age bracket has its own closet chaos.

---

## SCREEN 4: Social Proof Interstitial (Early Trust)

- **Kind:** Step — interstitial (no question)
- **Progress bar:** ~12%

---

**Visual layout:** Warm cream background. Pink (#FF2A6D) accent bar at top. Centred text block.

**Headline (28px, bold, charcoal):**
> You're in good company.

**Body copy (18px, charcoal, line breaks for rhythm):**
> 73% of women say they have nothing to wear.
> Even with a full closet.
>
> Most assume it's a style problem.
>
> It isn't.
>
> **It's a visibility problem. And it's fixable.**

**Stat visual (large, pink accent):**
> `147,000+`
> women have taken this quiz and found outfits they didn't know they had.

**CTA Button (full-width, pink, bold):**
> `Continue →`

---

**Design notes:**
- This screen slows her down for the first time. She just clicked through 2 fast screens — this pause creates gravitas
- The reframe ("visibility problem") seeds Stage 4 logic early, so when it lands fully later, it feels like confirmation not surprise
- No product mention yet

---

## SCREEN 5: Lifestyle Context

- **Kind:** Step
- **Progress bar:** ~17%

---

**Title (24px, bold):**
> What does a typical week look like for you?

**Subtitle (16px, secondary grey):**
> This helps us understand the kinds of outfits your closet actually needs to produce.

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- Mostly working from home
- Mix of office and home
- In an office or workplace most days
- Lots of social events and going out
- Mostly home / retired / not working right now
- All of the above — my week is chaos

**Design notes:**
- This feels practical, not probing — she's giving context, not being judged
- "My week is chaos" is validation-first language — she'll smile at that option

---

## SCREEN 6: Current Relationship with Her Closet

- **Kind:** Step
- **Progress bar:** ~21%

---

**Title (24px, bold):**
> When you open your closet in the morning, what usually happens?

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- I try on 3–5 things and go back to the same ones
- I know immediately there's nothing to wear
- I stare at it for a while, then give up
- I have a few things I always reach for and ignore the rest
- I actually feel pretty good about my options *(rare — we see maybe 8% say this)*

**Design notes:**
- Options 1–4 are all Closet Paralytic responses — she's in familiar territory no matter what she clicks
- Option 5 exists for credibility. Real quizzes allow for the "no problem" answer.
- Every option clicked adds to her Hidden Outfit Score calculation (displayed later)

---

## SCREEN 7: Wardrobe Usage Estimate

- **Kind:** Step
- **Progress bar:** ~25%

---

**Title (24px, bold):**
> Roughly how much of your wardrobe do you wear regularly?

**Subtitle (16px, secondary grey):**
> "Regularly" = at least once a month

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- Almost all of it
- About half
- Maybe a third
- About 20% or less — there's a lot I never touch
- I genuinely don't know

**Design notes:**
- The national average is 20% — most women will click "20% or less" or "a third"
- This builds the evidence for her Hidden Outfit Score: the more she leaves unworn, the higher her score

---

## SCREEN 8: The Mirror Moment — Interstitial

- **Kind:** Step — interstitial (no question)
- **Progress bar:** ~29%

---

**Visual:** Warm cream background. Large pink quotation marks. Pull-quote style.

**Copy block (22px, charcoal italic):**
> *"I'd try on 5 things, hate all of them, and end up in the same jeans and a black top. Every. Single. Morning."*

**Small label below quote:**
> Sound familiar? That's what 73% of women with full closets tell us.

**Below that, body copy (18px):**
> Here's what's actually happening:
>
> You're not running out of clothes.
>
> **You're running out of outfits you can see.**
>
> The rest of your closet is invisible — not because the clothes are bad, but because you have no system for putting them together.

**CTA Button:**
> `That's exactly it — keep going →`

---

**Design notes:**
- This is the first deep mirror moment. She should feel caught — in the best way.
- The quote uses HER words (from voice research): "5 things," "same jeans," "every single morning"
- The reframe is introduced here, lightly. It'll land harder in Stage 4.

---

## SCREEN 9: Outfit Repetition Frequency

- **Kind:** Step
- **Progress bar:** ~33%

---

**Title (24px, bold):**
> How often do you wear the same outfit combinations?

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- I rotate the exact same 5–6 combos
- I have maybe 10–12 combos I cycle through
- I mix it up more than I should — but nothing feels quite right
- I honestly don't know — I just grab things and hope for the best
- I have a solid range — genuinely happy with my variety *(rare)*

**Design notes:**
- "Cycle through" and "grab things and hope for the best" are her language
- Each answer maps to a score range displayed on results screen

---

## SCREEN 10: The Tags-On Clothes Question

- **Kind:** Step
- **Progress bar:** ~37%

---

**Title (24px, bold):**
> Do you have clothes in your closet with the tags still on?

**Subtitle (16px, secondary grey):**
> Things you bought but never actually wore

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- Yes — several items
- Yes — one or two things
- I've worn everything at least once
- I have things I bought with good intentions and never touched

**Design notes:**
- "Good intentions and never touched" is distinct from "tags still on" — catches the women whose tags came off but the items still live on the hanger unused
- Both answers add to the Hidden Outfit Score

---

## SCREEN 11: The Likert Block 1 — "I have things I bought hoping to figure out how to wear them"

- **Kind:** Step — Likert scale
- **Progress bar:** ~40%

---

**Title (22px, bold):**
> "I have things in my closet I bought hoping I'd figure out how to wear them someday."

**Question Type:** 5-point agreement scale (horizontal, labelled)

```
Strongly        Disagree      Not        Agree      Strongly
Disagree                      Sure                  Agree
   O              O            O           O            O
```

**Behaviour:** Auto-advances on selection.

**Design notes:**
- This is a confession question. Almost everyone clicks Agree or Strongly Agree.
- The "someday" framing is her exact internal language

---

## SCREEN 12: The Likert Block 2 — Morning Getting Dressed

- **Kind:** Step — Likert scale
- **Progress bar:** ~43%

---

**Title (22px, bold):**
> "Getting dressed in the morning sometimes ruins my mood before my day has even started."

**Question Type:** 5-point agreement scale (same format)

**Behaviour:** Auto-advances on selection.

**Design notes:**
- This escalates from "inconvenience" to "it affects my day"
- The Closet Paralytic knows this is true. Seeing it written down is validating AND clarifying.

---

## SCREEN 13: The Likert Block 3 — Avoidance

- **Kind:** Step — Likert scale
- **Progress bar:** ~46%

---

**Title (22px, bold):**
> "There are events or occasions I've felt anxious about — partly because I didn't know what to wear."

**Question Type:** 5-point agreement scale (same format)

**Behaviour:** Auto-advances on selection.

**Design notes:**
- This is the cost-expansion pivot: closet paralysis isn't just morning friction, it's social avoidance
- Most women in this archetype have avoided a party, dinner, or event because they couldn't figure out what to wear. This question names that.

---

## SCREEN 14: The Likert Block 4 — Shopping Guilt

- **Kind:** Step — Likert scale
- **Progress bar:** ~50%

---

**Title (22px, bold):**
> "I've bought new clothes to solve the 'nothing to wear' feeling — and it didn't actually fix it."

**Question Type:** 5-point agreement scale (same format)

**Behaviour:** Auto-advances on selection.

**Design notes:**
- This is the key paradox of the Closet Paralytic: she keeps buying to solve the problem, and the problem keeps existing
- Strongly agree here is the most powerful response — she's confirmed the cycle herself

---

## SCREEN 15: Cost Expansion — Time

- **Kind:** Step
- **Progress bar:** ~54%

---

**Title (24px, bold):**
> In an average week, how much time do you spend dealing with the "nothing to wear" problem?

**Subtitle (16px, secondary grey):**
> Include time trying things on, standing at your closet, shopping, or just feeling stuck

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- Less than 15 minutes
- 15–30 minutes
- 30 minutes to an hour
- Over an hour
- I try not to think about it

**Design notes:**
- "I try not to think about it" is an extremely common response — validated, not judged
- This data feeds the "120+ hours per year" stat on the results screen

---

## SCREEN 16: Cost Expansion — Money

- **Kind:** Step
- **Progress bar:** ~58%

---

**Title (24px, bold):**
> Have you ever bought something new because you felt like you had nothing to wear — and then barely worn it?

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- Yes — this happens pretty often
- Yes — it's happened a few times
- Once or twice, but I'm aware of it now
- No — I'm pretty disciplined about shopping
- I avoid shopping altogether because of this

**Design notes:**
- "I avoid shopping altogether" captures a segment of Closet Paralytics who've overcorrected — this feeds into the results framing
- All "yes" variants confirm the financial cost of the visibility problem

---

## SCREEN 17: Multi-Select — The Frustrations

- **Kind:** Step — multi-select
- **Progress bar:** ~62%

---

**Title (24px, bold):**
> Which of these frustrations do you recognize? *(Select all that apply)*

**Question Type:** Multi-select checkboxes, list layout

**Answer Options:**
- [ ] Walking out in my "whatever, fine" outfit and feeling bad all day
- [ ] Having a closet full of clothes and still buying the same boring basics
- [ ] Seeing an outfit I love on someone else and knowing it won't look the same on me
- [ ] Buying something specifically for one event and never wearing it again
- [ ] Feeling frumpy even when I've made an effort
- [ ] Not knowing how to make what I already own work together
- [ ] Getting compliments on an outfit and having no idea how to recreate it
- [ ] Dreading getting dressed for anything that isn't jeans

**Behaviour:** Multi-select. "Next" button appears after at least one selection. User selects all that apply.

**Design notes:**
- "Frumpy" is word #1 from the voice research — it must appear here
- "Whatever, fine" is her exact internal language
- Most women in this archetype will check 5–7 items. Every checked item adds to her score.

---

## SCREEN 18: Cost Expansion Interstitial

- **Kind:** Step — interstitial (no question)
- **Progress bar:** ~65%

---

**Visual:** Warm cream background, charcoal bold stats, pink accent for numbers.

**Headline (26px, bold):**
> Here's what this adds up to.

**Body copy (18px, with stat callouts in pink):**
> The average woman spends **120+ hours a year** standing at a full closet feeling stuck.
>
> That's 5 full days.
>
> She has **$2,000 worth of clothes she doesn't wear** — not because they're bad, but because she can't see how to put them together.
>
> And she still doesn't feel put-together most days.

**Below that, reframe copy (20px, bold italic, pink):**
> *This is not a taste problem.*
> *This is not a budget problem.*
> *This is a visibility problem.*

**CTA Button:**
> `I want to fix this →`

---

**Design notes:**
- Stats from context doc: 120+ hours, $2,000 in unworn clothes
- The reframe language ("visibility problem") is used for the second time — it's becoming familiar
- The CTA button is identity-driven: "I want to fix this" = she's already decided

---

## SCREEN 19: Hope Injection — The Reframe

- **Kind:** Step — interstitial (no question)
- **Progress bar:** ~69%

---

**Visual:** Warm cream with subtle warm gradient. Centred. Slightly slower, more considered energy than previous screens.

**Headline (30px, bold):**
> Your closet already has the outfits.
> You just can't see them yet.

**Body copy (18px):**
> Women who took this quiz with a similar closet profile discovered an average of **47 outfit combinations** they didn't know they had.
>
> Not new purchases.
>
> **Combinations from what they already own.**
>
> The system that reveals them takes about 10 minutes to set up. After that, it works every day.

**Small caption (14px, secondary grey):**
> We're calculating your Hidden Outfit Score now. A few more questions to personalize it.

**CTA Button:**
> `See my score →`

---

**Design notes:**
- "47 outfit combinations" is the first specific number — it anchors the score she's about to receive
- "Not new purchases" does critical work here — this is NOT a shopping app
- The anticipation for the score is set here — she's been told it's coming

---

## SCREEN 20: What She's Missing Most

- **Kind:** Step
- **Progress bar:** ~73%

---

**Title (24px, bold):**
> What do you miss most about getting dressed?

**Subtitle (16px, secondary grey):**
> Pick the one that hits hardest.

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- Feeling like myself when I walk out the door
- Getting dressed quickly and feeling confident
- Actually enjoying the process — it used to be fun
- Getting compliments and knowing exactly what I was wearing
- Having a "thing" — a style that felt like me

**Design notes:**
- Every option is about identity, not appearance
- "Feeling like myself" is her exact language (from context doc)
- This screen personalizes the results page copy — the answer she selects becomes the #1 benefit surfaced at paywall

---

## SCREEN 21: What She's Tried Before

- **Kind:** Step
- **Progress bar:** ~77%

---

**Title (24px, bold):**
> Have you tried solving this before?

**Subtitle (16px, secondary grey):**
> Select everything you've tried

**Question Type:** Multi-select checkboxes

**Answer Options:**
- [ ] Pinterest / Instagram for outfit ideas
- [ ] Buying new things hoping they'd fix it
- [ ] A big closet clean-out
- [ ] Following a "capsule wardrobe" approach *(usually works for about 2 weeks)*
- [ ] Asking a friend or partner for help
- [ ] Nothing — I've mostly just lived with it
- [ ] A wardrobe app that required me to catalogue everything *(abandoned it)*

**Behaviour:** Multi-select. "Next" button. Stored for results page "what you've already tried" section.

**Design notes:**
- "Capsule wardrobe" appears here because she's tried it — but we immediately editorialize "(usually works for about 2 weeks)" to pre-validate why it failed
- The options she selects tell us which "why Outfit Formulas is different" angle to lead with on the results screen

---

## SCREEN 22: Name Capture

- **Kind:** Step — text input
- **Progress bar:** ~81%

---

**Title (24px, bold):**
> What's your first name?

**Subtitle (16px, secondary grey):**
> We use this to personalize your Hidden Outfit Score.

**Question Type:** Text input field (first name only)

**Placeholder text:** `Your first name`

**CTA Button:** `Calculate My Score →`

**Behaviour:** Stores `{{firstName}}`. Used in score reveal, paywall headline, and CTA button. Auto-advances on button tap.

**Design notes:**
- Single-field. No last name. No friction.
- The CTA ("Calculate My Score") makes this feel like the final step before results — which it is

---

## SCREEN 23: Score Loading Screen

- **Kind:** Step — interstitial (loading animation)
- **Progress bar:** ~85%

---

**Visual:** Warm cream background. Animated progress ring in pink (#FF2A6D). Centred.

**Above the ring:**
> Calculating {{firstName}}'s Hidden Outfit Score...

**Animated copy lines (appear sequentially, staggered 1.5s apart):**
> ✓ Analyzing your closet habits...
> ✓ Mapping your wardrobe patterns...
> ✓ Counting your hidden outfit combinations...
> ✓ Calculating your personalization profile...

**Below ring (appears after 3s):**
> Your score is ready.

**Auto-advance:** After 5–6 seconds. No button needed.

**Design notes:**
- The loading screen does psychological work: it implies complex, personalized calculation
- The sequential text items name the specific dimensions she answered about — she recognizes her own data being processed
- Progress ring fills slowly to 100% — creates anticipation

---

## SCREEN 24: Hidden Outfit Score — Results Reveal

- **Kind:** Custom HTML results screen (full-screen)
- **Progress bar:** Complete (hidden on this screen)

---

**Visual layout:** Warm cream background. Large score visual, centred. Pink (#FF2A6D) accent.

**Pre-headline (small caps, pink):**
> {{firstName}}'s HIDDEN OUTFIT SCORE

**Score visual (large, bold, 72–80px, charcoal):**
```
47
```
**Label beneath score (20px, secondary grey):**
> outfit combinations hiding in your closet right now

**Score interpretation bar:**
```
LOW          AVERAGE          HIGH
 10    20    30    40    [47]    60    70    80+
                              ▲
                    {{firstName}}'s Score
```
*(Pink dot marker at her score position)*

**Copy block below score (18px, charcoal):**
> Your score is based on how much of your wardrobe you're actually using, how often you repeat outfits, and how many items you own but aren't putting together.
>
> A score of 47 means you have **47 outfit combinations** sitting in your closet right now that you've never worn together.
>
> They're not missing. They're just invisible.

**Below that, insight callout (pink card, white text):**
> **What this means for you:**
> With the right system, you could go from your current 5–6 regular outfits to 47+ options — without buying a single new item.

**CTA Button (full-width, pink, bold):**
> `See how to unlock them →`

---

**Design notes:**
- Score number is personalized based on her answers — women who indicated lower wardrobe usage, more repetition, and more tags-on items get higher scores (more hidden outfits = more to unlock)
- The score is always framed positively: higher score = more treasure, not more failure
- The score bar anchors her in the "high" range — she's not average, her situation is richer than most

---

## SCREEN 25: Testimonial + Social Proof

- **Kind:** Step — interstitial
- **Progress bar:** None (post-results, pre-paywall)

---

**Visual:** Warm cream background. Stacked testimonial cards.

**Headline (26px, bold):**
> Women just like you. Before and after.

**Testimonial cards (3, stacked, each with star rating and first name + brief descriptor):**

---

> ⭐⭐⭐⭐⭐
> *"I had a closet stuffed with clothes and got dressed in the same black jeans every single day. I thought I just had bad taste. Turns out I had 60 outfits I'd never tried. Now I actually look forward to opening my closet."*
> — **Sarah M.**, 42, Marketing Director

---

> ⭐⭐⭐⭐⭐
> *"I spent years feeling frumpy even when I made an effort. What changed wasn't buying new things — it was finally understanding which pieces I already owned actually worked together. I feel like myself again for the first time in years."*
> — **Jen K.**, 38, mom of two

---

> ⭐⭐⭐⭐⭐
> *"I was about to do a massive haul because I was convinced I just didn't have the right clothes. The quiz showed me I had a full wardrobe I wasn't using. I haven't bought anything new in three months and I've gotten more compliments than ever."*
> — **Diane R.**, 51, teacher

---

**Social proof stat line (14px, secondary grey, centred):**
> 4.8 stars · 147,000+ women have unlocked their hidden outfits · Featured in Real Simple, InStyle, Good Housekeeping

**CTA Button (full-width, pink):**
> `Unlock my {{firstName}}'s outfits →`

---

**Design notes:**
- Testimonials use her language: "frumpy," "same black jeans," "feel like myself again"
- No physical transformation language — identity and confidence only
- Ages span 38–51 to signal this works across the Closet Paralytic's life stage range

---

## SCREEN 26: Email Capture

- **Kind:** Step — text input (email)
- **Progress bar:** None (post-results flow)

---

**Visual:** Warm cream background, centred.

**Pre-headline (small, pink):**
> YOUR OUTFIT FORMULA PLAN IS BEING PREPARED

**Title (26px, bold):**
> Where should we send your outfit formula guide?

**Body copy (16px, secondary grey):**
> We'll also send you a summary of your Hidden Outfit Score and the 3 fastest outfit formulas to try this week — from what you already own.

**Input field:**
> `Your email address`

**CTA Button (full-width, pink, bold):**
> `Send my guide →`

**Fine print (12px, grey):**
> We never sell your data. Unsubscribe anytime.

---

**Design notes:**
- The email is framed as delivery, not marketing — she's getting something
- "From what you already own" is repeated here — constant de-shopping reassurance
- This email is used for follow-up sequences if she doesn't convert at paywall

---

## SCREEN 27: PAYWALL — SMARTYME ARCHITECTURE
### Countdown Discount Timer + Hybrid Trial (10-Minute Window)

- **Kind:** Custom HTML paywall screen (full-screen, warm cream background, pink accents)
- **Paywall Architecture:** SmartyMe — Countdown discount + trial hybrid
- **Checkout URL:** `https://app.outfitformulas.com/checkout/hidden-score`

---

### STICKY URGENCY HEADER (pinned to top, pink background #FF2A6D, white text)

```
⏱ Your Hidden Outfit Score offer expires in: [09:47]   |   782 women discovered hidden outfits this hour
```

- Countdown ticks in real time (MM:SS format)
- Pink background (#FF2A6D), white bold text, full-width
- Live ticker updates every 30 seconds with a number in the 740–820 range (random variation)

---

### RED URGENCY BANNER (below sticky header, warm red background)

```
🔥 SPECIAL OFFER: 51% off unlocked by completing your quiz — expires with the timer above
```

---

### HEADLINE SECTION

**Pre-headline (small caps, pink):**
> {{firstName}}, YOUR SCORE IS READY

**Main Headline (36px, bold, charcoal):**
> **You have 47 outfits hiding in your closet.**
> **Let's go find them.**

**Sub-headline (18px, secondary grey):**
> Outfit Formulas shows you exactly which pieces you already own work together — and gives you a daily outfit to wear so you never stand at a full closet feeling stuck again.
>
> 782 women discovered their hidden outfits this hour. Your turn.

---

### WHAT YOU GET (feature list, icon + text)

**Section header (20px, bold):**
> Here's what unlocks when you start:

**Feature list (icon cards, 2-column on mobile):**
- 🗂️ **Hidden Outfit Reveal** — See all the outfit combinations in your current wardrobe
- 📅 **Daily Outfit Suggestions** — A new put-together outfit every morning, from what you own
- 🧩 **Formula-Based Dressing** — Learn the formulas so you can create outfits yourself, fast
- ✨ **Closet Audit Tool** — Find out which pieces are earning their space and which aren't
- 💬 **Stylist-Level Guidance** — The same approach personal stylists charge $1,500–$4,000 for

---

### PLAN SELECTOR (interactive cards)

**Section header:** `Choose your plan — discount applied automatically:`

**Urgency sub-copy (pink, small):**
> This price is held for the duration of your countdown. After the timer expires, standard pricing applies.

---

**PLAN CARD 1 — 1-Week Trial** *(unselected by default)*

```
┌──────────────────────────────────────────────────┐
│  TRY IT FIRST                                     │
│                                                   │
│  1-Week Trial                                     │
│  $0.99 for 7 days                                 │
│  Then $9.99/month — cancel anytime               │
│                                                   │
│  ✓ Full access to all features                   │
│  ✓ Cancel before day 7 and pay nothing more      │
│  ✓ Outfit Formulas for an entire week, risk-free │
└──────────────────────────────────────────────────┘
```

---

**PLAN CARD 2 — 1-Month Plan** *(pre-selected, pink border glow)*

```
┌──────────────────────────────────────────────────┐
│  ⭐ MOST POPULAR                                  │
│                                                   │
│  1-Month Plan                                     │
│  ~~$19.99~~ → $9.99/month                        │
│  Just $0.33/day                                   │
│                                                   │
│  ✓ Full access for a full month                  │
│  ✓ Daily outfit suggestions every morning        │
│  ✓ Cancel anytime                                │
└──────────────────────────────────────────────────┘
```

---

**PLAN CARD 3 — 3-Month Plan** *(unselected)*

```
┌──────────────────────────────────────────────────┐
│  🏆 BEST VALUE                                    │
│                                                   │
│  3-Month Plan                                     │
│  $19.99 billed every 3 months                    │
│  Just $0.22/day                                   │
│                                                   │
│  ✓ Full access for 3 months                      │
│  ✓ People using Outfit Formulas for 3 months     │
│    save $1,200 in impulse clothing purchases     │
│  ✓ Cancel anytime                                │
└──────────────────────────────────────────────────┘
```

---

### PRIMARY CTA BUTTON (large, full-width, pink #FF2A6D, bold white text)

```
[ Unlock My Hidden Outfits →        ]
```

*Sub-copy beneath button (14px, grey):* "Secure checkout. Cancel anytime. 30-day money-back guarantee."

---

### SAVINGS PROOF LINE

**Bold callout (18px, charcoal, pink accent on number):**
> People using Outfit Formulas for 3 months **save $1,200 in impulse clothing purchases** — that's 120× the cost of the app.

---

### LIVE SOCIAL PROOF TICKER

```
🟢 782 women discovered hidden outfits this hour
```
*(Updates every 30 seconds: number varies between 740–820)*

---

### SECURITY & TRUST BADGES

**Badge row (horizontal, centre-aligned):**
```
[🔒 SSL Secure]  [✓ Cancel Anytime]  [🛡️ 30-Day Guarantee]  [⭐ 4.8 Stars]
```

---

### TESTIMONIALS (3, stacked or carousel)

> ⭐⭐⭐⭐⭐
> *"I found outfits I'd had for years and never put together. It felt like going shopping in my own closet."*
> — **Amanda L.**, 44

> ⭐⭐⭐⭐⭐
> *"I got dressed in 5 minutes this morning and felt put-together for the first time in months. Worth every penny."*
> — **Clare T.**, 37

> ⭐⭐⭐⭐⭐
> *"I was going to spend $400 on new clothes because I 'had nothing to wear.' Outfit Formulas showed me I had 60 outfits. I kept my money."*
> — **Rachel G.**, 49

---

### 30-DAY MONEY-BACK GUARANTEE (stamp seal visual)

```
┌────────────────────────────────────────────────┐
│  🛡️ 30-DAY MONEY-BACK GUARANTEE               │
│                                                 │
│  Try Outfit Formulas for 30 days.              │
│  If you haven't found hidden outfits in your   │
│  closet — outfits you actually want to wear —  │
│  we'll refund every penny.                     │
│                                                 │
│  No hoops. No questions. Your closet.          │
│  Your call.                                    │
└────────────────────────────────────────────────┘
```

*(Styled as a circular stamp seal — warm cream background, pink border, bold centre text)*

---

### COUNTDOWN FOOTER (sticky, always visible while scrolling)

```
⏱ Offer expires in [09:47]   [ Unlock My Hidden Outfits → ]
```

- Full-width sticky bar at bottom of viewport
- Pink (#FF2A6D) background, white text
- CTA button triggers checkout with pre-selected plan

---

**Design notes for Screen 27:**
- The countdown + social proof ticker are the twin urgency engines — time pressure + social FOMO
- The 1-week trial at $0.99 exists to reduce the "but what if it doesn't work for me" objection — low barrier entry
- The 3-month plan's "$1,200 savings" claim is the ROI anchor — makes the price comparison irrational
- The guarantee stamp seal must look like a real seal (circular, textured) — it's a trust visual, not just copy
- Score personalization carries through: "You have 47 outfits hiding in your closet" in the headline
- Background remains warm cream — we never switch to dark/aggressive. This app is a warm, knowing friend.
- **Paywall model: SMARTYME (countdown discount + trial hybrid)**

---

# FUNNEL A: SCREEN SUMMARY

| Screen | Type | Purpose |
|--------|------|---------|
| 1 | Entry node | Platform routing |
| 2 | Landing + single-choice | Entry + self-identification |
| 3 | Single-choice list | Age demographic |
| 4 | Interstitial | Early trust + reframe seed |
| 5 | Single-choice list | Lifestyle context |
| 6 | Single-choice list | Closet relationship |
| 7 | Single-choice list | Wardrobe usage % |
| 8 | Interstitial | Deep mirror moment |
| 9 | Single-choice list | Outfit repetition frequency |
| 10 | Single-choice list | Tags-on clothes |
| 11 | Likert (5-point) | Agreement barrage #1 |
| 12 | Likert (5-point) | Agreement barrage #2 |
| 13 | Likert (5-point) | Agreement barrage #3 |
| 14 | Likert (5-point) | Agreement barrage #4 |
| 15 | Single-choice list | Time cost |
| 16 | Single-choice list | Money cost |
| 17 | Multi-select | Frustrations mirror |
| 18 | Interstitial | Cost expansion stats |
| 19 | Interstitial | Hope injection + score preview |
| 20 | Single-choice list | What she misses most |
| 21 | Multi-select | What she's tried |
| 22 | Text input (name) | Personalization capture |
| 23 | Loading interstitial | Score anticipation |
| 24 | Custom HTML results | Score reveal |
| 25 | Interstitial | Testimonials + social proof |
| 26 | Text input (email) | Email capture |
| 27 | Custom HTML paywall | SmartyMe architecture |

**Total: 27 screens** ✅

---
---
---

# FUNNEL B: "Complete Style Assessment"
## Unimeal Paywall Architecture — The Weight Waiter
**Target Archetype:** The Weight Waiter
**Quiz Length:** 37 screens
**Paywall:** Unimeal — No visible paywall in quiz. Email gate after results. Separate pricing page.

---

# WHY THIS FUNNEL WORKS FOR THE WEIGHT WAITER

## The Core Insight

The Weight Waiter has the deepest shame of any archetype. She's not just frustrated with her closet — she's made a deal with herself. A promise. "When I lose the weight, THEN I'll dress well. Then I'll buy the nice things. Then I'll look the way I want to look."

She's been keeping this bargain for years. Sometimes decades.

The funnel cannot attack this bargain. It cannot tell her she's wrong to want to lose weight. It cannot be preachy, body-positive in the performative sense, or suggest she give up on her goals. She will close the tab immediately.

What it can do — what it must do — is **expose the cost of the bargain**. Because the bargain isn't free. Every year she waits is a year she shows up to her life feeling invisible, frumpy, and like a version of herself she doesn't recognize. The bargain is costing her the very confidence she's waiting to earn back.

The funnel's job:
1. Explore her wardrobe history so thoroughly she feels completely understood
2. Expose the behavior pattern — the waiting, the denial clothes, the "when I lose weight" items — without judgment
3. Surface the cost: she's already lost years of feeling good while waiting
4. Land the reframe: "You're not waiting to lose weight to dress well. You're dressing badly because you're waiting."
5. Show her that dressing for the body she has RIGHT NOW is the path forward — not the consolation prize
6. Build so much sunk cost through a 37-screen investment that abandoning now feels like walking away from herself

The email gate after results is the conversion mechanism. By screen 37, she's already started. The email is the bridge to her plan.

---

## Stage-by-Stage Psychology Breakdown

### Stage 1 — Deep Trust Building (Screens 2–10)
**What it does:** Establishes deep rapport through demographic and lifestyle questions before any emotionally loaded territory.

**Why it works for the Weight Waiter specifically:**

The Weight Waiter is on guard. She's been sold "dress for your body type!" programs, "confidence regardless of size!" articles, and preachy "love your body!" content that felt like it was talking at her, not to her.

The opening of this funnel is deliberately, almost aggressively, non-threatening. Age. Lifestyle. How long she's had her current wardrobe. What her shopping habits used to look like.

But here's what each screen is really doing: it's building a portrait. By screen 10, she's told us how long she's been in this pattern, what her body has been through, and how her relationship with clothes shifted. She's given us the map of her waiting behavior — without realizing she's describing it.

The 37-screen length is intentional and structural. Every screen is another investment. Another question answered. By the time the emotional questions arrive in Stage 2, she's already spent 15 minutes with us. Leaving feels like loss.

---

### Stage 2 — The Behavior Mirror (Screens 11–18)
**What it does:** Names the specific behaviors of the Weight Waiter — the denial clothes, the "when I lose weight" section of the closet, the avoiding events — without labeling or judging them.

**Why it works:**

The Weight Waiter's behaviors are specific and recognizable:
- She has clothes in her closet that "will fit when she loses weight" — she can't throw them away because throwing them away feels like giving up
- She's been wearing the same rotating items for years — functional, invisible, not hers
- She shops reluctantly if at all — buying for "right now" feels like accepting defeat
- She's declined invitations, avoided photos, worn safe neutrals — not because she doesn't care about how she looks, but because she cares so much and feels so stuck

When the quiz names these behaviors without judgment — just "does this sound familiar?" — she feels seen in a way she never has been. Not judged. Not fixed. Just seen.

This is where the 37-screen investment really compounds. She's not just answering questions. She's being heard.

---

### Stage 3 — The True Cost (Screens 19–25)
**What it does:** Quantifies what the waiting has actually cost her — in time, in events missed, in years of feeling invisible.

**Why it works:**

The Weight Waiter has been so focused on the future body that she hasn't added up the cost of waiting. How many years? How many events? How much time getting dressed while feeling bad?

This stage does the math for her. Gently. Without blame. Just: "This is what the waiting has cost you so far."

Then it asks the most important question in the funnel: "If nothing changes, how many more years would you wait?"

Most women type in a number. That number is devastating. And freeing. It's the first time she's made the waiting concrete instead of indefinite.

---

### Stage 4 — The Reframe (Screens 26–31)
**What it does:** Introduces the central reframe: the waiting is the cause of the problem, not the solution. Dressing for right now is not giving up on her goals — it's the thing that makes the rest of her life better while she pursues them.

**Why it works for the Weight Waiter specifically:**

The reframe must be delivered carefully. Not "give up on losing weight." Not "love your body at any size." Just: "You deserve to feel put-together RIGHT NOW. You don't have to earn it."

This is the conceptual shift that makes everything else possible. If dressing well right now is not a betrayal of her goals — if it's actually independent of them — then she can begin today. She doesn't need to wait for a different body. She needs a different system.

The reframe arrives after Stage 3 has made the cost of waiting undeniable. She's ready to hear it.

---

### Stage 5 — Plan Architecture + Future Cast (Screens 32–36)
**What it does:** Builds her personalized style plan, shows her what's possible, and creates the anticipation for results delivery.

**Why it works:**

By Stage 5, she's invested 37 screens into understanding herself. The plan architecture questions feel like the payoff of that investment. She's telling us what she wants to wear, how she wants to feel, what occasions matter to her.

The results preview is specifically designed for the Weight Waiter: it's not about how she'll look. It's about how she'll feel. Walking into a room feeling present instead of invisible. Getting dressed in the morning without dread. Showing up to events instead of declining them.

The email gate feels like receiving, not buying. She's earned these results. She wants them sent to her.

---

### Stage 6 — Email → Pricing Page (Separate)
**What it does:** Email gate collects her address and triggers redirect to a standalone pricing page. The quiz never felt like a sales funnel. The pricing page is framed as "your plan is ready."

**Why it works for the Weight Waiter specifically:**

The Weight Waiter has the longest decision cycle of any archetype. She doesn't make impulsive purchases. She considers. She second-guesses.

The Unimeal architecture honors this by:
- Never showing a paywall during the quiz (zero commercial pressure for 37 screens)
- Framing the email as plan delivery, not email capture
- Landing on a pricing page that says "Your plan is ready" — not "Buy now"
- Using her 37-screen investment as sunk-cost leverage: she's already started. This is just the next step.

---

## The Central Conversion Mechanism

The quiz is the funnel. There is no separate sales pitch. By the time the pricing page appears, she has:

1. Spent 20–25 minutes answering 37 deeply personal questions about her relationship with clothes and her body (Stage 1–2)
2. Seen her own behavior pattern named and understood (Stage 2)
3. Quantified the cost of waiting — in years, events, identity (Stage 3)
4. Received the reframe that makes acting now feel like care for herself, not giving up on her goals (Stage 4)
5. Built a personalized style plan for her specific life (Stage 5)
6. Entered her email to receive the plan (Stage 6)

The pricing page doesn't ask her to buy something. It asks her to access what she's already built.

---

# THE COMPLETE 37-SCREEN FUNNEL

---

## SCREEN 1: Start (Entry Node)

- **Kind:** Start (invisible entry node)
- **Notes:** Automatically transitions to Screen 2. No visible content. Platform handles routing.

---

## SCREEN 2: Landing / Primary Self-ID

- **Kind:** Step — Landing page + primary entry question
- **Progress bar:** None (first screen)

---

**VISUAL ELEMENTS:**

- **Top badge:** `COMPLETE STYLE ASSESSMENT` — pill/badge, pink fill, white text
- **Headline (large, 36–40px, bold, charcoal):**
  > **FIND OUT WHY GETTING DRESSED**
  > **FEELS SO COMPLICATED RIGHT NOW**

- **Subheadline (18px, secondary grey):**
  > A complete assessment of your style, your wardrobe, and what's been getting in the way. Takes about 7 minutes. Completely personal.

- **Badge:** `⏱ 7-MINUTE ASSESSMENT · 147,000+ WOMEN HAVE STARTED` — centred

- **Trust line:**
  > No judgment. No shopping required. Just honest answers.

---

**QUESTION TYPE:** Single-choice, list layout

**Question text (20px, bold):**
> Which of these describes your relationship with getting dressed right now?

**Answer Options (auto-advance):**
- I'm waiting until my body changes to start dressing the way I want
- I wear functional, safe clothes and avoid thinking about style
- My weight has changed and I don't know how to dress my body anymore
- I used to care about how I dressed, but that version of me feels far away
- I feel frumpy even when I make an effort

**Behaviour:** Auto-advances on click. Response stored for deep personalization.

**Footer text:** By continuing you agree to our Terms of Use and Privacy Policy.

---

**DESIGN NOTES:**
- All answer options reflect a version of the Weight Waiter or adjacent experience
- This is NOT a fitness quiz. No mention of weight loss goals on this screen.
- Warm cream background, friendly and non-clinical

---

## SCREEN 3: Age

- **Kind:** Step
- **Progress bar:** ~3%

---

**Title (24px, bold):**
> How old are you?

**Subtitle (16px, secondary grey):**
> Style patterns shift at different life stages. We build your assessment around yours.

**Answer Options (auto-advance, list):**
- Under 30
- 30–39
- 40–49
- 50–59
- 60+

---

## SCREEN 4: Body Change History

- **Kind:** Step
- **Progress bar:** ~6%

---

**Title (24px, bold):**
> Has your body changed significantly in the last few years?

**Subtitle (16px, secondary grey):**
> This helps us understand your relationship with your current wardrobe.

**Answer Options (auto-advance, list):**
- Yes — I've gained weight
- Yes — my weight has fluctuated a lot
- Yes — my body shape changed even without major weight change *(hormones, age, pregnancy)*
- Not significantly — but I've never quite felt at home in my body
- My body hasn't changed much, but my relationship with it has

**Design notes:**
- Critically: gaining weight is listed first, normalized, not highlighted differently from other options
- "Never quite felt at home in my body" catches the women who identify with the Weight Waiter emotionally even if their weight hasn't changed dramatically
- NO language about losing weight yet

---

## SCREEN 5: Early Interstitial — You're Not Alone

- **Kind:** Step — interstitial
- **Progress bar:** ~8%

---

**Visual:** Warm cream, centred text, pink accent.

**Headline (26px, bold):**
> You're not the only one who answered that way.

**Body copy (18px):**
> Most women who take this assessment describe a moment when getting dressed shifted from something they enjoyed to something they just... got through.
>
> It usually happens gradually. Life changes. Your body changes. Your priorities change. And somewhere in there, getting dressed stopped being yours.
>
> **This assessment is about figuring out exactly when and why — and what to do about it.**

**CTA Button (full-width, pink):**
> `That resonates — keep going →`

---

## SCREEN 6: Lifestyle Context

- **Kind:** Step
- **Progress bar:** ~11%

---

**Title (24px, bold):**
> What does a typical week look like for you?

**Answer Options (auto-advance, list):**
- Mostly working from home
- In an office or workplace most days
- Mix of both
- Primarily home — kids, caregiving, or not working right now
- Retired or semi-retired
- My week is completely different every week

---

## SCREEN 7: Current Wardrobe Description

- **Kind:** Step
- **Progress bar:** ~14%

---

**Title (24px, bold):**
> How would you describe most of the clothes you actually wear day-to-day?

**Answer Options (auto-advance, list):**
- Mostly comfortable and functional — not really "outfits"
- A few things I rotate because they work and I don't have to think
- A mix of things I like and things that are just fine
- Honestly I'm not sure — I just wear whatever fits and I can find
- I have things I love but I rarely reach for them

**Design notes:**
- "Fits and I can find" is her language — it implies the Weight Waiter is dressing around her body, not for it
- "Things I love but rarely reach for" surfaces the denial clothes category

---

## SCREEN 8: The Closet Composition Question

- **Kind:** Step
- **Progress bar:** ~16%

---

**Title (24px, bold):**
> Does any part of your closet contain clothes that "will fit when you lose weight"?

**Answer Options (auto-advance, list):**
- Yes — there's a whole section
- Yes — a few specific items I've held onto
- There were — I eventually got rid of them
- No — I try to dress for where I am now
- I don't really think of it that way, but maybe...

**Design notes:**
- This is the first direct naming of the "when I lose weight" clothing pattern
- The question is matter-of-fact, not judgmental — "does any part" is gentle framing
- Every "yes" variant deepens the Weight Waiter profile and will feed the results framing

---

## SCREEN 9: The Hope Closet Section

- **Kind:** Step
- **Progress bar:** ~19%

---

**Title (24px, bold):**
> How do you feel when you see those "someday" clothes in your closet?

*(Appears only if previous screen answer was a "yes" variant. If "no," skip to Screen 10.)*

**Answer Options (auto-advance, list):**
- Motivated — they remind me of my goal
- Guilty — I feel bad every time I see them
- A mix of both
- Mostly I've stopped looking at them
- Sad — they feel like someone I used to be

**Design notes:**
- This is a deeply honest question with deeply honest answers — all of them valid
- "Someone I used to be" is the weight of the archetype: the Weight Waiter mourns a past self
- Answers here feed the results page emotional framing

---

## SCREEN 10: Current Shopping Habits

- **Kind:** Step
- **Progress bar:** ~22%

---

**Title (24px, bold):**
> How often do you shop for clothes right now?

**Answer Options (auto-advance, list):**
- Rarely or never — it doesn't feel worth it right now
- Only when I absolutely have to
- Occasionally, but I don't enjoy it much
- I shop but I'm not sure what I'm looking for
- Regularly — it's something I like doing

**Design notes:**
- "It doesn't feel worth it right now" is the core Weight Waiter shopping stance — shopping for a body she's in the middle of changing feels wasteful or defeatist
- This data feeds results section on the financial cost of avoidance

---

## SCREEN 11: Last Time She Felt Good Getting Dressed

- **Kind:** Step
- **Progress bar:** ~24%

---

**Title (24px, bold):**
> When was the last time you got dressed and actually felt good — really felt like yourself?

**Answer Options (auto-advance, list):**
- Within the last month
- A few months ago
- About a year ago
- Several years ago
- I can't remember the last time

**Design notes:**
- This question begins Stage 2 — the behavior mirror
- "I can't remember" is devastating and common — naming it without judgment is powerful
- The answer to this question determines the urgency framing on the results page

---

## SCREEN 12: The Interstitial — Naming the Pattern

- **Kind:** Step — interstitial
- **Progress bar:** ~27%

---

**Visual:** Warm cream, centred, slightly slower pace.

**Headline (26px, bold):**
> There's a pattern here.

**Body copy (18px, charcoal):**
> Most women who answer the way you just did describe a version of the same thing:
>
> They're waiting.
>
> Waiting for a different body before they dress the way they actually want.
>
> It doesn't feel like a conscious decision. It just feels like common sense.
> *"When I lose the weight, then it'll be worth it."*
>
> We want to ask you about that. Not to challenge it.
> Just to understand it better.

**CTA Button (full-width, pink):**
> `OK — I'm listening →`

---

**Design notes:**
- This is the first time the quiz directly names the waiting pattern
- The framing is curious, not confrontational: "we want to understand it"
- "It doesn't feel like a conscious decision" — this is crucial. She doesn't see herself as stuck. She sees herself as sensible.

---

## SCREEN 13: How Long She's Been Waiting

- **Kind:** Step
- **Progress bar:** ~30%

---

**Title (24px, bold):**
> Have you been putting your style on hold — waiting for something to change first?

**Answer Options (auto-advance, list):**
- Yes — I'm actively waiting to lose weight before I "invest" in my wardrobe
- Yes — something else has felt like it needed to happen first
- It's more that I've just stopped thinking about it
- I used to be in that pattern but I'm trying to move past it
- Not really — I dress for where I am now

---

## SCREEN 14: How Long — Duration

- **Kind:** Step
- **Progress bar:** ~32%

*(Appears if Screen 13 answer is a "yes" variant)*

**Title (24px, bold):**
> Roughly how long have you been in this "waiting" pattern?

**Answer Options (auto-advance, list):**
- Less than a year
- 1–2 years
- 3–5 years
- More than 5 years
- Honestly, I've always been waiting for something

**Design notes:**
- "Always been waiting" hits hardest and is more common than expected
- Duration feeds the "cost of waiting" calculation on results page
- Every year is surfaced as a year of feeling less than her best

---

## SCREEN 15: The Denial Clothes Question

- **Kind:** Step
- **Progress bar:** ~35%

---

**Title (24px, bold):**
> Have you avoided buying new clothes — even things you needed — because buying them felt like "giving up"?

**Answer Options (auto-advance, list):**
- Yes — buying clothes in my current size feels like accepting it permanently
- Yes — I buy the bare minimum and tell myself it's temporary
- Sometimes, but I've mostly stopped thinking about it that way
- Not really — I buy what I need
- I've thought about it but I try to push past it

**Design notes:**
- "Accepting it permanently" is HER exact internal language
- "Temporary" is the other key word: the Weight Waiter lives in the temporary, always one diet away from her "real" life
- This question does the most to name the paradox: by refusing to buy, she's actively choosing to feel bad

---

## SCREEN 16: Events Declined or Dreaded

- **Kind:** Step
- **Progress bar:** ~38%

---

**Title (24px, bold):**
> Has not knowing what to wear — or feeling bad about how you look — ever stopped you from going somewhere or doing something?

**Answer Options (auto-advance, list):**
- Yes — I've declined invitations specifically because of this
- Yes — I've gone but spent the whole time feeling bad about what I was wearing
- Yes — I've avoided being in photos
- More than one of these apply to me
- Not really — I manage

**Question Type:** Single-choice OR multi-select (can be multi-select for this screen)

**Design notes:**
- "Avoiding photos" is one of the most visceral specifics for this archetype — she'll recognize it immediately
- This screen escalates the cost of waiting from "daily discomfort" to "actual life missed"
- Multi-select version allows her to confirm multiple ways the pattern has affected her

---

## SCREEN 17: Likert Block 1 — The "When I Lose Weight" Internal Script

- **Kind:** Step — Likert scale
- **Progress bar:** ~40%

---

**Title (22px, bold):**
> "I've told myself 'when I lose weight, then I'll dress the way I actually want.'"

**Question Type:** 5-point agreement scale

```
Strongly        Disagree      Not        Agree      Strongly
Disagree                      Sure                  Agree
   O              O            O           O            O
```

**Behaviour:** Auto-advances on selection.

**Design notes:**
- This is the Weight Waiter's defining internal script, verbatim
- Seeing it written down — and agreeing with it — is both relief (someone gets it) and clarity (I've been doing this)

---

## SCREEN 18: Likert Block 2 — The Real Cost

- **Kind:** Step — Likert scale
- **Progress bar:** ~43%

---

**Title (22px, bold):**
> "There are versions of myself I've missed out on — confident, put-together, present — because I was waiting to feel ready."

**Question Type:** 5-point agreement scale (same format)

**Behaviour:** Auto-advances on selection.

**Design notes:**
- This is the emotional heart of Stage 2
- "Versions of myself I've missed out on" is identity language, not appearance language
- Most women in this archetype will Strongly Agree — and sit with that for a moment

---

## SCREEN 19: Likert Block 3 — The Frumpy Feeling

- **Kind:** Step — Likert scale
- **Progress bar:** ~46%

---

**Title (22px, bold):**
> "Even when I make an effort, I often end up feeling frumpy — like the outfit didn't come together the way I hoped."

**Question Type:** 5-point agreement scale (same format)

---

## SCREEN 20: Likert Block 4 — Invisible

- **Kind:** Step — Likert scale
- **Progress bar:** ~49%

---

**Title (22px, bold):**
> "I sometimes feel invisible — like I've faded into the background in a way that's hard to explain."

**Question Type:** 5-point agreement scale (same format)

**Design notes:**
- "Invisible" and "faded" are direct words from the archetype research
- This is the deepest emotional confirmation of Stage 2 — she's not just frustrated with clothes, she's feeling like she's disappeared

---

## SCREEN 21: Interstitial — Cost Expansion

- **Kind:** Step — interstitial
- **Progress bar:** ~51%

---

**Visual:** Warm cream background, pink stat accents.

**Headline (26px, bold):**
> What this waiting has actually cost you.

**Body copy (18px):**
> The average woman who describes her situation the way you have has been in some version of this pattern for **3–5 years**.
>
> That's 3–5 years of:
> - Getting dressed in the morning and feeling bad before the day starts
> - Events attended in "whatever, fine" outfits
> - Photos avoided
> - Compliments not received
>
> Not because she didn't deserve to feel good.
>
> **Because she was waiting for the right moment.**
>
> The right moment is not coming. The right moment is now.

**CTA Button (full-width, pink):**
> `I hear that →`

---

**Design notes:**
- This is the cost calculation — Stage 3 in full
- The list format is stark and deliberate: each item is a real thing she's lost
- "The right moment is not coming" is the pivoting sentence — firm but not cruel

---

## SCREEN 22: The Multi-Select Cost Inventory

- **Kind:** Step — multi-select
- **Progress bar:** ~54%

---

**Title (24px, bold):**
> Which of these have you experienced? *(Select all that apply)*

**Question Type:** Multi-select checkboxes

**Answer Options:**
- [ ] Turned down an invitation because I didn't know what to wear
- [ ] Worn something that made me feel bad all day because it was the "best" option
- [ ] Bought something for a specific occasion and never worn it again
- [ ] Felt frumpy at an event and couldn't stop thinking about it
- [ ] Avoided being in photos or stepped to the back of group shots
- [ ] Spent money on clothes that are sitting unworn because I was "going to figure out how to wear them"
- [ ] Had the thought "I'll deal with my wardrobe once I've lost the weight"
- [ ] Worn the same 3–5 outfits for the last year or more

**Behaviour:** Multi-select. "Next" button appears after at least one selection.

**Design notes:**
- This is the mirror at full resolution — she sees her entire pattern laid out
- Every item she checks is a micro-commitment: "Yes, this is my experience. This is real."
- The last item is the most emotionally loaded — many women will pause at "I'll deal with my wardrobe once I've lost the weight"

---

## SCREEN 23: Financial Cost of Avoidance

- **Kind:** Step
- **Progress bar:** ~57%

---

**Title (24px, bold):**
> When you do shop, how do you typically feel about the experience?

**Answer Options (auto-advance, list):**
- I dread it — nothing looks right, so I grab what fits and leave
- I shop online and return most of it
- I only shop when I have to — for a specific event or need
- I sometimes enjoy it but usually feel discouraged
- I genuinely enjoy shopping and feel good about it *(rare at this point in the funnel)*

**Design notes:**
- This feeds the financial cost calculation: avoidant shoppers tend to buy poorly when they do shop — wrong sizes, wrong fits, items that don't integrate with their wardrobe

---

## SCREEN 24: The "If Nothing Changes" Question

- **Kind:** Step
- **Progress bar:** ~59%

---

**Title (24px, bold):**
> If nothing changes — if the pattern continues — how long would you be comfortable waiting?

**Subtitle (16px, secondary grey):**
> Be honest with yourself. There's no wrong answer.

**Answer Options (auto-advance, list):**
- Until I've lost the weight — however long that takes
- A few more months
- I don't want to wait anymore, honestly
- I'm not sure — I've just been going along with it
- I hadn't really thought about it as a "waiting" pattern until now

**Design notes:**
- This is the most psychologically important question in the funnel
- "Until I've lost the weight — however long that takes" is the answer that most directly leads to the reframe
- "I hadn't thought about it as a waiting pattern" is a breakthrough response — this is someone who's just had a realization

---

## SCREEN 25: Interstitial — The Reframe Arrival

- **Kind:** Step — interstitial
- **Progress bar:** ~62%

---

**Visual:** Slightly richer design — soft warm background, larger centred copy, more white space. This is the emotional peak.

**Pre-headline (small caps, pink):**
> HERE'S WHAT WE KNOW ABOUT YOUR SITUATION

**Headline (28px, bold):**
> You're not dressing badly because you're waiting to lose weight.
>
> **You're dressing badly because you're waiting.**

**Body copy (20px, charcoal, slower rhythm):**
> Those are different things.
>
> One is about your body.
>
> The other is about a decision you made — probably without fully realizing it — to put your style on pause until you arrived at a body that felt "right."
>
> Here's what that decision costs:
>
> Every morning you get dressed in something that doesn't feel like you.
> Every event you show up to feeling invisible.
> Every time you look in the mirror and don't recognize the woman looking back.
>
> That's not because you haven't lost the weight yet.
>
> That's because you don't have a system for dressing the body you have right now.
>
> **And that system? You can build it today.**

**CTA Button (full-width, pink):**
> `I want that system →`

---

**Design notes:**
- This is the central conversion screen. Maximum white space. Slower copy pace.
- "You're not dressing badly because you're waiting to lose weight. You're dressing badly because you're waiting." — this is the key reframe, verbatim as specified in the brief
- The CTA "I want that system" converts intent into identity

---

## SCREEN 26: What Dressing Well Right Now Would Mean

- **Kind:** Step
- **Progress bar:** ~65%

---

**Title (24px, bold):**
> If you started dressing for your body as it is right now — what would that actually change for you?

**Subtitle (16px, secondary grey):**
> Pick the one that matters most.

**Answer Options (auto-advance, list):**
- I'd actually look forward to getting dressed in the morning
- I'd feel more confident in everyday situations — work, running errands, seeing people
- I'd stop dreading events and start showing up as myself
- I'd stop feeling invisible
- I'd feel like myself again — like that version of me that used to exist

**Design notes:**
- Every option is identity language: "feel like myself," "stop feeling invisible," "show up as myself"
- Zero appearance language — no mention of looking thinner, better, more attractive
- The answer she selects becomes the primary benefit language on the pricing page

---

## SCREEN 27: The Body She Has Right Now

- **Kind:** Step
- **Progress bar:** ~68%

---

**Title (24px, bold):**
> What's your relationship with your body like right now — honestly?

**Subtitle (16px, secondary grey):**
> There's no right answer here. Just yours.

**Answer Options (auto-advance, list):**
- I'm actively trying to change it and that's my focus
- I've made a sort of peace with it, but I don't love it
- I mostly avoid thinking about it
- It's complicated — some days better than others
- I'm genuinely working on accepting it as it is

**Design notes:**
- This question does not require her to accept her body or abandon her goals
- It simply asks for her truth — and every answer is honored in the results
- "I'm actively trying to change it" is valid and not challenged — the reframe is about dressing, not body goals

---

## SCREEN 28: What Kind of Outfits She Actually Needs

- **Kind:** Step
- **Progress bar:** ~70%

---

**Title (24px, bold):**
> What kinds of outfits do you most need to feel put-together in your life?

**Subtitle (16px, secondary grey):**
> Select all that apply

**Question Type:** Multi-select checkboxes

**Answer Options:**
- [ ] Everyday outfits — running errands, working from home, being a person
- [ ] Work-appropriate — meetings, office, professional situations
- [ ] Going out — dinners, events, occasions
- [ ] Weekend / casual — relaxed but still feels like me
- [ ] Specific situation: I need to figure out [a trip / a reunion / a job]

**Design notes:**
- This is Stage 5 — plan architecture building begins
- Her selections feed the "Your personalized plan includes" section on the pricing page
- Real, practical, non-fashion-industry language

---

## SCREEN 29: Colors and What She Reaches For

- **Kind:** Step
- **Progress bar:** ~73%

---

**Title (24px, bold):**
> When you get dressed, what do you usually reach for?

**Answer Options (auto-advance, list):**
- Mostly neutrals — black, grey, navy, beige
- A mix of neutrals and some color
- I love color but I'm not sure how to make it work
- I wear what fits and doesn't draw attention
- It changes with my mood — no consistent pattern

**Design notes:**
- "Doesn't draw attention" is Weight Waiter language — she's dressing to disappear
- This data personalizes the formula recommendations (color guidance)

---

## SCREEN 30: Her Wardrobe Size Estimate

- **Kind:** Step
- **Progress bar:** ~76%

---

**Title (24px, bold):**
> How much clothing do you actually have?

**Subtitle (16px, secondary grey):**
> Include everything — even the stuff you never wear

**Answer Options (auto-advance, list):**
- Very little — a small wardrobe, deliberately
- A moderate amount — a normal-sized closet
- Quite a lot — more than I regularly use
- A lot — my closet is full, some of it I haven't touched in years
- I genuinely don't know — I try not to look too hard

**Design notes:**
- "I try not to look too hard" — this is avoidance language specific to the Weight Waiter
- Wardrobe size feeds the "how many hidden outfits" calculation in results

---

## SCREEN 31: What She's Already Tried

- **Kind:** Step
- **Progress bar:** ~78%

---

**Title (24px, bold):**
> Have you tried to solve this before?

**Subtitle (16px, secondary grey):**
> Select everything you've tried

**Question Type:** Multi-select checkboxes

**Answer Options:**
- [ ] Pinterest or Instagram for style inspiration *(helpful but never quite works for my body)*
- [ ] A big wardrobe clear-out or declutter
- [ ] Buying new things hoping they'd help
- [ ] Following style advice for "your body type"
- [ ] A styling app that required me to photograph everything I own *(abandoned)*
- [ ] I haven't really tried anything — I've just been waiting
- [ ] A capsule wardrobe approach *(lasted about 2 weeks)*

**Design notes:**
- "Style advice for your body type" — the Weight Waiter has often received this advice and it stings; naming it validates why those approaches failed
- "I haven't really tried anything — I've just been waiting" is her most honest answer if she's deep in the pattern

---

## SCREEN 32: Interstitial — Why Those Approaches Failed

- **Kind:** Step — interstitial
- **Progress bar:** ~81%

---

**Visual:** Warm cream, simple.

**Headline (24px, bold):**
> Here's why those approaches didn't stick.

**Body copy (18px):**
> Pinterest gives you inspiration for bodies and lifestyles that aren't yours.
>
> Body type advice tells you what to hide — not what to wear.
>
> Clear-outs feel productive but don't solve the "what do I put together" problem.
>
> None of them give you **formulas**. Repeatable combinations. A system that works on your body, with your clothes, for your actual life.
>
> That's what we're building in your assessment.

**CTA Button:**
> `Keep building my plan →`

---

## SCREEN 33: The Goal — How She Wants to Feel

- **Kind:** Step
- **Progress bar:** ~83%

---

**Title (24px, bold):**
> In your ideal version of getting dressed — how do you feel walking out the door?

**Subtitle (16px, secondary grey):**
> Pick what matters most

**Answer Options (auto-advance, list):**
- Like myself — recognizably me
- Put-together without having tried too hard
- Confident that I look good in what I'm wearing
- Like I made an actual choice, not just grabbed whatever
- Like I have my act together — even if everything else is chaotic

**Design notes:**
- Every option is identity/feeling language — zero appearance/attractiveness language
- "Like I have my act together" resonates with moms, professionals, anyone managing a complex life
- This answer becomes headline language on the pricing page

---

## SCREEN 34: Commitment Question

- **Kind:** Step
- **Progress bar:** ~86%

---

**Title (24px, bold):**
> How much time would you spend, per day, if it meant getting dressed in 5 minutes and feeling good?

**Answer Options (auto-advance, list):**
- 5 minutes or less
- 5–10 minutes
- 10–15 minutes
- Whatever it takes — I'm ready to actually fix this
- I'm not sure I'm ready to commit yet, but I'm curious

**Design notes:**
- "Whatever it takes" is the highest-commitment response — flag for stronger CTA on pricing page
- "Not sure yet but curious" is still a conversion — the curiosity is the opening

---

## SCREEN 35: Name Capture

- **Kind:** Step — text input
- **Progress bar:** ~88%

---

**Title (24px, bold):**
> What's your first name?

**Subtitle (16px, secondary grey):**
> We use this to personalize your style assessment results.

**Question Type:** Text input (first name only)

**Placeholder:** `Your first name`

**CTA Button:** `Finish my assessment →`

---

## SCREEN 36: Style Assessment Loading Screen

- **Kind:** Step — interstitial (loading animation)
- **Progress bar:** ~92%

---

**Visual:** Warm cream. Animated progress ring in pink. Centred.

**Above ring:**
> Building {{firstName}}'s personalized style assessment...

**Sequential loading copy (staggered):**
> ✓ Reviewing your wardrobe profile...
> ✓ Mapping your style obstacles...
> ✓ Identifying your hidden outfits...
> ✓ Calculating your formula matches...
> ✓ Building your personalized plan...

**Below ring (after 4s):**
> Your assessment is complete.

**Auto-advance:** After 6–7 seconds.

---

## SCREEN 37: Results Reveal — Email Gate

- **Kind:** Custom HTML results screen + email capture
- **Progress bar:** Complete

---

**Visual layout:** Warm cream background. Assessment summary card. Pink accents. Clean, warm, non-clinical.

**Pre-headline (small caps, pink):**
> {{firstName}}'S COMPLETE STYLE ASSESSMENT

**Headline (30px, bold, charcoal):**
> Here's what your assessment found.

---

**ASSESSMENT SUMMARY CARD (styled card, cream background, pink border):**

```
┌─────────────────────────────────────────────────────┐
│  {{firstName}}'s Style Profile                       │
│                                                      │
│  Pattern identified: Wardrobe-on-hold               │
│                                                      │
│  Years in waiting pattern: [calculated from Q14]    │
│                                                      │
│  Outfits you're not using: [calculated from Q30]    │
│                                                      │
│  Primary obstacle: [from Q13 answer]                │
│                                                      │
│  What dressing well means to you: [from Q26 answer] │
│                                                      │
│  Your most-needed formula type: [from Q28 answer]   │
└─────────────────────────────────────────────────────┘
```

---

**Below card, body copy (18px):**
> {{firstName}}, you've been waiting.
>
> Not because you don't care about how you look — you care deeply. But because somewhere along the way, dressing well became conditional on something that hasn't happened yet.
>
> **That ends today.**
>
> Your personalized style plan — built from your answers — includes outfit formulas for your actual body, your actual life, and your actual wardrobe.
>
> We're ready to send it to you.

---

**BLURRED PREVIEW (2–3 insights teased, partially revealed):**
```
┌──────────────────────────────────────────────┐
│  🔒 Your 3 most versatile outfit formulas... │
│       [BLURRED PREVIEW — unlock to see]     │
│                                              │
│  🔒 The 5 items in your wardrobe doing...   │
│       [BLURRED PREVIEW — unlock to see]     │
│                                              │
│  🔒 Your morning routine shortcut...        │
│       [BLURRED PREVIEW — unlock to see]     │
└──────────────────────────────────────────────┘
```

---

**EMAIL GATE — below preview:**

**Gate headline (20px, bold):**
> Enter your email to unlock your complete style plan.

**Sub-copy (16px, grey):**
> We'll send your full assessment plus your first 3 outfit formulas — ready to try tomorrow morning.

**Email input field:**
> `Your email address`

**CTA Button (full-width, pink, bold):**
> `Send my style plan →`

**Fine print (12px, grey):**
> We never sell your data. Unsubscribe anytime. No spam — just your plan.

---

**Design notes:**
- The email gate is framed as plan delivery, not marketing capture
- The blurred preview creates genuine curiosity — she can see there's something there, she just can't read it
- "Ready to try tomorrow morning" makes the promise immediate and practical
- Email click triggers redirect to standalone pricing page

---

## PRICING PAGE (Separate URL — Accessed After Email Capture)

**URL:** `https://app.outfitformulas.com/plan/style-assessment`

**Page framing:** "Your plan is ready" — this is NOT a paywall. It's the delivery of something she's already built.

---

### PAGE HEADLINE SECTION

**Pre-headline (small caps, pink):**
> {{firstName}}, YOUR STYLE PLAN IS READY

**Main Headline (36px, bold, charcoal):**
> **You've done the hard part.**
> **Your outfit formulas are waiting.**

**Sub-headline (18px, secondary grey):**
> Based on your assessment, we've built a personalized formula system for your wardrobe, your body, and your life as it is RIGHT NOW.
>
> Choose your plan to unlock it.

---

### BEFORE / AFTER BLOCK (emotional, non-physical)

**Section header (20px, bold):**
> What changes when you stop waiting.

**Two-column card layout:**

```
┌─────────────────────────┐  ┌─────────────────────────┐
│  WITHOUT OUTFIT          │  │  WITH OUTFIT             │
│  FORMULAS               │  │  FORMULAS                │
│                         │  │                          │
│  ☹ Dressing in          │  │  ✓ 5-minute mornings.   │
│    "whatever, fine"     │  │    Outfit chosen.        │
│    every morning        │  │    Done.                 │
│                         │  │                          │
│  ☹ Feeling frumpy       │  │  ✓ Walking out feeling   │
│    even when you tried  │  │    like yourself         │
│                         │  │                          │
│  ☹ Invisible at         │  │  ✓ Present. Seen.        │
│    events               │  │    Actually there.       │
│                         │  │                          │
│  ☹ Waiting for a        │  │  ✓ Dressing for the      │
│    different body to    │  │    body you have.        │
│    start living         │  │    Starting today.       │
└─────────────────────────┘  └─────────────────────────┘
```

---

### SAVINGS PROJECTION

**Highlighted stat block (pink card, white text, centred):**
> The average woman wastes **$2,000/year on unworn clothes.**
>
> Your formula system stops the cycle — because when you know what works, you stop buying things that don't.
>
> Outfit Formulas pays for itself by the second month.

---

### PLAN CARDS

**Section header:** `Choose your plan:`

---

**PLAN CARD 1 — Monthly** *(pre-selected — "most popular")*

```
┌──────────────────────────────────────────────────┐
│  ⭐ MOST POPULAR                                  │
│                                                   │
│  Monthly Plan                                     │
│  $9.99/month                                      │
│  Just $0.33/day                                   │
│                                                   │
│  ✓ Full access to your personalized formulas     │
│  ✓ Daily outfit suggestions                      │
│  ✓ Cancel anytime                                │
└──────────────────────────────────────────────────┘
```

---

**PLAN CARD 2 — Annual** *(unselected)*

```
┌──────────────────────────────────────────────────┐
│  🏆 BEST VALUE — SAVE 58%                         │
│                                                   │
│  Annual Plan                                      │
│  $49.99/year ($4.17/month)                        │
│  Just $0.14/day                                   │
│                                                   │
│  ✓ Everything in Monthly, for the whole year     │
│  ✓ Best option if you're serious about this      │
│  ✓ Cancel anytime                                │
└──────────────────────────────────────────────────┘
```

---

**PLAN CARD 3 — Weekly** *(unselected)*

```
┌──────────────────────────────────────────────────┐
│  TRY IT FIRST                                     │
│                                                   │
│  Weekly Plan                                      │
│  $4.99/week                                       │
│                                                   │
│  ✓ Full access for one week                      │
│  ✓ Lowest commitment — perfect if you want       │
│    to try before you commit                      │
└──────────────────────────────────────────────────┘
```

---

### PRIMARY CTA BUTTON (large, full-width, pink)

```
[ Unlock My Style Plan →                           ]
```

*Sub-copy beneath:* "Secure checkout. Cancel anytime. 147,000+ women have already started."

---

### SUNK COST COPY BLOCK

**Callout (18px, charcoal, italic):**
> You've already done the hard part. You answered 37 questions about your wardrobe, your body, and what you actually want.
>
> Your plan is built. Your formulas are ready.
>
> All that's left is unlocking them.

---

### TESTIMONIALS (3, from Weight Waiter voices)

> ⭐⭐⭐⭐⭐
> *"I spent years telling myself I'd deal with my wardrobe 'once I've lost the weight.' I finally stopped waiting. I didn't need to lose weight — I needed to know how to dress the body I have. Outfit Formulas showed me how."*
> — **Linda M.**, 46

> ⭐⭐⭐⭐⭐
> *"I hadn't bought new clothes in 3 years because everything felt temporary. I feel like myself again for the first time in forever — and I didn't have to lose a pound to get there."*
> — **Trish K.**, 52

> ⭐⭐⭐⭐⭐
> *"I was invisible at my own family reunion. I'm done waiting. Outfit Formulas gave me outfits from what I already own — real outfits — and I feel like I actually showed up."*
> — **Debra S.**, 48

---

### GUARANTEE BLOCK

```
┌────────────────────────────────────────────────┐
│  🛡️ 30-DAY MONEY-BACK GUARANTEE               │
│                                                 │
│  Try Outfit Formulas for 30 days.              │
│  If you haven't found outfit formulas that     │
│  work for your body and your wardrobe —        │
│  we'll refund every penny.                     │
│                                                 │
│  No lectures. No conditions.                   │
│  Just your money back if it doesn't work.     │
└────────────────────────────────────────────────┘
```

---

### TRUST BADGES (horizontal row)

```
[🔒 SSL Secure]  [⭐ 4.8 Stars]  [✓ Cancel Anytime]  [🛡️ 30-Day Guarantee]
```

---

**Design notes for Pricing Page:**
- URL is never shown in quiz flow — transition to pricing page is framed as "sending your plan"
- NO countdown timer on pricing page — the Weight Waiter doesn't respond to artificial urgency; she responds to sunk cost and trust
- The before/after is ENTIRELY emotional and lifestyle-based: zero physical appearance language
- "Recommended for your profile" language could be added to the Monthly plan using her quiz data (e.g. "Based on your answers, we recommend starting with the Monthly plan")
- The sunk cost copy block ("you've already answered 37 questions") is the core Unimeal conversion mechanic — she's already started; this is just the next step
- Testimonials use the Weight Waiter's exact language: "waiting until," "felt like myself again," "stopped waiting"
- **Paywall model: UNIMEAL (no visible paywall in quiz, email gate, separate pricing page with sunk-cost framing)**

---

# FUNNEL B: SCREEN SUMMARY

| Screen | Type | Purpose |
|--------|------|---------|
| 1 | Entry node | Platform routing |
| 2 | Landing + single-choice | Entry + self-identification |
| 3 | Single-choice list | Age demographic |
| 4 | Single-choice list | Body change history |
| 5 | Interstitial | Early trust + pattern intro |
| 6 | Single-choice list | Lifestyle context |
| 7 | Single-choice list | Current wardrobe description |
| 8 | Single-choice list | Denial clothes detection |
| 9 | Single-choice list | Feelings about "someday" clothes *(conditional)* |
| 10 | Single-choice list | Shopping habits |
| 11 | Single-choice list | Last time she felt good |
| 12 | Interstitial | Pattern naming |
| 13 | Single-choice list | Waiting acknowledgment |
| 14 | Single-choice list | Waiting duration *(conditional)* |
| 15 | Single-choice list | Denial clothes / buying guilt |
| 16 | Single-choice / multi-select | Events declined or dreaded |
| 17 | Likert (5-point) | "When I lose weight" script |
| 18 | Likert (5-point) | Versions of self missed |
| 19 | Likert (5-point) | The frumpy feeling |
| 20 | Likert (5-point) | Feeling invisible |
| 21 | Interstitial | Cost expansion stats |
| 22 | Multi-select | Cost inventory mirror |
| 23 | Single-choice list | Shopping experience |
| 24 | Single-choice list | "If nothing changes" question |
| 25 | Interstitial | THE REFRAME (central) |
| 26 | Single-choice list | What dressing well right now means |
| 27 | Single-choice list | Relationship with body right now |
| 28 | Multi-select | Outfit types needed |
| 29 | Single-choice list | Colors + what she reaches for |
| 30 | Single-choice list | Wardrobe size estimate |
| 31 | Multi-select | What she's tried |
| 32 | Interstitial | Why those approaches failed |
| 33 | Single-choice list | Goal — how she wants to feel |
| 34 | Single-choice list | Time commitment |
| 35 | Text input (name) | Personalization capture |
| 36 | Loading interstitial | Assessment anticipation |
| 37 | Custom HTML results + email gate | Results reveal + email capture |
| — | Separate pricing page | Unimeal paywall (sunk-cost framing) |

**Total: 37 quiz screens + 1 pricing page** ✅

---

# SHARED DESIGN SYSTEM — BOTH FUNNELS

## Brand Application
- **Primary:** #FF2A6D (vibrant pink) — CTAs, accents, badge fills, stat callouts
- **Primary hover:** #E61559
- **Background:** #FFF8F5 (warm cream) — all screen backgrounds
- **Text primary:** #1E1E1E (charcoal)
- **Text secondary:** #6B6B6B (grey) — subtitles, labels, fine print
- **Font:** Inter (Google Fonts) — all sizes
- **Button style:** 12px border-radius, full-width, mobile-first
- **Cards:** Soft shadow, cream/white fill, pink border for selected/highlight states

## Voice Consistency Across Both Funnels

**Words always used:**
- "Full closet, nothing to wear"
- "Feel like myself again"
- "Put-together"
- "Your staples"
- "Frumpy"
- "Whatever, fine"
- "The same jeans"

**Words never used:**
- Capsule wardrobe
- Curated / curated essentials
- Elevated
- Effortless chic
- Slimming
- Age-appropriate
- Body type (as classification)
- Polished (use "put-together")
- Decision fatigue (use "that morning where nothing works")

## Pattern: Mirror → Validate → Shift → Promise → CTA
Every interstitial, every results screen, every paywall headline follows this pattern:
1. **MIRROR** — describe her exact experience
2. **VALIDATE** — she's not alone, she's not broken
3. **SHIFT** — reframe the problem
4. **PROMISE** — what changes with Outfit Formulas
5. **CTA** — clear, identity-driven action

---

*End of document. Funnel A: 27 screens (SmartyMe paywall). Funnel B: 37 screens + separate pricing page (Unimeal architecture).*
