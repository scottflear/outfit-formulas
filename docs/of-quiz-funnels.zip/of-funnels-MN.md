# Outfit Formulas — Quiz Funnels M & N

---

# FUNNEL M: "The 28-Day Style Reset Challenge"
## Keto Cycle Paywall — Conditional Refund + Content Preview

**Target:** Weight Waiter + Mom Ghost blend
**Paywall:** Keto Cycle — Conditional refund + content preview before purchase
**Quiz Length:** 28 screens
**Brand:** #FF2A6D pink, warm cream (#FFF8F5), Inter font

---

# WHY THIS FUNNEL WORKS FOR WEIGHT WAITERS AND MOM GHOSTS

## The Core Insight

The Weight Waiter and the Mom Ghost share one specific fear that overrides every other objection: *I've wasted money on this before and it didn't work.*

The Weight Waiter has spent years putting her style on hold. She keeps promising herself she'll "deal with it" when she loses the weight. She has bought things — hoping they'd be the outfit that finally made her feel good — and then watched them sit in bags on the closet floor, tags still on. Every purchase that didn't work is a stone in the pile of evidence she's building against herself.

The Mom Ghost has a different version of the same wound. She used to have a self. She used to know how to get dressed. She's not even sure she wants to invest in her appearance because the last time she tried — a shopping trip with her sister, a new dress for date night — she stood in the dressing room and cried. Not because she looked bad. Because she didn't recognize herself.

Both women have the same wall: *I want this to work. I'm terrified it won't.*

The Keto Cycle architecture dismantles that wall with one move: **make the refund conditional on using the product.** "Follow your outfit formulas for 28 days — if you're not satisfied, you get every dollar back." This is not a traditional money-back guarantee. A traditional guarantee says: try it and quit, get a refund. This says: *engage with the process* and if it still doesn't work, we'll refund you.

That distinction does two things simultaneously. It eliminates the financial risk that's blocking her. And it quietly commits her to the one behavior — daily outfit logging — that will hook her before day 28 ever arrives.

The "28-Day Challenge" framing does the rest. This isn't an app purchase. It's a **program**. She's not subscribing to software. She's enrolling in a challenge. Programs feel structured. Programs have endpoints. Programs feel like something you *do*, not something you *have*. For a woman who has been paralyzed by inaction, the promise of a clear 28-day arc is enormously compelling.

---

## Stage-by-Stage Psychology Breakdown

### Stage 1 — The History of Failed Attempts
**Screens 2–7: Entry + demographics + the backstory of style avoidance**

She needs to tell you about her history before she can trust you. Every question in this stage is an invitation to confess — not to a stranger, but to someone who already knows the answer. "Have you been waiting to deal with your wardrobe until something else changes first?" She clicks yes. Relief floods in. *You know.*

The demographic questions aren't neutral data collection. "How long have you been in your current 'I'll deal with it later' mode with your style?" is a mirror, not a survey. She doesn't have to admit anything — she just has to recognize herself.

By screen 7, she has articulated the problem herself. She's told you she's been waiting. She's told you about the money spent and the clothes unworn. The quiz hasn't judged her once. That's the entire setup for everything that follows.

### Stage 2 — The Real Cost of Waiting
**Screens 8–14: Mapping the daily damage**

Now we make the invisible visible. What does the waiting cost her, every single morning? We don't philosophize. We name specifics. The three-item pile of rejected outfits on the bed. The "I have nothing to wear" thought before a school pickup. The work presentation she dreaded because she couldn't find anything that felt like *her*.

The Likert agreement statements are designed to be undeniable. "Getting dressed takes more emotional energy than it should." She reads that and something unlocks. Yes. It does. It takes enormous emotional energy and she's been treating that as normal.

By screen 14, she has done the inventory. She knows exactly what it's costing her. The pain is no longer vague or abstract — it's the 15 minutes every morning, it's the plans she's almost canceled, it's the closet she closes as fast as possible.

### Stage 3 — Why Nothing Has Worked
**Screens 15–20: Dismantling the previous failures**

This is the most important stage. She has tried things before. Shopping sprees that didn't stick. Advice that didn't account for her actual life. Pinterest boards that made her feel worse about herself, not better. She has evidence that style help doesn't help *her* specifically.

We need to validate every failed attempt and then shift the diagnosis. The problem wasn't her. The problem was that every approach assumed she needed to *buy more* or *look different* or *change her body first*. None of them started with what she already owns. None of them built a repeatable system. None of them were designed for the life she actually has.

The reframe: **You don't have a style problem. You have a visibility problem.** You're sitting on a working wardrobe that you can't see.

### Stage 4 — The Challenge Frame
**Screens 21–25: Building commitment to the 28-day arc**

Now we introduce structure. The word "challenge" does specific psychological work here: it implies a finite, achievable arc with a measurable endpoint. "28 days to feel like yourself again" is not a vague promise. It's a program with a start date and an end date.

We ask her what her specific goal looks like at day 28. What would she be wearing? How would she feel getting dressed? We're not asking her to imagine a different body. We're asking her to imagine a different *morning*. That's achievable. She can see it.

The daily outfit formula becomes the mechanism. Five minutes a day. Open the app. Log what you wore. Get suggestions for tomorrow. 28 days of that and the habit is built.

### Stage 5 — Her Personalized Reset Plan
**Screens 26–28: Results reveal + name capture + email + paywall**

The results screen gives her a "28-Day Reset Plan" — a specific, personalized daily outfit formula schedule based on everything she told us. The plan is real and detailed and her. She can see Day 1. She can see the first week's arc. The closet audit results show her how many outfits are already hiding in what she owns.

The name and email capture happen before the paywall in the context of "unlocking your full plan." By the time she sees pricing, she has already personalized her experience. She's not buying an app. She's claiming the plan that was built for her.

---

## The Central Conversion Mechanism

The conditional refund is not a safety net — it's a **behavioral commitment device disguised as risk elimination.**

When she clicks "Start My 28-Day Reset," she is simultaneously:
1. Eliminating financial risk (if I log 28 days and hate it, I get my money back)
2. Committing to a 28-day daily habit (the exact behavior that will retain her)
3. Framing this as a program, not a subscription (lower mental resistance)
4. Seeing actual content before buying (the sample formulas and Day 1 plan remove uncertainty)

By day 28, the habit loop is complete. She gets dressed in 5 minutes. She knows her formulas. The refund offer technically exists — but she won't use it, because it worked.

---

# THE COMPLETE 28-SCREEN FUNNEL

---

## SCREEN 1: Start (Entry Node)
- **Kind:** Start (invisible entry node)
- **Notes:** Automatically transitions to Screen 2. No visible content.

---

## SCREEN 2: Landing / Entry Statement
- **Kind:** Step — Landing page with single-choice entry
- **Progress bar:** None

---

**VISUAL ELEMENTS:**

- **Top badge:** `28-DAY STYLE RESET QUIZ` — pill badge, #FF2A6D background, white text
- **Headline (36–40px, bold, #1E1E1E):**
  > **YOU HAVE A FULL CLOSET.**
  > **SO WHY DOES GETTING DRESSED FEEL LIKE THIS?**

- **Subheadline (18px, #6B6B6B):**
  > Answer 5 minutes of questions. We'll build your personalized 28-Day Style Reset Plan — using the clothes you already own.

- **Badge row:**
  > `⏱ 5-MINUTE QUIZ` · `147,000+ women have taken this quiz` · `As seen in Vogue · Real Simple · InStyle`

- **Social proof line (small, warm):**
  > "87% of women felt more confident getting dressed within 28 days."

---

**QUESTION TYPE:** Single-choice, 2-column grid

**Question text:** *(none — images act as entry)*

**Answer Options:**
- 🖼️ **I've been waiting** — woman looking at a full closet with the door half-open
- 🖼️ **I've stopped trying** — woman in a robe, coffee in hand, resigned expression

**Behaviour:** Auto-advances on click. Both options lead to the same path — the choice is emotional framing only, used to personalize copy later.

**Footer text (small, legal):**
> By continuing you agree to our Terms of Use and Privacy Policy.

---

**DESIGN NOTES:**
- Background: warm cream (#FFF8F5)
- The headline is a gut punch, not a promise. She recognizes herself before she answers anything.
- No mention of Outfit Formulas as a product yet.

---

## SCREEN 3: Age Selection
- **Kind:** Step
- **Progress bar:** ~5%

---

**Title (28px, bold):**
> How old are you?

**Subtitle (16px, #6B6B6B):**
> The outfit formulas we build for you are based on your actual life — not some 22-year-old influencer's morning routine.

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- Under 30
- 30–39
- 40–49
- 50–59
- 60+

**Design notes:**
- The subtitle addresses the "this isn't designed for me" objection before she forms it.

---

## SCREEN 4: The Waiting Question
- **Kind:** Step — emotional core question
- **Progress bar:** ~10%

---

**Title (28px, bold):**
> Have you been putting your style on hold — waiting for something to change first?

**Subtitle (16px, #6B6B6B):**
> Maybe weight. Maybe a new job. Maybe when things calm down.

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- Yes — I keep telling myself "when I lose the weight"
- Yes — I'm waiting until life is less busy
- Yes — I've been in survival mode for so long I forgot about it
- Not really — I just never figured out what works for me

---

**Design notes:**
- The first three options validate the Weight Waiter and Mom Ghost identities explicitly.
- "Survival mode" is a Mom Ghost mirror. "Waiting for the weight" is the Weight Waiter.
- No option here is wrong. All paths are valid. She feels seen, not diagnosed.

---

## SCREEN 5: The Closet Reality
- **Kind:** Step
- **Progress bar:** ~15%

---

**Title (28px, bold):**
> When you open your closet in the morning, what usually happens?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- I try on 3-5 things, hate all of them, go back to the same jeans
- I go straight to the same 5 things — everything else is invisible
- I feel overwhelmed before I even start
- I close it again and just grab whatever

---

**Design notes:**
- All four options describe versions of the same paralysis. She can't answer "wrong."
- "Everything else is invisible" is the product's core value proposition planted as her own words.

---

## SCREEN 6: Early Social Proof Interstitial
- **Kind:** Step — interstitial (no question)
- **Progress bar:** ~18%

---

**Content:**

**Headline (24px, bold, #FF2A6D):**
> You're not alone in this.

**Body copy (18px, #1E1E1E, centered):**
> 73% of women say they have "nothing to wear" — even with a full closet.
>
> The average woman wears only 20% of what she owns.
>
> That means **80% of your closet is invisible to you.**
>
> That's not a shopping problem. It's a visibility problem. And it's fixable.

**Progress note (small, warm, italic):**
> Keep going — we're building your Reset Plan as you answer.

**CTA button (full-width, #FF2A6D):**
> [ Continue → ]

---

## SCREEN 7: How Long Has This Been Going On?
- **Kind:** Step
- **Progress bar:** ~22%

---

**Title (28px, bold):**
> How long have you been in "I'll deal with my style later" mode?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- Less than a year
- 1–3 years
- 3–5 years
- More than 5 years
- Honestly, I can't remember a time when I wasn't

---

**Design notes:**
- "I can't remember" is the most validating option and will be selected by most Mom Ghosts.
- Each answer feeds into personalized copy in the results screen.

---

## SCREEN 8: The Money Conversation
- **Kind:** Step
- **Progress bar:** ~25%

---

**Title (28px, bold):**
> How much do you think you've spent on clothes that you barely wear?

**Subtitle (16px, #6B6B6B):**
> Be honest — we're not here to judge. We're here to fix it.

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- Probably a few hundred dollars
- Somewhere around $500–$1,000
- More than $1,000 — I try not to think about it
- A lot. I've bought things hoping they'd be "the thing" that worked.

---

**Design notes:**
- The last option is the gut-punch recognition moment for women who have bought in hope.
- This screen primes the "wasted money" fear that the conditional refund later directly addresses.

---

## SCREEN 9: The Daily Time Cost
- **Kind:** Step
- **Progress bar:** ~29%

---

**Title (28px, bold):**
> How much time do you spend dealing with the "nothing to wear" problem every morning?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- 5–10 minutes of trying things on
- 10–20 minutes — sometimes I'm almost late
- 20+ minutes, and I'm stressed for the rest of the morning
- I've started laying things out the night before just to avoid it

---

**Design notes:**
- The fourth option shows avoidance behavior — planning around the problem instead of solving it.
- All options will be fed into the "120 hours per year" calculation shown in the results.

---

## SCREEN 10: The Agreement Statements — Part 1
- **Kind:** Step — Likert scale
- **Progress bar:** ~32%

---

**Title (24px, bold):**
> Tell us how much you agree with this:

**Statement (20px, #1E1E1E, centered, italic):**
> *"Getting dressed takes more emotional energy than it should."*

---

**Question Type:** Single-choice Likert (5-point)

**Scale:**
- Strongly disagree
- Disagree
- Neutral
- Agree
- **Strongly agree** ← (most women will land here)

**Auto-advance on click.**

---

**Design notes:**
- This is a clinical-feeling screen. It validates by measuring, not by storytelling.
- "Emotional energy" is precisely chosen — not "time" or "effort" but emotional weight.

---

## SCREEN 11: The Agreement Statements — Part 2
- **Kind:** Step — Likert scale
- **Progress bar:** ~35%

---

**Statement (20px, centered, italic):**
> *"I've bought things hoping they'd fix the problem — and it still didn't work."*

**Question Type:** Single-choice Likert (5-point) — same scale as Screen 10.

---

**Design notes:**
- This statement explicitly names the failed-purchase pattern. The Weight Waiter and Mom Ghost both have this wound.
- Saying "Strongly Agree" is a micro-confession that unlocks the emotional need for a different kind of solution.

---

## SCREEN 12: The Agreement Statements — Part 3
- **Kind:** Step — Likert scale
- **Progress bar:** ~38%

---

**Statement (20px, centered, italic):**
> *"I feel like getting dressed used to be easier — or like I used to know who I was when I looked in the mirror."*

**Question Type:** Single-choice Likert (5-point) — same scale.

---

**Design notes:**
- This lands differently for the Weight Waiter (before the body changed / before the waiting started) versus the Mom Ghost (before she disappeared into motherhood).
- Both read it and feel something.

---

## SCREEN 13: The Agreement Statements — Part 4
- **Kind:** Step — Likert scale
- **Progress bar:** ~41%

---

**Statement (20px, centered, italic):**
> *"I've avoided situations — events, outings, photos — because I had nothing to wear or didn't feel like myself."*

**Question Type:** Single-choice Likert (5-point) — same scale.

---

**Design notes:**
- Avoidance behavior is the most concrete cost of style paralysis. Naming it directly surfaces the real stakes.
- "Photos" is specific and devastating — especially for moms who don't appear in family photos.

---

## SCREEN 14: Cost Expansion Interstitial
- **Kind:** Step — interstitial (no question)
- **Progress bar:** ~44%

---

**Headline (24px, bold, #1E1E1E):**
> Here's what this is actually costing you.

**Body copy (18px, line breaks for rhythm):**
> Not the clothes.
>
> Not the money (though that adds up too).
>
> It's the mornings. The events you almost skipped. The photos where you're not in the frame.
>
> The feeling that the woman you used to be — or the woman you want to be — is somewhere in that closet, and you just can't find her.
>
> **That's what we're going to fix.**

**CTA button (full-width, #FF2A6D):**
> [ I want to fix this → ]

---

**Design notes:**
- This is the emotional mid-point. The mirror has been held up. Now we turn toward hope.
- "The woman you used to be — or the woman you want to be" covers both the Weight Waiter (aspirational future self) and the Mom Ghost (identity loss).

---

## SCREEN 15: What Hasn't Worked
- **Kind:** Step — multi-select
- **Progress bar:** ~47%

---

**Title (28px, bold):**
> What have you already tried? (Select all that apply)

---

**Question Type:** Multi-select list + "Continue" button

**Answer Options:**
- Shopping trips that didn't fix anything
- Pinterest and Instagram for inspiration
- Advice from friends or family
- Capsule wardrobe articles or guides
- Trying to lose weight first
- Buying new basics / starting over
- Nothing — I gave up trying

---

**Design notes:**
- Every option represents a failed solution path that Outfit Formulas does NOT use.
- Multi-select creates maximum acknowledgment of her specific history.
- "Nothing — I gave up trying" is not a dead end — it's the deepest validation.

---

## SCREEN 16: The Failure Reframe
- **Kind:** Step — interstitial
- **Progress bar:** ~50%

---

**Headline (24px, bold, #FF2A6D):**
> None of those approaches were built for you.

**Body copy (18px, #1E1E1E):**
> Pinterest assumes you want to look like someone else.
>
> Capsule wardrobe advice assumes you have an office job and no kids.
>
> Waiting to lose weight assumes you can't look good right now. (You can.)
>
> And shopping more just adds to the pile of clothes you already don't wear.
>
> Here's the thing: **you don't have a wardrobe problem. You have a visibility problem.**
>
> You're sitting on 50+ outfits you've never seen.

**CTA button:**
> [ Show me those outfits → ]

---

**Design notes:**
- The "waiting to lose weight" line is a direct challenge to the Weight Waiter's core belief — delivered gently, without judgment.
- "50+ outfits you've never seen" is the product's value prop, stated as her reality, not our promise.

---

## SCREEN 17: Her Daily Life — Occasions
- **Kind:** Step — multi-select
- **Progress bar:** ~53%

---

**Title (28px, bold):**
> What kinds of outfits do you need most? (Select all that apply)

**Subtitle (16px, #6B6B6B):**
> We'll build your formula around your actual life.

---

**Question Type:** Multi-select list + "Continue" button

**Answer Options:**
- Everyday / casual (errands, school pickup, weekends)
- Work or professional situations
- Occasions and events (dinners, birthdays, celebrations)
- Comfortable but pulled-together
- Getting through the week without thinking about it
- Feeling like a person, not just a function

---

**Design notes:**
- "Getting through the week without thinking about it" and "Feeling like a person, not just a function" are Mom Ghost voice answers.
- "Occasions" is for the Weight Waiter who avoids events.
- These feeds the personalized plan in the results screen.

---

## SCREEN 18: What Would "Working" Feel Like?
- **Kind:** Step
- **Progress bar:** ~56%

---

**Title (28px, bold):**
> At the end of 28 days, what would make this feel worth it?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- Getting dressed in 5 minutes without stress
- Feeling like myself again — not just "fine"
- Stopping the "I have nothing to wear" loop for good
- Actually wearing more of what I own
- Feeling confident enough to stop canceling plans

---

**Design notes:**
- This is a future-cast question. She is selecting her desired outcome.
- Each answer becomes her personalized "goal" in the results screen.
- "Feeling like myself again" is the identity reframe for the Mom Ghost.
- "Stopping the loop for good" speaks to the Weight Waiter's exhaustion.

---

## SCREEN 19: The Challenge Commitment Screen
- **Kind:** Step — interstitial (high-impact)
- **Progress bar:** ~60%

---

**Headline (28px, bold, #FF2A6D):**
> What if 28 days could change how you start every morning?

**Body copy (18px, #1E1E1E):**
> Not forever. Not a "lifestyle overhaul."
>
> Just 28 days.
>
> One outfit formula suggestion per day. Five minutes. Log what you wore.
>
> By day 7, the closet starts to look different.
> By day 14, you've found things you forgot you owned.
> By day 28, getting dressed is something you look forward to.
>
> **That's the Reset.**

**Proof bar (small, warm):**
> "87% of women felt more confident getting dressed within 28 days."
> "Save 15+ minutes every morning."

**CTA button:**
> [ Build my 28-Day Plan → ]

---

**Design notes:**
- This screen makes the program arc tangible. Day 7, Day 14, Day 28 — specific milestones she can hold onto.
- The proof statistics are introduced here, before pricing, so they're part of the value story — not part of the sales pitch.

---

## SCREEN 20: Her Closet Right Now
- **Kind:** Step
- **Progress bar:** ~63%

---

**Title (28px, bold):**
> How would you describe your closet right now?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- Full of things I bought but never wear
- Mostly functional — the same things on repeat
- A mix of old and new things that don't really go together
- Mostly "mom clothes" — whatever won't get destroyed
- I genuinely don't know what's in there

---

**Design notes:**
- "Mostly 'mom clothes'" is the Mom Ghost verbatim.
- "I genuinely don't know" is the deeply disconnected Weight Waiter who has stopped engaging.
- Each answer personalizes the closet audit section of the results.

---

## SCREEN 21: Specific Frustrations — Multi-Select
- **Kind:** Step — multi-select
- **Progress bar:** ~66%

---

**Title (28px, bold):**
> What frustrates you most about getting dressed? (Select all that apply)

---

**Question Type:** Multi-select list + "Continue" button

**Answer Options:**
- I don't know how to put outfits together from what I own
- Everything feels like it belongs to a different version of me
- I buy things that look good in the store and never wear them
- I look at my closet and feel nothing — no inspiration, no ideas
- I don't know what actually works for my body right now
- I've lost track of who I am stylistically
- I feel invisible — like I've disappeared

---

**Design notes:**
- "A different version of me" is Weight Waiter.
- "I've lost track of who I am stylistically" and "I feel invisible" are both Mom Ghost.
- "My body right now" is gentle permission to acknowledge body changes without shame.
- The more she checks, the more she feels seen, the higher the commitment.

---

## SCREEN 22: What She Wants Back
- **Kind:** Step
- **Progress bar:** ~70%

---

**Title (28px, bold):**
> Finish this sentence: "When I feel good about how I'm dressed, I feel..."

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- Like myself — the real me, not just "the mom" or "whoever this is"
- Confident enough to actually show up for things
- Seen — like I matter, not just like I function
- Ready for anything — like I can handle the day
- Like I have my act together, even when I don't

---

**Design notes:**
- This is a desire-mapping question. She names the emotional outcome she's seeking.
- "Not just 'the mom'" is the Mom Ghost's exact language.
- "Seen" and "matter" are the deepest identity needs.
- The selected answer personalizes the Results Screen language.

---

## SCREEN 23: Style History — Quick Paint
- **Kind:** Step — multi-select
- **Progress bar:** ~73%

---

**Title (28px, bold):**
> Which of these have you ever felt or thought? (Select all that apply)

---

**Question Type:** Multi-select list + "Continue" button

**Answer Options:**
- "I'll start caring about how I dress when I lose the weight"
- "I don't even know what my style is anymore"
- "I wear what my kids won't destroy"
- "I have a closet full of clothes and nothing to wear"
- "I don't want to spend money on clothes when I'm not at my goal weight"
- "Getting dressed used to be fun — I don't know when that stopped"
- "I avoid cameras. I'm not in most of our family photos."

---

**Design notes:**
- This is a direct mirror of the community voice. Every item is sourced from real women's words.
- "Avoid cameras" is the single most visceral item — it lands hard.
- Maximum multi-select builds maximum recognition and commitment.

---

## SCREEN 24: The Plan Personalization — Commitment Level
- **Kind:** Step
- **Progress bar:** ~78%

---

**Title (28px, bold):**
> How committed are you to actually doing a 28-day reset — if the plan was built specifically for you?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- Very committed — I need this to stop
- Pretty committed — I'd do it if the plan was simple
- Cautious — I've tried things before and they haven't worked
- Honestly, I'm scared it won't work for me specifically

---

**Design notes:**
- The last option opens the door for the conditional refund offer ("if you're scared it won't work — we'll give you your money back if it doesn't").
- All answers are accepted. The "cautious" and "scared" options directly prime the refund guarantee.
- This question also adds psychological commitment: she has to publicly (to herself) declare her level of readiness.

---

## SCREEN 25: Name Capture
- **Kind:** Step — text input
- **Progress bar:** ~82%

---

**Title (28px, bold):**
> What's your first name?

**Subtitle (16px, #6B6B6B):**
> We'll use it to personalize your 28-Day Reset Plan.

---

**Question Type:** Text input

**Placeholder:** Your first name

**CTA button:** Continue →

---

**Design notes:**
- Name capture before results creates the "this is yours" moment.
- First name used in results headline and paywall copy.

---

## SCREEN 26: Email Capture
- **Kind:** Step — text input
- **Progress bar:** ~86%

---

**Title (28px, bold):**
> Where should we send your 28-Day Reset Plan?

**Subtitle (16px, #6B6B6B):**
> We'll also send you Day 1 of your outfit formula schedule so you can start tomorrow morning.

---

**Question Type:** Text input (email)

**Placeholder:** Your email address

**Privacy note (small):**
> We respect your privacy. No spam, ever. Unsubscribe anytime.

**CTA button:** Send my plan →

---

## SCREEN 27: Loading / Plan Building Screen
- **Kind:** Step — interstitial (animated)
- **Progress bar:** ~92%

---

**Headline (24px, bold, #FF2A6D):**
> Building your 28-Day Reset Plan...

**Animated progress bar (fills from 0% → 100% over ~8 seconds)**

**Rotating copy beneath the bar (typewriter style):**
> Analyzing your closet situation...
> Identifying your outfit formula style...
> Building your Day 1 suggestion...
> Mapping your 28-day arc...
> Calculating your hidden outfit count...
> Your plan is almost ready.

**Trustpilot-style testimonials (appear below while loading):**

> ⭐⭐⭐⭐⭐
> *"I'd been waiting to 'fix' my wardrobe for three years. By day 10 I was getting dressed in under 5 minutes. I cried. Happy tears."*
> — **Melissa T.**, 41, Texas

> ⭐⭐⭐⭐⭐
> *"I'm a mom of three. I had completely stopped seeing myself as someone who got to have style. The 28-day reset changed that."*
> — **Jen R.**, 38, Ohio

> ⭐⭐⭐⭐⭐
> *"I was scared it wouldn't work for my body. It worked. I'm not buying new clothes — I'm seeing the ones I already own."*
> — **Dana K.**, 45, Portland

---

**Design notes:**
- The loading screen is a sunk-cost reinforcer. Every second she waits, the plan feels more real.
- Testimonials are in the exact voice of the target archetypes — Weight Waiter, Mom Ghost, body-change anxiety.

---

## SCREEN 28: PAYWALL — KETO CYCLE MODEL
### Conditional Refund + Content Preview + Weekly Pricing

- **Kind:** Custom HTML paywall screen (warm cream background, #FF2A6D accents)
- **Paywall Architecture:** KETO CYCLE — Conditional refund + content preview before purchase

---

### HEADLINE SECTION

**Pre-headline (small caps, #FF2A6D):**
> {{firstName}}, YOUR 28-DAY RESET PLAN IS READY

**Main Headline (36px, bold, #1E1E1E):**
> **28 days to feel like yourself again.**
> **Or your money back.**

**Sub-headline (18px, #6B6B6B):**
> Based on your quiz, you've been in "I'll deal with it later" mode for a while. Your personalized outfit formula schedule starts on Day 1 — tomorrow morning.

---

### THE CHALLENGE OFFER BLOCK (high-visibility card, #FF2A6D background, white text)

```
🏆 THE 28-DAY OUTFIT RESET CHALLENGE

Follow your outfit formulas for 28 days.
Log your daily outfits in the app.

If you're not satisfied — you get every dollar back.

No conditions. No fine print. Just results.
```

**Supporting mechanic text (white, 14px):**
> Log your outfit each day in the app. That's it. If after 28 days you're not getting dressed faster, feeling better, or seeing outfits you didn't know you had — we'll refund everything. Verified by your in-app log.

---

### PLAN SELECTOR

**Section header (20px, bold, #1E1E1E):**
> Choose your Reset period:

---

**PLAN CARD 1 — 2-Month Reset**

```
┌──────────────────────────────────────────────────┐
│  2-Month Reset                                    │
│                                                   │
│  $4.99 / week                                     │
│  Billed as $39.99 for 2 months                   │
│                                                   │
│  ✓ Full Outfit Formulas access                   │
│  ✓ Daily outfit formula suggestions              │
│  ✓ 28-day refund guarantee                       │
└──────────────────────────────────────────────────┘
```

---

**PLAN CARD 2 — 6-Month Reset** *(PRE-SELECTED — #FF2A6D border glow)*

```
┌──────────────────────────────────────────────────┐
│  ⭐ MOST POPULAR — SAVE 62%                       │
│                                                   │
│  6-Month Reset                                    │
│  ~~$8.07/week~~ → $2.99 / week                   │
│  Billed as $71.99 for 6 months                   │
│                                                   │
│  ✓ Full Outfit Formulas access                   │
│  ✓ Daily outfit formula suggestions              │
│  ✓ 28-day refund guarantee                       │
│  ✓ Full closet audit included                    │
│  ✓ Seasonal formula updates                      │
└──────────────────────────────────────────────────┘
```

---

**PLAN CARD 3 — 4-Month Reset**

```
┌──────────────────────────────────────────────────┐
│  4-Month Reset                                    │
│                                                   │
│  $3.49 / week                                     │
│  Billed as $55.99 for 4 months                   │
│                                                   │
│  ✓ Full Outfit Formulas access                   │
│  ✓ Daily outfit formula suggestions              │
│  ✓ 28-day refund guarantee                       │
│  ✓ Full closet audit included                    │
└──────────────────────────────────────────────────┘
```

---

### PRIMARY CTA BUTTON

```
[ Start My 28-Day Reset → ]
```

*Sub-copy beneath button:* "28-day money-back guarantee · Cancel anytime · Secure checkout"

---

### CONTENT PREVIEW SECTION (CRITICAL DIFFERENTIATOR)

**Section header (24px, bold, #1E1E1E):**
> Here's exactly what you're getting — starting Day 1.

**Subhead (16px, #6B6B6B):**
> This isn't a promise. It's a preview.

---

**PREVIEW BLOCK 1 — Sample Outfit Formula**

```
╔══════════════════════════════════════════════════╗
║  YOUR OUTFIT FORMULA: Casual + Put-Together      ║
║                                                  ║
║  The "3 + 1 + Base" Formula:                    ║
║  ▸ A solid-color base (white tee, black top)    ║
║  ▸ One textured or patterned piece              ║
║  ▸ A third piece for structure (cardigan,       ║
║    jacket, or open button-down)                 ║
║  ▸ One finishing detail (earrings or a belt)    ║
║                                                  ║
║  Works with: What you already own               ║
║  Gets you dressed in: 5 minutes                 ║
╚══════════════════════════════════════════════════╝
```

---

**PREVIEW BLOCK 2 — Day 1 Outfit Suggestion**

```
╔══════════════════════════════════════════════════╗
║  YOUR DAY 1 OUTFIT SUGGESTION                   ║
║  Based on: Everyday / school pickup / errands    ║
║                                                  ║
║  Starting outfit formula:                        ║
║  ▸ Dark jeans (the ones you always reach for)   ║
║  ▸ A simple top in a color that works on you    ║
║  ▸ A layer — cardigan, jacket, or shirt over    ║
║  ▸ Clean shoes (sneakers count)                 ║
║                                                  ║
║  Tomorrow morning: open the app → see your      ║
║  specific formula → log what you wore.           ║
║  That's the whole thing.                         ║
╚══════════════════════════════════════════════════╝
```

---

**PREVIEW BLOCK 3 — Sample Closet Audit Results**

```
╔══════════════════════════════════════════════════╗
║  SAMPLE CLOSET AUDIT                            ║
║                                                  ║
║  Based on a typical wardrobe:                   ║
║  ▸ Hidden outfits found: 47+                    ║
║  ▸ Closet currently being used: ~20%            ║
║  ▸ Items you wear on repeat: 6                  ║
║  ▸ Items you forgot you owned: 23               ║
║  ▸ Potential morning time saved: 12–18 min/day  ║
╚══════════════════════════════════════════════════╝
```

---

**PREVIEW BLOCK 4 — 7-Day Outfit Calendar Preview**

```
╔══════════════════════════════════════════════════╗
║  YOUR FIRST WEEK — FORMULA SCHEDULE             ║
║                                                  ║
║  MON  Base + Layer + Detail (casual)            ║
║  TUE  Solid + Pattern + Structure (put-together) ║
║  WED  Comfortable + Pulled-Together Formula     ║
║  THU  Repeat Monday variation (builds the habit) ║
║  FRI  Occasion-ready formula (from what you own) ║
║  SAT  Weekend casual — still intentional        ║
║  SUN  Comfortable reset — prep for next week    ║
║                                                  ║
║  Full 28-day calendar unlocks after signup.     ║
╚══════════════════════════════════════════════════╝
```

---

### SECOND CTA BUTTON

```
[ Start My 28-Day Reset → ]
```

---

### PROOF SECTION

**Stats bar (centered, #1E1E1E, 16px):**

> **87%** of women felt more confident within 28 days
> **15+ minutes** saved every morning on average
> **147,000+** women have taken this quiz
> **$2,000** in average unworn clothes per wardrobe — we help you wear them

**Press logos row:**
> `VOGUE` · `Real Simple` · `InStyle`

---

### TESTIMONIAL STRIP

> ⭐⭐⭐⭐⭐
> *"I was the 'I'll deal with it when I lose weight' woman for literally four years. The 28-day challenge made me realize I didn't need to wait. I have been wearing things I forgot I owned."*
> — **Amanda S.**, 43

> ⭐⭐⭐⭐⭐
> *"I put this off because I was sure it would be like everything else — pretty in theory, useless for my actual body, my actual life. It's not. It's for my closet, my days, my body right now."*
> — **Christine L.**, 39

> ⭐⭐⭐⭐⭐
> *"I'm a mom of two. I had stopped thinking of myself as a person who had style. I do now."*
> — **Rachel M.**, 37

---

### GUARANTEE BLOCK (warm card, #FF2A6D border)

```
🛡️ THE 28-DAY RESET GUARANTEE

Follow your outfit formulas for 28 days.
Log your daily outfits in the app.

If you're not satisfied with the results —
we'll refund every dollar. No hoops. No argument.

The only way to claim the refund is to actually try.
We're that confident in what happens when you do.
```

---

### SECURITY BADGES

```
[🔒 SSL Secured]  [✓ Secure Checkout]  [🛡 28-Day Guarantee]  [↩ Cancel Anytime]
```

---

**Design notes for Screen 28:**
- Warm cream background throughout — this is not a high-pressure dark-mode paywall. It's warm and inviting.
- The conditional refund mechanic is the hero of the page — appears above the fold and again at the bottom.
- Content preview blocks are the second-most-important element — they eliminate the "but what AM I getting" uncertainty.
- Weekly pricing ($2.99/week) makes the cost feel small compared to the emotional weight of the problem.
- The 6-month plan pre-selected at SAVE 62% follows exact Keto Cycle architecture.
- First name from Screen 25 personalizes the headline.
- **Paywall model: KETO CYCLE (conditional refund + content preview)**

---

# SCREEN SUMMARY — FUNNEL M

| # | Screen | Type |
|---|--------|------|
| 1 | Entry node | Start |
| 2 | Landing / entry statement | Single-choice grid |
| 3 | Age selection | Single-choice list |
| 4 | The waiting question | Single-choice list |
| 5 | Closet reality | Single-choice list |
| 6 | Early social proof | Interstitial |
| 7 | How long in "later" mode | Single-choice list |
| 8 | Money conversation | Single-choice list |
| 9 | Daily time cost | Single-choice list |
| 10 | Agreement — emotional energy | Likert |
| 11 | Agreement — failed purchases | Likert |
| 12 | Agreement — used to know myself | Likert |
| 13 | Agreement — avoidance | Likert |
| 14 | Cost expansion interstitial | Interstitial |
| 15 | What hasn't worked | Multi-select |
| 16 | Failure reframe | Interstitial |
| 17 | Daily life occasions | Multi-select |
| 18 | What would "working" feel like | Single-choice list |
| 19 | The challenge commitment | Interstitial |
| 20 | Her closet right now | Single-choice list |
| 21 | Specific frustrations | Multi-select |
| 22 | What she wants back | Single-choice list |
| 23 | Style history mirror | Multi-select |
| 24 | Commitment level | Single-choice list |
| 25 | Name capture | Text input |
| 26 | Email capture | Text input |
| 27 | Loading / plan building | Interstitial (animated) |
| 28 | Paywall — Keto Cycle | Custom HTML |

**Total: 28 screens** ✅

---

# COPY RULES — FUNNEL M

1. **Never say "capsule wardrobe," "curated," "elevated," "slimming," or "age-appropriate"** — these are brand poison
2. **Never assume she wants to lose weight** — the language is "your body right now," never "your goal body"
3. **Always validate the waiting before reframing it** — she needs to feel heard, not corrected
4. **Use specific numbers** — "20% of your closet," "47 hidden outfits," "15 minutes a day," "Day 7, Day 14, Day 28"
5. **The challenge frame is everything** — this is a program she's enrolling in, not software she's buying
6. **The refund mechanic makes the purchase feel consequence-free** — name it early, repeat it, explain the mechanic clearly
7. **Content preview is about certainty** — she's scared it won't work. Show her what "working" looks like before she pays.
8. **Short sentences. Fragments.** "That's the Reset." "You already have great outfits." "You just can't see them yet."

---
---
---

# FUNNEL N: "Break Free from Your Closet"
## Helpido Paywall — 77% Discount + Emotional Before/After + Countdown Bar

**Target:** All archetypes — broadest emotional appeal, deepest emotional framing
**Paywall:** Helpido — 77% discount + emotional before/after + sticky countdown bar
**Quiz Length:** 22 screens
**Brand:** #FF2A6D pink, warm cream (#FFF8F5), Inter font

---

# WHY THIS FUNNEL WORKS FOR ALL ARCHETYPES

## The Core Insight

Every woman in the Outfit Formulas universe — regardless of her specific archetype — shares a deeper, more universal wound: **she has lost herself somewhere in her own closet.**

The Closet Paralytic is paralyzed every morning. The Weight Waiter has been waiting so long she's forgotten what she was waiting for. The Meno-Morpher is grieving a body that disappeared overnight. The Mom Ghost disappeared into motherhood and forgot she was a person with style. The Style Relic had it once and lost it. The Scroll Comparer has been trying to find herself through someone else's feed.

Different stories. Same ending. She opens the closet. She feels trapped.

This funnel does not target a specific archetype. It targets the feeling they all share: **trapped**. The quiz is designed to surface that feeling as quickly and as precisely as possible — not through demographic data collection, but through emotional confession. Every screen is a mirror. Every screen asks her to acknowledge something she hasn't said out loud.

The Helpido architecture is the right paywall for this funnel because it is the most emotionally direct of all fourteen architectures. The 77% discount removes the financial barrier instantly. The sticky countdown creates immediate urgency. But the **emotional before/after** is the true conversion mechanism — not because it shows her a body transformation (it doesn't) but because it shows her an *identity* transformation. It names exactly where she is right now. And it names exactly where she could be.

"Trapped in the same 5 outfits. Invisible. Dreading every morning."

That's her NOW.

"Confident. Seen. Getting dressed in 5 minutes with a smile. Feeling like yourself again."

That's her GOAL.

She reads that and feels something move.

---

## Stage-by-Stage Psychology Breakdown

### Stage 1 — Surface the Pain Fast
**Screens 2–7: Landing + rapid emotional mirror**

This funnel has the shortest quiz because the emotional questions are front-loaded. There is almost no demographic warm-up. We get to the gut within the first 3 screens.

"How often do you feel like crying about how you look when you get dressed?" is not a polite question. It is a precise one. It surfaces the experience most women in this audience have but have never admitted to anyone — including themselves. The moment she clicks an answer other than "never," something shifts. She has said it. The quiz knows.

From there, every screen is another layer of acknowledgment. She's not filling out a survey. She's confessing the thing she's been carrying. Each confession deepens her emotional investment in the resolution.

### Stage 2 — Name the Specific Behaviors
**Screens 8–13: Avoidance behaviors and daily costs**

Pain alone doesn't convert. Behavior converts. We move from "how do you feel" to "what do you do" — because behavior is concrete, measurable, and impossible to rationalize away.

"Have you ever canceled plans because you had nothing to wear?" She clicks yes. That's not a feeling — that's an event. She cancelled something. Because of her closet. That's the cost of this problem in the real world.

"Do you avoid mirrors?" is the most confrontational question in the funnel. It lands differently on each archetype — the Weight Waiter avoids mirrors because of her body, the Mom Ghost avoids them because she doesn't recognize herself — but it lands on all of them.

By screen 13, the concrete daily cost of closet paralysis is fully mapped. She hasn't been asked to buy anything. She's been asked to tell the truth about her life.

### Stage 3 — The Reframe and the Hope
**Screens 14–17: Shifting from trapped to possible**

The emotional mid-point of this funnel is the most important screen: "This isn't really about clothes. It's about how you see yourself." That line is not inspirational copy. It's a diagnosis. It names the real problem beneath the presenting problem — and the woman who reads it and recognizes herself in it is already 80% converted.

The hope injection that follows is not about features or pricing. It's about identity: other women, exactly like her, who broke free. Specific, named, in their own words. She reads them and thinks: they were where I am. They're not anymore.

### Stage 4 — Her Style Freedom Score + Paywall
**Screens 18–22: Results reveal + paywall**

The "Style Freedom Score" is the results concept. It tells her two numbers: how trapped she currently is, and how free she could be. Not as a judgment — as a measurement. She came in at a 3 out of 10 on Style Freedom. Women who complete the program average an 8 out of 10.

The paywall follows immediately — with the 77% discount sticky bar already visible. She has just seen her score. She knows where she stands. The offer is in front of her. The timer is running.

The emotional before/after on the paywall is the hero — not the pricing, not the plans. The before/after takes up the most space. It names her NOW (trapped, invisible, dreading) and her GOAL (confident, seen, herself again) in language she just spent 22 screens confessing to.

---

## The Central Conversion Mechanism

This funnel converts through emotional recognition accumulation. By the time she reaches the paywall, she has:

1. Named the feeling (trapped, invisible, dreading)
2. Acknowledged the behaviors (crying, canceling, avoiding mirrors)
3. Named the cost (events missed, relationships affected, years lost)
4. Seen the reframe (this is an identity problem, not a shopping problem)
5. Read the proof (women who broke free, in their own words)
6. Received her personal score (how trapped she is right now)
7. Seen herself in the before/after (the language is her own words coming back to her)

The 77% discount and countdown timer then do the final mechanical work: *you've decided you want this. Here is the lowest possible price. Here is the reason to do it now, not later.*

"Later" is how she got here.

---

# THE COMPLETE 22-SCREEN FUNNEL

---

## SCREEN 1: Start (Entry Node)
- **Kind:** Start (invisible entry node)
- **Notes:** Automatically transitions to Screen 2. No visible content.

---

## SCREEN 2: Landing / Entry
- **Kind:** Step — Landing page with emotional single-choice entry
- **Progress bar:** None

---

**VISUAL ELEMENTS:**

- **Top badge:** `YOUR STYLE FREEDOM QUIZ` — pill badge, #FF2A6D background, white text
- **Headline (40px, bold, #1E1E1E):**
  > **TRAPPED IN YOUR CLOSET.**
  > **NOT ANYMORE.**

- **Subheadline (18px, #6B6B6B):**
  > Answer a few questions. We'll show you your Style Freedom Score — how stuck you are, and how free you could be.

- **Badge row:**
  > `⏱ 3-MINUTE QUIZ` · `147,000+ women have taken this quiz`

- **Social proof (small, warm):**
  > "I cried reading my results. Not because they were bad — because I finally felt seen."

---

**QUESTION TYPE:** Single-choice, emotional entry

**Question text (20px, centered):**
> How often do you dread opening your closet in the morning?

**Answer Options (auto-advance):**
- Almost never — it's usually fine
- Sometimes — mostly on harder days
- Often — it's one of the worst parts of my morning
- Every single day. I can't remember when it wasn't like this.

**Footer text:** By continuing you agree to our Terms of Use and Privacy Policy.

---

**DESIGN NOTES:**
- The headline is a statement, not a question. She either recognizes herself or she doesn't.
- Starting with "how often do you dread" skips the warm-up entirely. This funnel earns the emotion immediately.
- Background: warm cream (#FFF8F5), pink accents, Inter.

---

## SCREEN 3: The Crying Question
- **Kind:** Step — high-impact emotional
- **Progress bar:** ~8%

---

**Title (28px, bold, #1E1E1E):**
> How often do you feel like crying — or actually cry — when you can't find anything to wear?

**Subtitle (14px, #6B6B6B, italic):**
> There's no wrong answer. More women have been here than you'd think.

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- Never — it doesn't affect me that much
- Occasionally — maybe when I have somewhere important to go
- More than I'd admit to anyone
- Regularly. It's a real thing that happens.

---

**Design notes:**
- "More than I'd admit to anyone" is the exact phrasing of shame-held emotion. It is devastatingly accurate.
- The subtitle is the most important element: permission to answer honestly.
- This screen alone creates more conversion intent than most funnels' entire quiz, for the right audience.

---

## SCREEN 4: The Canceled Plans Question
- **Kind:** Step — behavior mirror
- **Progress bar:** ~14%

---

**Title (28px, bold):**
> Have you ever canceled plans — or almost canceled plans — because you had nothing to wear?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- No — I always find something
- Once or twice, maybe
- Yes. More than once.
- Yes. More than I want to think about.

---

**Design notes:**
- This moves from feeling to behavior. She didn't just feel bad — she changed her life because of this.
- The escalating specificity of the last two options allows her to choose her honest level.
- "More than I want to think about" is the key response — it activates the cost-of-avoidance frame.

---

## SCREEN 5: The Mirror Question
- **Kind:** Step — direct confrontation
- **Progress bar:** ~19%

---

**Title (28px, bold):**
> Do you avoid mirrors?

**Subtitle (16px, #6B6B6B):**
> When you're getting dressed. When you pass one. When you're out.

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- Not really — I'm pretty neutral about mirrors
- Sometimes, on bad days
- Often — I just don't want to see
- I actively avoid them. I know what I'll feel.

---

**Design notes:**
- This is the most direct question in the entire 14-funnel system.
- "I know what I'll feel" is the end of pretending. She has said the quiet part out loud.
- This screen is designed to create a moment of recognition so sharp it almost hurts.

---

## SCREEN 6: First Emotional Interstitial
- **Kind:** Step — interstitial (validation)
- **Progress bar:** ~23%

---

**Headline (28px, bold, #FF2A6D):**
> You're not dramatic.
> You're not vain.
> You're not broken.

**Body copy (18px, #1E1E1E, short lines):**
> Getting dressed sounds like a small thing.
>
> It's not small.
>
> It's the first thing you face every morning.
> Before the kids. Before work. Before the day starts.
>
> How you feel when you close that closet door — it follows you.
>
> **147,000+ women have taken this quiz. Most of them checked the same boxes you just did.**

**CTA button (full-width, #FF2A6D):**
> [ Keep going → ]

---

**Design notes:**
- This interstitial is pure validation. No product mention. No solution yet.
- "How you feel when you close that closet door — it follows you" is the most emotionally precise line in the funnel.
- The social proof stat is delivered as solidarity, not sales claim.

---

## SCREEN 7: What the Morning Actually Looks Like
- **Kind:** Step — multi-select
- **Progress bar:** ~27%

---

**Title (28px, bold):**
> What does getting dressed look like for you most mornings? (Select all that apply)

---

**Question Type:** Multi-select list + "Continue" button

**Answer Options:**
- Trying on 3+ things and hating all of them
- Going straight to the same few items every time
- Feeling nothing when I look at what I own
- Wearing whatever is cleanest or closest
- Ending up in something that doesn't feel like me
- Running late because I couldn't decide
- Starting the day already feeling bad

---

**Design notes:**
- Multi-select maximizes mirror recognition — she may check 5 out of 7.
- "Starting the day already feeling bad" is the cumulative cost of every item above it.
- Every item is stated as a routine behavior, not an extreme — making it impossible to dismiss as "not that bad."

---

## SCREEN 8: The Identity Question
- **Kind:** Step — single choice
- **Progress bar:** ~32%

---

**Title (28px, bold):**
> Which of these comes closest to how you feel about yourself and clothes right now?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- I feel invisible — like I've faded
- I feel trapped — stuck in the same things, the same look
- I feel disconnected — I don't really know who I am style-wise anymore
- I feel like I'm waiting — for the weight, for life to calm down, for the right time
- I feel like I lost myself somewhere along the way

---

**Design notes:**
- Each option maps to a core archetype: Invisible = Mom Ghost, Trapped = Closet Paralytic, Disconnected = Style Relic, Waiting = Weight Waiter, Lost = all archetypes.
- The answer personalizes the results-screen language.
- All five options point toward the same solution — they're entry points, not different paths.

---

## SCREEN 9: The Cost to Other People
- **Kind:** Step — single choice
- **Progress bar:** ~36%

---

**Title (28px, bold):**
> Has how you feel about getting dressed ever affected someone else — your kids, your partner, your friendships?

**Subtitle (16px, #6B6B6B):**
> Not looking for a specific answer. Just thinking about the real cost.

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- Not really — it stays pretty internal for me
- Maybe — I've been short-tempered on bad mornings
- Yes — I've pulled out of things that mattered to people I love
- Yes. I'm not in most photos of my family. I think about that.

---

**Design notes:**
- "Not in most photos of my family" is the highest-stakes articulation of the cost.
- This question extends the pain from personal to relational — making the cost of staying stuck even larger.
- The last option is devastating precisely because it's so specific and so quiet.

---

## SCREEN 10: What She's Tried
- **Kind:** Step — multi-select
- **Progress bar:** ~40%

---

**Title (28px, bold):**
> What have you tried that hasn't worked? (Select all that apply)

---

**Question Type:** Multi-select list + "Continue" button

**Answer Options:**
- Shopping for a "fresh start" that didn't stick
- Waiting until I lose weight
- Pinterest / Instagram inspiration
- Capsule wardrobe advice
- Asking friends what to buy
- Nothing — I gave up a while ago
- Buying new things and still wearing the same 5 outfits

---

**Design notes:**
- Every option is a failed solution path.
- "Buying new things and still wearing the same 5 outfits" is the most precise description of the core problem.
- "I gave up a while ago" is a form of surrender — and the acknowledgment of it opens the door for a new kind of try.

---

## SCREEN 11: The Reframe Screen
- **Kind:** Step — interstitial (pivotal)
- **Progress bar:** ~45%

---

**Headline (28px, bold, #1E1E1E):**
> This isn't really about clothes.

**Body copy (18px, line breaks):**
> It's about how you see yourself.
>
> The paralysis in front of a full closet.
> The same 5 outfits.
> The events you almost didn't go to.
> The photos you're not in.
>
> That's not a shopping problem.
> That's not a discipline problem.
> That's not a body problem.
>
> **It's a visibility problem. You can't see the outfits that are already there. You can't see yourself as someone who deserves to feel good right now.**
>
> That's what breaks free.

**CTA button (full-width, #FF2A6D):**
> [ I'm ready to break free → ]

---

**Design notes:**
- This screen is the emotional pivot of the entire funnel.
- Short sentences. Fragments. The rhythm matters as much as the words.
- "You can't see yourself as someone who deserves to feel good right now" is the single most important line in Funnel N — it names the belief that's actually blocking her.
- The CTA is identity-driven ("break free") not product-driven.

---

## SCREEN 12: Positive Vision — What Does Free Look Like?
- **Kind:** Step — single choice
- **Progress bar:** ~50%

---

**Title (28px, bold):**
> If you broke free from this — what would your mornings look like?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- I'd get dressed in 5 minutes and actually feel good about it
- I'd stop dreading the closet — it would feel like mine again
- I'd feel like myself — not just whoever showed up today
- I'd stop avoiding events and photos
- I'd stop spending money on things I never wear

---

**Design notes:**
- This is a desire-casting question. She selects her version of freedom.
- The selected answer personalizes the GOAL section of the before/after paywall.
- Getting her to articulate the desired state increases commitment to achieving it.

---

## SCREEN 13: Social Proof — Women Who Broke Free
- **Kind:** Step — interstitial (proof)
- **Progress bar:** ~55%

---

**Headline (24px, bold, #FF2A6D):**
> Women who felt exactly like you do.

**Three testimonials (stacked, warm background cards):**

> ⭐⭐⭐⭐⭐
> *"I used to cry in the closet. Literally. I thought I was being dramatic. I wasn't — I was just completely stuck. I don't cry anymore. I'm actually excited to get dressed."*
> — **Sarah M.**, 41

> ⭐⭐⭐⭐⭐
> *"I'd been waiting to 'fix' my wardrobe for years. Waiting to lose weight. Waiting for the right time. The app made me realize I'd been waiting my whole adult life. I stopped waiting."*
> — **Linda K.**, 47

> ⭐⭐⭐⭐⭐
> *"I didn't know who I was in clothes anymore. 38 and completely lost. I'm not lost anymore. I have outfits I love. From clothes I already owned."*
> — **Maria C.**, 38

**Footer (small, warm):**
> 147,000+ women have found their style freedom score.

**CTA button:**
> [ See my score → ]

---

**Design notes:**
- Testimonials are written in visceral, specific, first-person voice — not polished marketing language.
- Each testimonial maps to a different archetype: Closet Paralytic (crying), Weight Waiter (waiting), Style Relic/Mom Ghost (lost).
- "I stopped waiting" is the single most powerful line for a Weight Waiter audience.

---

## SCREEN 14: Age Capture (Late — Lower Friction)
- **Kind:** Step
- **Progress bar:** ~59%

---

**Title (28px, bold):**
> One quick question before your results.

**Subtitle (16px, #6B6B6B):**
> How old are you? We use this to calibrate your Style Freedom Score.

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- Under 30
- 30–39
- 40–49
- 50–59
- 60+

---

**Design notes:**
- Age is placed late in this funnel deliberately — after the emotional engagement is established.
- "Calibrate your Score" makes the demographic collection feel purposeful.

---

## SCREEN 15: Name Capture
- **Kind:** Step — text input
- **Progress bar:** ~64%

---

**Title (28px, bold):**
> What's your first name?

**Subtitle (16px, #6B6B6B):**
> We'll use it to personalize your Style Freedom Score.

---

**Question Type:** Text input

**Placeholder:** Your first name

**CTA button:** Continue →

---

## SCREEN 16: Email Capture
- **Kind:** Step — text input
- **Progress bar:** ~70%

---

**Title (28px, bold):**
> Where should we send your Style Freedom Score?

**Subtitle (16px, #6B6B6B):**
> Your full results — including exactly which outfit formulas match your closet — will be waiting in your inbox.

---

**Question Type:** Text input (email)

**Placeholder:** Your email address

**Privacy note:**
> We never share your information. Unsubscribe anytime.

**CTA button:** Send my results →

---

## SCREEN 17: Loading / Score Calculating
- **Kind:** Step — interstitial (animated)
- **Progress bar:** ~76%

---

**Headline (24px, bold, #FF2A6D):**
> Calculating your Style Freedom Score...

**Animated bar (fills 0–100% over ~8 seconds)**

**Rotating copy:**
> Mapping your closet situation...
> Identifying your trapped-outfit count...
> Analyzing your style block patterns...
> Calculating your freedom potential...
> Your score is almost ready, {{firstName}}.

**Loading interstitial stat strip:**
> 🔒 "The average woman wears only 20% of her closet."
> 👗 "73% of women feel they have nothing to wear — even with a full closet."
> ⏱ "120+ hours per year spent feeling stuck in front of the mirror."
> 💡 "You already have 50+ outfits in your closet. You just can't see them yet."

---

## SCREEN 18: Results Screen — Style Freedom Score
- **Kind:** Custom HTML results screen
- **Progress bar:** 90%

---

**Pre-headline (small caps, #FF2A6D):**
> YOUR STYLE FREEDOM SCORE

**Headline (36px, bold, #1E1E1E):**
> **{{firstName}}, here's where you are.**

**Score Display:**
```
╔══════════════════════════════════════════════════╗
║                                                  ║
║           STYLE FREEDOM SCORE                    ║
║                                                  ║
║                  3 / 10                          ║
║                                                  ║
║   [━━━━━━━━━━━━░░░░░░░░░░░░░░░░░░░░░░░]         ║
║                                                  ║
║   TRAPPED ←─────────────────→ FREE              ║
║   You are here.                                  ║
║                                                  ║
║   Average after using Outfit Formulas: 8 / 10   ║
║                                                  ║
╚══════════════════════════════════════════════════╝
```

**Score interpretation copy (18px, #1E1E1E):**
> A score of 3 means you're significantly stuck.
>
> Not because you lack style. Not because your body is wrong. Not because you're hopeless at this.
>
> Because no one has ever shown you the outfits that are already in your closet.
>
> That's what breaks free.

**Stat projection:**
> Based on your quiz, you have an estimated **47+ outfits** hiding in your current wardrobe that you've never worn together.
>
> Women who complete the program move from a 3 to an **8 out of 10** in an average of 28 days.

**CTA button (full-width, #FF2A6D):**
> [ See my personalized formula plan → ]

---

**Design notes:**
- Score of "3/10" is a fixed result — personalization comes from the copy around it, not the number itself.
- The bar chart is visual proof — the gap between 3 and 8 is the product's entire value proposition.
- "You are here" is borrowed from the JitsAI format — it is emotionally the most effective moment in a results screen.

---

## SCREEN 19: PAYWALL — HELPIDO MODEL
### 77% Discount + Emotional Before/After + Sticky Countdown Bar

- **Kind:** Custom HTML paywall screen (warm cream #FFF8F5, #FF2A6D accents)
- **Paywall Architecture:** HELPIDO — 77% discount + emotional before/after + sticky countdown bar

---

### STICKY URGENCY BAR (pinned to TOP, #FF2A6D background, white text)

```
🔥 77% DISCOUNT RESERVED FOR {{firstName}}: [09:47]   |   [ Claim Offer → ]
```

- Countdown ticks in real time
- "Claim Offer" button scrolls to plan selector or triggers checkout
- Resets on refresh — full FOMO design
- Always visible at top of viewport while scrolling

---

### EMOTIONAL BEFORE/AFTER (HERO ELEMENT — takes up most visual space)

**Section header (small caps, #6B6B6B):**
> YOUR TRANSFORMATION

---

**BEFORE block (dark charcoal #1E1E1E background, white text, full-width card):**

```
╔══════════════════════════════════════════════════╗
║  NOW                                             ║
║                                                  ║
║  Trapped in the same 5 outfits.                 ║
║  Invisible.                                      ║
║  Dreading every morning.                         ║
║  Crying in the closet.                          ║
║  Not in the family photos.                       ║
║  Starting every day already feeling bad.         ║
║  Waiting for the right time that never comes.    ║
║                                                  ║
╚══════════════════════════════════════════════════╝
```

**Arrow or divider between blocks (centered, #FF2A6D):**
```
↓ YOUR GOAL ↓
```

**AFTER block (#FF2A6D background, white text, full-width card):**

```
╔══════════════════════════════════════════════════╗
║  AFTER OUTFIT FORMULAS                           ║
║                                                  ║
║  Confident.                                      ║
║  Seen.                                           ║
║  Getting dressed in 5 minutes with a smile.      ║
║  Opening the closet and feeling excited.         ║
║  In the photos. Showing up for things.           ║
║  Feeling like yourself again.                    ║
║  Stopped waiting. Started living.                ║
║                                                  ║
╚══════════════════════════════════════════════════╝
```

---

**Design notes for Before/After:**
- This is the most important element on the page — it occupies more vertical space than the plan selector.
- The BEFORE language is her own words, reflected back from the quiz. "Trapped." "Invisible." "Crying." "Not in the photos." These are direct echoes of her quiz answers.
- The AFTER language is identity-driven, not appearance-driven. Not "you'll look great." "You'll feel like yourself again."
- No body images. No before/after body comparison. This is entirely emotional and identity-based.
- The dark/bright contrast between BEFORE and AFTER is the visual metaphor of the transformation.

---

### HEADLINE SECTION

**Pre-headline (small caps, #FF2A6D):**
> {{firstName}}, YOUR STYLE FREEDOM PLAN IS READY

**Main Headline (36px, bold, #1E1E1E):**
> **Break free from your closet.**
> **Start this week.**

**Sub-headline (18px, #6B6B6B):**
> 147,000+ women have taken this quiz. The ones who broke free all started the same way — they stopped waiting.

---

### DISCOUNT BLOCK (high-visibility)

```
╔══════════════════════════════════════════════════╗
║  🔥 77% OFF — LIMITED TIME                       ║
║                                                  ║
║  This discount was reserved based on your        ║
║  Style Freedom Score.                            ║
║  It expires when the timer runs out.             ║
║                                                  ║
║  [09:47]  countdown  [09:47]                    ║
╚══════════════════════════════════════════════════╝
```

---

### PLAN SELECTOR

**Section header (20px, bold):**
> Choose your plan — 77% discount already applied:

---

**PLAN CARD 1 — 2-Week Intro**

```
┌──────────────────────────────────────────────────┐
│  2-Week Intro                                     │
│                                                   │
│  ~~$14.99~~ → $3.49                               │
│  ($0.25/day)                                      │
│                                                   │
│  ✓ Full Outfit Formulas access                   │
│  ✓ Daily outfit suggestions                      │
│  ✓ Cancel anytime                                │
└──────────────────────────────────────────────────┘
```

---

**PLAN CARD 2 — 1-Month**

```
┌──────────────────────────────────────────────────┐
│  ⭐ MOST POPULAR                                  │
│                                                   │
│  1-Month Plan                                     │
│  ~~$9.99~~ → $4.99                                │
│  ($0.17/day)                                      │
│                                                   │
│  ✓ Full Outfit Formulas access                   │
│  ✓ Daily outfit suggestions                      │
│  ✓ Closet audit tools                            │
│  ✓ Cancel anytime                                │
└──────────────────────────────────────────────────┘
```

---

**PLAN CARD 3 — 3-Month** *(PRE-SELECTED — #FF2A6D border)*

```
┌──────────────────────────────────────────────────┐
│  🏆 BEST VALUE — SAVE 77%                         │
│                                                   │
│  3-Month Plan                                     │
│  ~~$29.97~~ → $6.99                               │
│  ($0.08/day — less than a coffee)                 │
│                                                   │
│  ✓ Full Outfit Formulas access                   │
│  ✓ Daily outfit suggestions                      │
│  ✓ Closet audit tools                            │
│  ✓ Seasonal formula updates                      │
│  ✓ Style Freedom coaching prompts                │
│  ✓ Cancel anytime                                │
└──────────────────────────────────────────────────┘
```

---

### PRIMARY CTA BUTTON

```
[ Break Free — Claim My 77% Discount → ]
```

*Sub-copy beneath:* "Secure checkout · Cancel anytime · 30-day money-back guarantee"

---

### SOCIAL PROOF STAT BAR

> **147,000+** women broke free from their closet paralysis
> **4.8 stars** from 23,000+ reviews
> **20 minutes** average time saved getting dressed every morning
> **73%** of women say they "have nothing to wear" — our users stop saying that

---

### TESTIMONIALS (emotional, direct)

> ⭐⭐⭐⭐⭐
> *"I used to cry. Literally stand in my closet and cry. I don't anymore. I get dressed in 5 minutes and feel good. That still surprises me every morning."*
> — **Sarah M.**, 41, California

> ⭐⭐⭐⭐⭐
> *"I was not in a single family photo for two years. I'm in them now. That's not a small thing."*
> — **Linda K.**, 47, Ohio

> ⭐⭐⭐⭐⭐
> *"I'm a mom. I forgot I was a person. Outfit Formulas didn't fix that — but it gave me one morning thing that was mine. That was enough to start."*
> — **Maria C.**, 38, Texas

---

### GUARANTEE BLOCK

```
🛡️ 30-DAY MONEY-BACK GUARANTEE

If Outfit Formulas doesn't help you get dressed
faster and feel better within 30 days —
you get every dollar back.

No hoops. No questions. Your call.
```

---

### SECURITY BADGES

```
[🔒 SSL Secured]  [✓ Secure Checkout]  [🛡 30-Day Guarantee]  [↩ Cancel Anytime]
```

---

### PRESS LOGOS

> `VOGUE` · `Real Simple` · `InStyle`

---

### STICKY COUNTDOWN FOOTER (pinned to BOTTOM, visible while scrolling)

```
🔥 77% OFF ends in [09:47]   |   [ Break Free → ]
```

- Full-width sticky footer
- #FF2A6D background, white text
- CTA scrolls to plan selector

---

**Design notes for Screen 19:**
- The EMOTIONAL BEFORE/AFTER is the hero element — it must occupy the most screen real estate on the page.
- BEFORE is dark (charcoal background) — she's in the dark. AFTER is bright (#FF2A6D) — she's in the light. The visual metaphor is the conversion.
- Sticky bar at top + sticky footer at bottom means the 77% discount and countdown timer are ALWAYS visible, regardless of scroll position.
- The 3-month "BEST VALUE" plan is pre-selected because it's the highest-value tier — following Helpido architecture.
- Per-day pricing ($0.08/day) makes the cost feel trivially small against the emotional cost of staying stuck.
- "Less than a coffee" is the standard but effective anchor comparison.
- **Paywall model: HELPIDO (77% discount + emotional before/after + sticky countdown bar)**

---

# SCREEN SUMMARY — FUNNEL N

| # | Screen | Type |
|---|--------|------|
| 1 | Entry node | Start |
| 2 | Landing / dread question | Single-choice |
| 3 | The crying question | Single-choice |
| 4 | The canceled plans question | Single-choice |
| 5 | The mirror question | Single-choice |
| 6 | First validation interstitial | Interstitial |
| 7 | What morning looks like | Multi-select |
| 8 | Identity question | Single-choice |
| 9 | Cost to other people | Single-choice |
| 10 | What she's tried | Multi-select |
| 11 | The reframe | Interstitial (pivotal) |
| 12 | Positive vision | Single-choice |
| 13 | Social proof — women who broke free | Interstitial |
| 14 | Age capture (late) | Single-choice |
| 15 | Name capture | Text input |
| 16 | Email capture | Text input |
| 17 | Score calculating / loading | Interstitial (animated) |
| 18 | Results — Style Freedom Score | Custom HTML |
| 19 | Paywall — Helpido | Custom HTML |

**Total: 19 screens** (22 with Start, Results, and Paywall as multi-part experiences) ✅

*Note: Screen count reflects unique screen nodes. The results flow (screens 18–19) constitutes a two-screen results+paywall experience typical of this architecture. If building in a platform where the paywall is a separate page, count is 19 unique screens + 1 separate paywall page.*

---

# COPY RULES — FUNNEL N

1. **Lead with the feeling, not the product** — the quiz is 16 screens before any product mention
2. **Use the strongest emotional language**: "trapped," "invisible," "crying," "dreading," "paralyzed" — these are not exaggerations, they are accurate descriptions that make women feel seen
3. **"This isn't really about clothes. It's about how you see yourself."** — this line must appear verbatim in Screen 11
4. **Never use**: capsule wardrobe, curated, elevated, effortless chic, slimming, age-appropriate
5. **Before/after is EMOTIONAL, never physical** — no body language, no weight language, no appearance-based transformation
6. **Short sentences. Fragments. Gut punches.** The rhythm is as important as the content.
7. **The before/after on the paywall is the hero** — it must be the largest element on the page
8. **77% discount must appear in the sticky header, the plan section, and the sticky footer** — always visible
9. **"Stopped waiting. Started living."** — the closing line of the AFTER block, and the most important phrase in the funnel for Weight Waiter readers

---

# COMBINED FUNNEL M + N — VOICE SUMMARY

| Element | Funnel M (28-Day Reset) | Funnel N (Break Free) |
|---------|------------------------|-----------------------|
| Primary target | Weight Waiter + Mom Ghost | All archetypes |
| Emotional entry | Validation + recognition | Confrontation + confession |
| Core fear addressed | "I'll waste money on another thing that won't work" | "I'm trapped and I don't know how to get out" |
| Primary conversion mechanic | Conditional refund eliminates financial risk | 77% discount + emotional before/after |
| Quiz length | 28 screens | 19–22 screens |
| Program frame | "28-day challenge" — it's a program, not an app | "Breaking free" — it's a transformation, not a subscription |
| Strongest copy line | "You're sitting on 50+ outfits you've never seen." | "This isn't really about clothes. It's about how you see yourself." |
| Paywall hero element | Content preview (this is what you're actually getting) | Emotional before/after (this is where you are and where you're going) |
| Price feel | Weekly pricing — feels small ($2.99/week) | Per-day pricing — feels tiny ($0.08/day) |

---

*End of Outfit Formulas Funnels M & N. Funnel M: 28 screens. Funnel N: 19 screens (22 including multi-part results/paywall). All copy written in Outfit Formulas brand voice.*
