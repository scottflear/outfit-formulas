# Outfit Formulas — Quiz Funnels K & L

---

# FUNNEL K: "Build Your Style Blueprint"
## Target: Closet Paralytic + Style Relic blend
## Paywall Architecture: Slowdive — Limited Time + Per-Day Pricing + Live Buyer Counter + Sticky Footer
## Quiz Length: 28 screens

---

# WHY THIS FUNNEL WORKS FOR THE CLOSET PARALYTIC + STYLE RELIC BLEND

## The Core Insight

These two women share one devastating belief: **the answer is somewhere in their closet, and they can't find it.**

The Closet Paralytic stands in front of a stuffed rack every morning and draws a blank. The Style Relic remembers a version of herself who could pull an outfit together in 90 seconds — and she has no idea where that woman went. Same paralysis. Different origin story.

The funnel's central reframe — **"What if you already own everything you need?"** — works for both because it doesn't ask her to shop, change her body, or start over. It says: the problem isn't your wardrobe. The problem is you don't have a system for reading it.

That reframe is the engine. Everything before it builds the pain of the blank-closet morning. Everything after it sells the blueprint as the solution she's been one step away from the whole time.

---

## Stage-by-Stage Psychology Breakdown

### Stage 1 — The Mirror (Screens 2–8)
**What it does:** Reflects her exact morning experience back at her with enough specificity that she thinks you've been watching.

**Why it works:**

The Closet Paralytic has told herself she just "isn't a fashion person" so many times she's started to believe it. The Style Relic tells herself she used to have it, lost it, and probably won't get it back. Both are wrong. Both need to be shown — not told — that they're wrong.

The opening screens don't diagnose. They describe. "You stand in front of your closet. You see clothes. You feel nothing." That's not an accusation. That's a mirror. The moment she nods along, the psychological contract is signed: *this thing knows me.*

The zero-friction principle applies here too. First questions feel like registration: age, lifestyle, how she'd describe her style now. By the time the emotional material arrives (the morning ritual, the try-on-reject loop, the fall-back-on-the-same-four-pieces), she's in the habit of answering honestly.

---

### Stage 2 — The Inventory Audit (Screens 9–15)
**What it does:** Asks about what's actually in her closet, what she reaches for, what she ignores, and why.

**Why it works:**

This is where the funnel becomes different from every quiz she's taken before. Instead of asking "what's your style personality?" it asks about her actual wardrobe — specific categories, specific behaviors. "How many white tops do you own?" "How often do you wear your nicest pieces?" "What's still sitting in the bag from three months ago?"

These questions accomplish two things simultaneously:
1. They generate genuine data the results screen will use ("Your Style Blueprint" is built from this)
2. They surface the sunk cost: she just inventoried clothes she's been ignoring. The problem is suddenly real and concrete, not abstract.

The Style Relic also notices something here: she still *owns* the pieces. They're not gone. They're just not being activated.

---

### Stage 3 — The Cost Audit (Screens 16–20)
**What it does:** Moves the pain from inconvenient to genuinely expensive — in time, in money, in missed life.

**Why it works:**

"I have nothing to wear" feels like a first-world problem she should be able to solve. Then you give her the numbers. 120 hours per year standing at a closet feeling bad. $2,000 in unworn clothes. Events she's turned down because she couldn't figure out what to wear. Mornings that started with frustration and never recovered.

The multi-select frustration screen is the pivot point. She checks every box that applies — and she checks almost all of them. Each check is a micro-commitment: *I've confirmed this is a real problem. I cannot dismiss it now.*

---

### Stage 4 — The Reframe (Screens 21–24)
**What it does:** Introduces the "What if you already own everything you need?" reframe. Shifts the diagnosis from "wardrobe problem" to "visibility problem."

**Why it works:**

This is the most important stage. The Closet Paralytic has been assuming she needs more clothes, better clothes, or a completely different closet. The Style Relic has been assuming she needs to go back to who she was. Both are wrong.

The reframe lands gently: "73% of women who feel like they have nothing to wear are actually sitting on 50+ outfits they've never put together." Then: "You don't have a wardrobe problem. You have a visibility problem."

This isn't a dismissal. It's a gift. She doesn't have to start over. She doesn't have to shop. She doesn't have to wait for anything. She just needs a system for seeing what's already there.

---

### Stage 5 — The Blueprint Preview (Screens 25–28)
**What it does:** Makes the transformation tangible. Shows what a "Style Blueprint" actually means for her specific answers.

**Why it works:**

She's told us about her closet composition, her daily life, her morning ritual, her deepest frustrations. Now we show her what happens when all of that becomes a system.

The results loading screen — "Building your Style Blueprint..." — with a live progress bar makes her feel like she earned something. The results screen shows her preliminary formula profile and the headline insight from her answers. Then the paywall.

The Slowdive urgency architecture hits exactly here: she's just seen enough to want the full blueprint. The live counter ("147 women unlocked their blueprint in the last hour") creates the FOMO specific to women who've been putting this off. The sticky footer means the countdown is ALWAYS visible as she scrolls.

---

## The Central Conversion Mechanism

The quiz never sells the app. It sells the diagnosis. By the time the paywall appears, she has:

1. Confirmed she has the blank-closet problem (Stage 1)
2. Inventoried exactly which clothes she's been ignoring (Stage 2)
3. Quantified the real cost of the problem — in hours and dollars (Stage 3)
4. Received the reframe: it's a visibility problem, not a wardrobe problem (Stage 4)
5. Seen the beginning of her personal blueprint, which requires the full app to unlock (Stage 5)

The blueprint is the delivery mechanism for the system she already decided she needs.

---

# THE COMPLETE 28-SCREEN FUNNEL

---

## SCREEN 1: Start (Entry Node)

- **Kind:** Start (invisible entry node)
- **Notes:** Automatically transitions to Screen 2. No visible content. Platform handles routing.

---

## SCREEN 2: Landing Page

- **Kind:** Step — Landing page (no question)
- **Progress bar:** None

---

**VISUAL ELEMENTS:**

- **Top badge:** `STYLE BLUEPRINT QUIZ` — pill/badge, warm cream border on pink background, Inter font
- **Headline (large, 36–40px, bold, #1E1E1E):**
  > **"I have a full closet and nothing to wear."**
  > **Let's fix that. In 3 minutes.**

- **Subheadline (18px, #6B6B6B):**
  > Answer a few questions about YOUR closet and we'll build your personal Style Blueprint — a formula-based system for the clothes you already own.

- **Badge:** `⏱ 3-MINUTE QUIZ` — centered, pink accent

- **Trust line (small, below badge):**
  > 147,000+ women have taken this quiz

- **CTA Button (full-width, #FF2A6D, 12px border-radius, white bold text):**
  > Build My Blueprint →

- **Footer (small, muted):**
  > By continuing you agree to our Terms of Use and Privacy Policy.

---

**DESIGN NOTES:**
- Background: warm cream (#FFF8F5)
- The headline opens with her exact words — not a claim, not a question, not a headline. Her sentence. This is the mirror.
- No mention of Outfit Formulas as an app yet. This is "your quiz."
- The CTA is "Build My Blueprint" — not "Start Quiz." She's building something. Not being tested.

---

## SCREEN 3: Age Selection

- **Kind:** Step
- **Progress bar:** ~5%

---

**Title (28px, bold):**
> How old are you?

**Subtitle (16px, #6B6B6B):**
> We use this to personalise your formula — what works at 28 looks different at 45.

---

**Question Type:** Single-choice list, auto-advance on click

**Answer Options:**
- Under 30
- 30–39
- 40–49
- 50–59
- 60+

**Design notes:**
- The subtitle does quiet work: "what works at 28 looks different at 45" tells the 47-year-old her age is a variable in the formula, not a disqualifier.
- No "I prefer not to say" — age is required for personalization. Frame it as necessary, not demographic collection.

---

## SCREEN 4: Lifestyle Context

- **Kind:** Step
- **Progress bar:** ~10%

---

**Title (28px, bold):**
> What does a typical week look like for you?

**Subtitle (16px, muted):**
> Your lifestyle shapes your formula — what you need to get dressed for matters.

---

**Question Type:** Single-choice list

**Answer Options:**
- Mostly at home / working from home
- Mix of home and going out
- Office or workplace most days
- Very busy — events, travel, lots of variety
- Life feels like it changes week to week

**Design notes:**
- This grounds the quiz immediately in her real life, not an aspirational lifestyle she doesn't have.
- "Life feels like it changes week to week" is the catch-all for women who resist categories — and it's also the Meno-Morpher/Relic blend's honest answer.

---

## SCREEN 5: Current Style Self-Description

- **Kind:** Step
- **Progress bar:** ~15%

---

**Title (28px, bold):**
> How would you describe your style right now?

**Subtitle (16px, muted):**
> Honest answers only — this isn't a magazine quiz.

---

**Question Type:** Single-choice list

**Answer Options:**
- Non-existent. I just wear what's clean.
- Stuck. Same few things on repeat.
- Used to be great. Not anymore.
- Inconsistent — some days fine, most days not.
- I'm still figuring it out.

**Design notes:**
- "Non-existent. I just wear what's clean." — Closet Paralytic voice
- "Used to be great. Not anymore." — Style Relic voice directly
- These answer options ARE the archetypes, written in their own language. Selecting one creates self-identification.

---

## SCREEN 6: Early Social Proof Interstitial

- **Kind:** Interstitial (no question)
- **Progress bar:** ~18%

---

**VISUAL ELEMENTS (card style, warm cream background, pink accent left border):**

> **"I used to get dressed in 20 minutes and feel great. Somewhere between two kids and a job change, I lost the plot entirely. I would stand at my closet for 20 minutes and still leave the house feeling wrong."**
>
> — **Sarah M.**, 41, used to describe herself as "used to be great, not anymore"

**Below the quote, small centered text:**
> 73% of women who take this quiz describe the same pattern.

**CTA Button:**
> That sounds familiar — keep going →

---

**Design notes:**
- The interstitial appears early because the Style Relic/Closet Paralytic blend needs validation immediately — before she can click away.
- Sarah's voice is specific: "lost the plot entirely" is not marketing language. It's how she actually thinks about it.
- The 73% stat makes her feel part of a group, not isolated.

---

## SCREEN 7: The Morning Ritual

- **Kind:** Step
- **Progress bar:** ~22%

---

**Title (28px, bold):**
> On a typical morning, how does getting dressed go?

---

**Question Type:** Single-choice list

**Answer Options:**
- I try on multiple things, reject them all, and grab what I always grab
- I stare at my closet for a while, then panic-dress
- I just grab the first thing and feel bad about it all day
- I've basically pre-decided — same things on rotation
- It depends on the day, but "easy" is rare

**Design notes:**
- Every option describes some version of failure. Because for this woman, success is rare. The question isn't "is getting dressed hard?" — it's assumed. The question is HOW it's hard.
- "I stare at my closet for a while, then panic-dress" is the Closet Paralytic in four words.

---

## SCREEN 8: The Try-On Loop

- **Kind:** Step
- **Progress bar:** ~26%

---

**Title (28px, bold):**
> When you try something on and it doesn't feel right, what usually happens?

---

**Question Type:** Single-choice list

**Answer Options:**
- I put it back and try something else until I give up
- I wear it anyway and feel off all day
- I change my whole plan — bag stays home, event skipped
- I try to fix it (different shoes, different top) and it still doesn't work
- I've stopped trying on things. I just grab what I know works.

**Design notes:**
- "Bag stays home, event skipped" surfaces the real cost of closet paralysis: life avoidance. This is not about clothes.
- "I've stopped trying on things" is the Stage 3 capitulation — the Style Relic who gave up.

---

## SCREEN 9: Wardrobe Composition — Tops

- **Kind:** Step
- **Progress bar:** ~30%

---

**Title (28px, bold):**
> How many tops would you say you own?

**Subtitle (16px, muted):**
> Include everything — tees, blouses, sweaters, tanks.

---

**Question Type:** Single-choice list

**Answer Options:**
- Fewer than 10
- 10–20
- 20–35
- 35–50
- More than 50 (honestly not sure)

**Design notes:**
- This begins the inventory audit. It's practical, almost clinical — which is the point. After two emotional screens, the shift to inventory feels grounding.
- "Honestly not sure" normalizes not knowing how much you own — and subtly flags overconsumption without shaming it.

---

## SCREEN 10: What She Always Reaches For

- **Kind:** Step
- **Progress bar:** ~33%

---

**Title (28px, bold):**
> When you actually get dressed without overthinking, what do you almost always reach for?

**Subtitle (16px, muted):**
> Pick the combo that's basically your default.

---

**Question Type:** Single-choice list

**Answer Options:**
- Jeans + a top (any top, just jeans)
- Black anything — as long as it's black
- Leggings and something comfortable
- A dress or jumpsuit (one piece, less thinking)
- Whatever's on the chair / recently worn
- I genuinely rotate — no default

**Design notes:**
- "The chair" is deeply real. Calling it out by name — not "recently worn" but "what's on the chair" — creates a moment of "they know."
- The default outfit is also the data point that makes the results screen meaningful: "Your most-used formula is X. Here's how to make it do more work."

---

## SCREEN 11: What She Always Ignores

- **Kind:** Step
- **Progress bar:** ~36%

---

**Title (28px, bold):**
> And what do you consistently skip over — even though you own it?

**Subtitle (16px, muted):**
> The stuff that looked great in the store but never makes it out of the closet.

---

**Question Type:** Multi-select (select all that apply)

**Answer Options:**
- Nice blouses / going-out tops
- Statement pieces (bold colors, patterns)
- Blazers and structured jackets
- Dresses and skirts
- Accessories — jewelry, scarves, belts
- Heels or anything that requires effort
- Pieces I bought for a "specific occasion" that never happens
- Clothes that fit slightly differently than I expected

**CTA Button (replaces auto-advance):**
> Continue →

**Design notes:**
- Multi-select here is important: most women skip multiple categories. Each checked box = one more piece of evidence that her wardrobe is underperforming.
- "Bought for a 'specific occasion' that never happens" — this is the dead inventory every woman over 35 owns.
- This data will directly feed into the results screen: "Your Style Blueprint will show you how to activate your [blazers / statement pieces / etc.]."

---

## SCREEN 12: The Nicest Pieces Question

- **Kind:** Step
- **Progress bar:** ~40%

---

**Title (28px, bold):**
> How often do you wear the nicest things you own?

---

**Question Type:** Single-choice list

**Answer Options:**
- Rarely or never — I'm "saving" them
- Maybe once a month, for specific occasions
- A few times a year if I remember I have them
- Honestly, I forget they exist
- I don't have "nice" things — I stopped buying them

**Design notes:**
- "I'm saving them" — the classic closet paralysis behavior. Clothes so nice they become unwearable by association.
- "I forget they exist" is both funny and devastating. It's the $200 blouse at the back of the rail.
- This question surfaces the emotional cost of the paralysis beyond the morning: she's not even getting use from the investment she's already made.

---

## SCREEN 13: Past Confidence Anchor (Style Relic hook)

- **Kind:** Step
- **Progress bar:** ~44%

---

**Title (28px, bold):**
> Did there used to be a time when getting dressed felt easier?

---

**Question Type:** Single-choice list

**Answer Options:**
- Yes — and I miss it more than I expected
- Somewhat — it was never easy, but it was easier
- Not really, it's always been a struggle
- I'm not sure. It's hard to remember now.

**Design notes:**
- This is the Style Relic screen. But it's written so the Closet Paralytic can answer too — "not really" is valid.
- "I miss it more than I expected" — that qualifier "more than I expected" is doing enormous work. It gives her permission to have real feelings about this without feeling vain.
- The Style Relic who clicks "Yes — and I miss it more than I expected" has just made a micro-commitment: this matters to me. That commitment is the conversion engine.

---

## SCREEN 14: Grief Interstitial

- **Kind:** Interstitial (no question)
- **Progress bar:** ~47%

---

**VISUAL ELEMENTS (warm, non-clinical — feels like a note from a friend):**

**Centered text, 22px, #1E1E1E:**
> Here's something most people don't say out loud:

**Large text, 28px, bold, #FF2A6D:**
> Your style isn't gone.
> It's buried under leggings and life.

**Below, 18px, #6B6B6B:**
> The woman who used to pull an outfit together without thinking — she's still in there. She just doesn't have a system anymore. We're going to build her one.

**CTA Button:**
> Keep going →

---

**Design notes:**
- "Buried under leggings and life" is the exact Style Relic phrase from the brand voice guide.
- This screen is a permission slip: you're allowed to want this back. You're not shallow for grieving it.
- The reframe begins here: not "you lost your style" but "you lost your system." System is fixable. Style is not a thing you find or lose.
- No data question on this screen. Just validation.

---

## SCREEN 15: Self-Study & Solutions Tried

- **Kind:** Step
- **Progress bar:** ~50%

---

**Title (28px, bold):**
> What have you already tried to fix this?

**Subtitle (16px, muted):**
> Pick everything that applies.

---

**Question Type:** Multi-select

**Answer Options:**
- Pinterest / saved outfit inspiration (a lot of it)
- Bought new clothes hoping it would help
- Cleaned out / reorganized the closet
- Watched YouTube or TikTok for style tips
- Followed fashion accounts on Instagram
- Read articles about "building a wardrobe"
- Consulted a stylist / personal shopping
- Nothing yet — that's why I'm here

**CTA Button:**
> Continue →

**Design notes:**
- Every option except "nothing yet" represents something that didn't fully solve the problem — because she's still here.
- The Pinterest/Instagram answer feeds directly into the Scroll Comparer overlap: inspiration-gathering without a formula system.
- "Bought new clothes hoping it would help" is the consumption trap, and naming it without shame is important.

---

## SCREEN 16: Why It Didn't Work

- **Kind:** Step
- **Progress bar:** ~53%

---

**Title (28px, bold):**
> When you tried those things — why do you think they didn't stick?

---

**Question Type:** Single-choice list

**Answer Options:**
- The inspiration never translated to MY body / MY closet
- I'd do well for a week, then slip back into the same habits
- I bought things and they still didn't go with anything
- I never knew what to do with what I already owned
- Life got in the way and I stopped
- I honestly don't know — nothing seems to work for me

**Design notes:**
- "The inspiration never translated to MY body / MY closet" — this is the Scroll Comparer in the blend.
- "I never knew what to do with what I already owned" — this is the exact problem Outfit Formulas solves, stated in her own language.
- She's now implicitly said: "I need help with what I already own." The product pitch is already half-landed.

---

## SCREEN 17: Time Cost Reveal

- **Kind:** Interstitial (no question)
- **Progress bar:** ~56%

---

**VISUAL ELEMENTS (stat card format, cream background with pink accent):**

**Centered headline, 24px, bold:**
> Do you know how much time this is actually costing you?

**Large stat display:**
> **120 hours per year**
> *(that's 5 full days)*
> spent standing in front of a closet feeling stuck.

**Below stat, 16px, muted:**
> That's the average. For women who identify with the "full closet, nothing to wear" feeling — it's often more.

**Second stat:**
> **$2,000+**
> in clothes the average woman owns but never wears.

**Below, 16px, #6B6B6B:**
> Not because she made bad choices. Because she didn't have a system for making them work together.

**CTA Button:**
> I know this feeling — keep going →

---

**Design notes:**
- The stats are from the master context and are real. Presenting them as a reveal — not buried in a list — makes them land harder.
- The reframe in the final line ("not because she made bad choices") is critical. It removes blame. The problem is systemic, not personal.

---

## SCREEN 18: Specific Frustrations (The Mirror)

- **Kind:** Step
- **Progress bar:** ~59%

---

**Title (28px, bold):**
> Which of these frustrations do you recognize?

**Subtitle (16px, muted):**
> Select everything that's true.

---

**Question Type:** Multi-select

**Answer Options:**
- I wear the same 4–5 pieces and pretend I have more
- I've turned down plans because I couldn't figure out what to wear
- I buy things that look great in the store and never wear them
- I've had the same "I need to sort my closet" thought for months (years?)
- I get compliments on the days I'm not trying, and feel invisible on the days I am
- I look at my closet and feel guilty — about the money, the mess, the waste
- I feel like everyone else has figured this out except me
- Getting dressed used to feel different, and I don't know when that changed

**CTA Button:**
> That's me — continue →

---

**Design notes:**
- "I get compliments on the days I'm not trying, and feel invisible on the days I am" — this is the perfect articulation of the paradox that makes closet paralysis so demoralizing.
- "I feel like everyone else has figured this out except me" — isolation acknowledgment. Critical.
- "Getting dressed used to feel different, and I don't know when that changed" — this is the Style Relic's grief, written for the blend.
- Every checked box = one more layer of problem-ownership before the results screen.

---

## SCREEN 19: Event Avoidance

- **Kind:** Step
- **Progress bar:** ~62%

---

**Title (28px, bold):**
> Have you ever skipped something — or almost skipped it — because you didn't know what to wear?

---

**Question Type:** Single-choice list

**Answer Options:**
- Yes, and more than once
- Yes, once or twice — and it bothered me
- Almost — I've been late because of it
- I've gone, but felt wrong the whole time
- No, I push through it — but it's not fun

**Design notes:**
- This screen converts the abstract frustration into real-life cost. Avoidance. Events missed. Relationships strained.
- "I've gone, but felt wrong the whole time" is as costly as staying home — it just looks different from the outside.
- By this screen, the problem is no longer about clothes at all. It's about showing up to her own life.

---

## SCREEN 20: The Reframe Reveal

- **Kind:** Interstitial (no question)
- **Progress bar:** ~65%

---

**VISUAL ELEMENTS (centered, punchy, warm):**

**Pre-headline (small caps, #FF2A6D, 14px):**
> HERE'S WHAT WE'VE FOUND

**Main text (28px, bold, #1E1E1E):**
> **What if you already own**
> **everything you need?**

**Body text (18px, #6B6B6B):**
> 73% of women who feel like they have nothing to wear are actually sitting on 50 or more outfits they've never put together.
>
> You don't have a wardrobe problem.
>
> **You have a visibility problem.**

**Below (18px, #1E1E1E):**
> The clothes are there. The combinations aren't obvious. That's what a Style Blueprint fixes — not by adding more, but by making what you have finally visible.

**CTA Button (#FF2A6D):**
> Build my Blueprint →

---

**Design notes:**
- This is the central reframe of the entire funnel. It needs its own screen with no competing elements.
- "Visibility problem" is the key phrase. It's specific, it's solvable, and it doesn't blame her.
- The 73% stat does two things: validates her experience AND shows her there's a systemic fix, not a personal failing.

---

## SCREEN 21: Blueprint Input — Daily Outfit Goals

- **Kind:** Step
- **Progress bar:** ~68%

---

**Title (28px, bold):**
> What do you most want your daily outfits to feel like?

**Subtitle (16px, muted):**
> This goes into your Blueprint — pick what matters most.

---

**Question Type:** Single-choice list

**Answer Options:**
- Put-together without looking like I tried too hard
- Comfortable AND like I actually got dressed
- Like I have my life together (even when I don't)
- Like myself again — whoever that is
- Like I could run into anyone and not want to hide
- Something I feel proud to be seen in

**Design notes:**
- "Like myself again — whoever that is" — this is the Style Relic's deepest answer, and it's vulnerable enough to be real.
- "Even when I don't" — permission to be imperfect while still looking like you have it together. This is the hook for the Closet Paralytic who doesn't want to be a "fashion person."
- The answers will appear on the results screen: "Your Blueprint priority: [FEEL LIKE YOURSELF AGAIN]. Here's what that looks like as a formula."

---

## SCREEN 22: Blueprint Input — Closet Constraints

- **Kind:** Step
- **Progress bar:** ~71%

---

**Title (28px, bold):**
> What's the biggest obstacle to getting dressed better right now?

---

**Question Type:** Single-choice list

**Answer Options:**
- I don't know how to put things together
- My clothes don't seem to go with each other
- My body is different than it was — old formulas don't work
- I'm too tired to think about it in the morning
- I feel guilty buying new things, but I also feel stuck
- I don't know my own style anymore
- All of the above, honestly

**Design notes:**
- "My body is different than it was — old formulas don't work" — this is the Meno-Morpher voice within the Style Relic story. It belongs here because body change is often WHY the Style Relic became a Style Relic.
- "I don't know my own style anymore" — this is the relic grief without calling it grief.
- "All of the above" is always the honest answer for 60% of women in this funnel. Offer it and let them select it — it's the highest-commitment answer.

---

## SCREEN 23: Formula Style Preference

- **Kind:** Step
- **Progress bar:** ~74%

---

**Title (28px, bold):**
> When you imagine an outfit that works perfectly for you — what does it feel like?

**Subtitle (16px, muted):**
> Not what it looks like — what it FEELS like.

---

**Question Type:** Single-choice list

**Answer Options:**
- Easy. Done in 5 minutes. No second-guessing.
- Pulled together — like I thought about it, even if I didn't.
- Comfortable enough to forget I'm wearing it.
- Confident. Like I walked in and people noticed in a good way.
- Like me — not a version of someone else's idea of style.

**Design notes:**
- Asking about FEELING, not looking, is the Outfit Formulas brand distinction.
- These answers directly feed the results screen language: "Based on your answers, your Style Blueprint prioritizes [ease / confidence / authenticity]."

---

## SCREEN 24: Color Confidence

- **Kind:** Step
- **Progress bar:** ~77%

---

**Title (28px, bold):**
> How do you feel about color in your outfits right now?

---

**Question Type:** Single-choice list

**Answer Options:**
- I stick to neutrals — I can't go wrong
- I own color but it never makes it out of the closet
- I used to wear color more. Not anymore.
- I don't know what colors work on me
- I mix color in freely — this isn't my issue

**Design notes:**
- "I used to wear color more. Not anymore." — the Style Relic again. Color is often the first casualty of losing style confidence.
- "I don't know what colors work on me" feeds into the Outfit Formulas color formula system.
- The last option ("I mix color in freely") is valid — and it tells the system: color is not her pain point. Other elements are.

---

## SCREEN 25: Email Capture

- **Kind:** Step — Email input
- **Progress bar:** ~82%

---

**Title (28px, bold):**
> Where should we send your Style Blueprint?

**Subtitle (16px, muted):**
> We'll also send your personalized formula guide — free.

---

**Input field:** Email address (placeholder: "your@email.com")

**Below input, small print (#6B6B6B):**
> We never sell your data. Unsubscribe anytime. Promise.

**CTA Button:**
> Build My Blueprint →

---

**Design notes:**
- The email is framed as delivery, not capture. "Where should we send" not "enter your email to continue."
- The "personalized formula guide" bonus justifies the ask without making it feel like a gate.

---

## SCREEN 26: Name Capture

- **Kind:** Step — Name input
- **Progress bar:** ~85%

---

**Title (28px, bold):**
> What's your first name?

**Subtitle (16px, muted):**
> Your Blueprint will be personalized to you.

---

**Input field:** First name (placeholder: "First name")

**CTA Button:**
> Almost there →

---

**Design notes:**
- Name capture here enables personalization on the results screen and paywall ("{{firstName}}, your Blueprint is ready").
- Keep it light — no last name, no birthday, nothing that feels like a form.

---

## SCREEN 27: Blueprint Loading Screen

- **Kind:** Interstitial — Loading / Results build
- **Progress bar:** 100% (animating)

---

**VISUAL ELEMENTS:**

**Centered animated progress bar (pink, fills from left to right over 8–10 seconds)**

**Text above bar (20px, bold):**
> Building your Style Blueprint...

**Rotating status messages (swap every 2 seconds):**
- "Analyzing your wardrobe patterns..."
- "Mapping your go-to formulas..."
- "Identifying your hidden outfit combinations..."
- "Calculating your style confidence gaps..."
- "Finalizing your personalized blueprint..."

**Below bar, smaller text (#6B6B6B):**
> Based on your answers, we've identified [X] outfit formulas hiding in your closet.

*(The [X] should dynamically reflect a calculated number based on closet size answers — can be 15–50+ range)*

---

**Trustpilot-style review strip (appears at 60% load):**

> ⭐⭐⭐⭐⭐
> *"I cried a little. I opened my closet the next morning and actually felt excited. I've worn the same jeans for 6 years — I put on a dress. A dress!"*
> — **Rachel T.**, 44

> ⭐⭐⭐⭐⭐
> *"I thought I needed a whole new wardrobe. I needed a system. My closet has been the same for two years and it works now."*
> — **Michelle B.**, 38

**Design notes:**
- The loading screen is not just UX — it's the psychological transition from "I just answered questions" to "something is being built for me specifically."
- The rotating messages mirror her exact quiz data back at her in product language.
- Reviews must sound like real women, not marketing copy.

---

## SCREEN 28: PAYWALL — SLOWDIVE ARCHITECTURE
### Limited Time + Per-Day Pricing + Live Buyer Counter + Sticky Footer

- **Kind:** Custom HTML paywall screen (warm cream background, #FF2A6D accents)
- **Paywall Architecture:** SLOWDIVE CHAKRA — live urgency, per-day pricing, sticky footer
- **Checkout URL:** `https://app.outfitformulas.com/checkout/style-blueprint`

---

### STICKY URGENCY HEADER (pinned to top of viewport, always visible)

```
🔥 LIMITED TIME OFFER   |   50% OFF reserved for: [09:47]   |   Offer expires when timer hits zero
```

- Background: #FF2A6D (vibrant pink), white bold text, full width
- Countdown ticks in real time (MM:SS)
- Resets on page refresh (FOMO design, intentional)

---

### LIVE BUYER COUNTER (appears just below sticky header)

```
👩 147 women unlocked their Style Blueprint in the last hour
```

- Counter animates up/down slightly every 8–12 seconds to simulate live activity
- Small pulsing green dot to indicate "live"
- Muted background strip — not intrusive but always visible

---

### HEADLINE SECTION

**Pre-headline (small caps, #FF2A6D, 14px):**
> YOUR STYLE BLUEPRINT IS READY

**Main Headline (36px, bold, #1E1E1E):**
> **{{firstName}}, your closet is hiding outfits you've never seen.**
> **Here's the system to find them.**

**Sub-headline (18px, #6B6B6B):**
> Based on your quiz answers, we've built your personal Style Blueprint — a formula-based system for the clothes you already own. Unlock it before your offer expires.

---

### RESULTS PREVIEW (partial reveal — hook before pricing)

**Section header (20px, bold):**
> Here's what your Blueprint found:

**Preview cards (3, styled with pink left border, cream background):**

```
🔎 YOUR DEFAULT FORMULA
You almost always reach for [jeans + a top]. Your Blueprint
turns this into 8 variations — without buying anything new.
```

```
📦 YOUR IGNORED INVENTORY
You're consistently skipping [blazers / statement pieces / etc.].
Your Blueprint activates these into 3 complete outfit formulas.
```

```
🎯 YOUR STYLE PRIORITY
Your #1 goal: [feel like yourself again].
Your Blueprint is built around this — not someone else's idea of style.
```

**Below preview cards (italic, 16px, muted):**
> *The full Blueprint — including your 30-day outfit calendar, your formula cheat sheet, and your daily outfit suggestions — unlocks when you start your plan.*

---

### PLAN SELECTOR

**Section header (20px, bold):**
> Choose your plan — all prices shown per day:

---

**PLAN CARD 1 — 12-Week Plan** *(pre-selected, glowing pink border)*

```
┌─────────────────────────────────────────────────────┐
│  ⭐ MOST POPULAR                                     │
│                                                      │
│  12-Week Style Blueprint Plan                        │
│  ~~$44.99~~ → $19.99                                 │
│                                                      │
│  Just $0.24/day                                      │
│  Less than a coffee. For the outfit you've wanted    │
│  for years.                                          │
│                                                      │
│  ✓ Full Style Blueprint access (12 weeks)           │
│  ✓ Daily outfit suggestions from YOUR closet        │
│  ✓ 30-day outfit calendar                           │
│  ✓ Formula cheat sheet                              │
│  ✓ Cancel anytime                                   │
└─────────────────────────────────────────────────────┘
```

---

**PLAN CARD 2 — 4-Week Plan** *(unselected)*

```
┌─────────────────────────────────────────────────────┐
│  4-Week Style Blueprint Plan                         │
│  ~~$19.99~~ → $9.99                                  │
│                                                      │
│  Just $0.36/day                                      │
│                                                      │
│  ✓ Full Style Blueprint access (4 weeks)            │
│  ✓ Daily outfit suggestions from YOUR closet        │
│  ✓ Cancel anytime                                   │
└─────────────────────────────────────────────────────┘
```

---

**PLAN CARD 3 — 1-Week Plan** *(unselected)*

```
┌─────────────────────────────────────────────────────┐
│  1-Week Trial Plan                                   │
│  ~~$9.99~~ → $4.99                                   │
│                                                      │
│  Just $0.71/day                                      │
│                                                      │
│  ✓ Full Style Blueprint access (1 week)             │
│  ✓ Daily outfit suggestions from YOUR closet        │
│  ✓ Cancel anytime                                   │
└─────────────────────────────────────────────────────┘
```

---

### PRIMARY CTA BUTTON (full-width, #FF2A6D, white bold text, 12px border-radius)

```
[ Unlock My Style Blueprint → ]
```

*Sub-copy beneath button:*
> Secure checkout. Cancel anytime. Your Blueprint is already built — this is just the unlock.

---

### CONDITIONAL GUARANTEE BLOCK

**Styled card (cream background, pink border, centered):**

```
🛡️ THE OUTFIT FORMULAS PROMISE

If you use your Style Blueprint formulas for 4 weeks
and getting dressed doesn't feel measurably better —
we'll refund every penny.

No forms. No judgment. Just email us.

The condition: actually use the formulas.
If you do and it doesn't work, we want to know — and we want to make it right.
```

---

### SOCIAL PROOF SECTION

**Stat strip (centered, bold):**
> ⭐⭐⭐⭐⭐ 4.8 stars · 147,000+ women · 12,400+ reviews

**Three testimonials (stacked cards):**

> ⭐⭐⭐⭐⭐
> *"I used to wear the same jeans and a black top every single day. Not because I liked it — because it was the only thing that didn't feel wrong. Three weeks in, I've worn pieces I forgot I owned. Last Tuesday I wore a blazer."*
> — **Jennifer K.**, 46

> ⭐⭐⭐⭐⭐
> *"I'm not a 'fashion person.' I want to be clear about that. This is not about fashion. It's about not dreading the morning. I don't dread the morning anymore."*
> — **Allison P.**, 39

> ⭐⭐⭐⭐⭐
> *"I used to get dressed so easily. That was 12 years ago. I honestly thought that version of me was just... gone. She wasn't. She just needed a formula."*
> — **Dana M.**, 52

---

### PAYMENT METHOD LOGOS

**Row of logos (centered, grey scale):**
```
[Visa]  [Mastercard]  [American Express]  [PayPal]  [Apple Pay]
```

**Below logos:**
> 🔒 256-bit SSL encryption · Your payment information is never stored

---

### STICKY FOOTER (always visible, pinned to bottom of viewport)

```
⏱ 50% OFF reserved for: [09:47]   |   147 women unlocked in the last hour   [ Unlock My Blueprint → ]
```

- Background: #1E1E1E (deep charcoal), white text, #FF2A6D CTA button
- Countdown syncs with sticky header
- CTA button scrolls to plan selector or triggers checkout
- Full-width on mobile (the primary view)

---

**Design notes for Screen 28:**
- The sticky header AND sticky footer create a permanent urgency frame — the countdown is always visible regardless of scroll position.
- Per-day pricing ($0.24/day) makes the 12-week plan feel trivial compared to the morning she spends 20 minutes standing at her closet.
- The results preview section (partial reveal before pricing) creates desire before price is shown — she's already seen the blueprint teaser. Now she just needs to unlock it.
- The live counter ("147 women unlocked their blueprint in the last hour") is the specific FOMO tuned to women who've been putting this off: "they did it. You're still at your closet."
- The conditional guarantee removes the remaining objection: "what if it doesn't work?" — it doesn't if you don't use it. And if you use it and it doesn't work, you get your money back.
- **Paywall model: SLOWDIVE CHAKRA (limited time + per-day pricing + live buyer counter + sticky footer)**

---

# FUNNEL K SCREEN SUMMARY

| Screen | Type | Content |
|--------|------|---------|
| 1 | Start node | Entry |
| 2 | Landing | Headline + CTA (no question) |
| 3 | Single-choice | Age |
| 4 | Single-choice | Lifestyle context |
| 5 | Single-choice | Current style self-description |
| 6 | Interstitial | Early social proof (Sarah M. quote) |
| 7 | Single-choice | Morning ritual |
| 8 | Single-choice | Try-on loop behavior |
| 9 | Single-choice | Wardrobe composition — tops |
| 10 | Single-choice | What she always reaches for |
| 11 | Multi-select | What she always ignores |
| 12 | Single-choice | How often she wears her nicest pieces |
| 13 | Single-choice | Past style confidence (Style Relic hook) |
| 14 | Interstitial | "Buried under leggings and life" reframe |
| 15 | Multi-select | What she's already tried |
| 16 | Single-choice | Why it didn't work |
| 17 | Interstitial | Time/money cost stats reveal |
| 18 | Multi-select | Specific frustrations mirror |
| 19 | Single-choice | Event avoidance |
| 20 | Interstitial | "Visibility problem" reframe |
| 21 | Single-choice | Blueprint input — daily outfit goals |
| 22 | Single-choice | Blueprint input — closet constraints |
| 23 | Single-choice | Formula style preference (feel, not look) |
| 24 | Single-choice | Color confidence |
| 25 | Email input | Email capture |
| 26 | Name input | Name capture |
| 27 | Interstitial | Blueprint loading screen |
| 28 | Paywall | Slowdive architecture |

**Total: 28 screens** ✅

---

---

---

# FUNNEL L: "Your Complete Style Report"
## Target: Scroll Comparer + Meno-Morpher blend
## Paywall Architecture: Nebula — One-Time Report Purchase (NOT subscription)
## Quiz Length: 27 screens

---

# WHY THIS FUNNEL WORKS FOR THE SCROLL COMPARER + MENO-MORPHER BLEND

## The Core Insight

These two women have something specific in common: **they've been let down by formulas that weren't built for their body.**

The Scroll Comparer has 847 Pinterest pins and a closet full of things that looked amazing on someone else. The Meno-Morpher used to have a set of formulas that worked — until her body reorganized itself and the formulas stopped. Different frustrations. Same underlying belief: **there isn't a system that works for my body specifically.**

The genius of the Nebula architecture for this blend: instead of selling a subscription app, we're selling **a Report.** A personalized analysis. A document with their name on it. Not "ongoing access to our platform" — a specific, finite ANSWER built from her specific, finite answers.

This mental model shift is massive for two reasons:
1. The Scroll Comparer **hates subscriptions** — another monthly charge that won't deliver what Instagram promised. A one-time $19.99 report feels controlled, finite, and low-risk.
2. The Meno-Morpher doesn't want an app. She wants an **analysis** — something that sees her body as it is right now, not as it was.

The entire funnel is designed to feel like it's compiling a Report, not selling a product. Progress feels like data gathering, not question answering. Every screen builds toward the reveal.

---

## Stage-by-Stage Psychology Breakdown

### Stage 1 — Body Context (Screens 2–7)
**What it does:** Collects body, lifestyle, and color data framed as "report input."

**Why it works:**

The Meno-Morpher's most painful experience is having stylists, apps, and advice systems treat her body like a standard template. The moment she sees a quiz that asks about her body's *specific changes* — not just current size, but what changed and how — she feels seen in a way she rarely does.

The Scroll Comparer's most painful experience is following advice that was clearly designed for a different body. When the quiz acknowledges "you've seen a lot of advice that doesn't account for YOUR proportions," she relaxes.

The framing throughout Stage 1 is clinical but warm: "We're collecting data for your report." Every question has a visible purpose.

---

### Stage 2 — Lifestyle Analysis (Screens 8–13)
**What it does:** Documents her real life — not her aspirational life — as the context for her formula analysis.

**Why it works:**

Most style advice is written for a generic "modern woman." The Report framing means every question here is building her specific profile: where she actually goes, what she actually does, what she actually needs to get dressed for. The Meno-Morpher who now works from home and needs different outfits than she did 10 years ago sees her reality reflected. The Scroll Comparer who needs work-appropriate outfits that also look like what she saved on Pinterest gets asked about both.

The lifestyle section also surfaces the gap between aspiration and reality — gently, without judgment.

---

### Stage 3 — Color & Pattern Analysis (Screens 14–17)
**What it does:** Collects color and pattern preference data, framed as building her color profile.

**Why it works:**

Color analysis is one of the most desired but least accessible elements of personal styling. The Scroll Comparer has been following influencers who wear colors that don't suit her. The Meno-Morpher has noticed her old color palette stopped working when her skin tone changed (this happens with hormonal shifts, and calling it out specifically creates a moment of "they understand this").

The Report framing makes color analysis feel like expertise, not guesswork.

---

### Stage 4 — Wardrobe Audit (Screens 18–22)
**What it does:** Documents what she actually owns, what she reaches for, and what's wasted.

**Why it works:**

By Stage 4, she's been giving data for 15+ screens. The report is clearly taking shape. The wardrobe audit asks her to confront specific inventory — "how many unused dresses?" "how many things bought from Pinterest/Instagram that don't work?" — and each answer makes the report feel more justified.

"Your report will show you exactly which of these items can be activated with the right formula."

---

### Stage 5 — Report Preview & Unlock (Screens 23–27)
**What it does:** Shows a partial preview of the completed Report, with key insights blurred/locked. Creates desire before pricing appears.

**Why it works:**

The Nebula paywall is about unlocking something that's already been built. The preview screen shows her report structure — with two or three insights visible and the rest blurred. She can see:
- "Your #1 color family is: [BLUR]"
- "Your body proportion formula: [BLUR]"
- "Your top 3 outfit formulas: [BLUR]"

The content is right there. She just needs to unlock it. The one-time $19.99 price makes that feel completely different from "subscribe to yet another app."

---

## The Central Conversion Mechanism

The quiz never sells a subscription. It builds a Report. By the time the paywall appears, she has:

1. Contributed body/lifestyle/color/wardrobe data across 20+ screens (massive sunk cost)
2. Watched a visible progress bar compile "her report" in real time
3. Seen a blurred preview — the report is done, she just can't see it yet
4. Read the table of contents: 6 distinct analysis sections, each one something she actually wants
5. Seen a price tag that's one-time, finite, and smaller than a lipstick

She's not subscribing. She's buying an ANSWER.

---

# THE COMPLETE 27-SCREEN FUNNEL

---

## SCREEN 1: Start (Entry Node)

- **Kind:** Start (invisible entry node)
- **Notes:** Automatically transitions to Screen 2. Platform handles routing.

---

## SCREEN 2: Landing Page

- **Kind:** Step — Landing page (no question)
- **Progress bar:** None

---

**VISUAL ELEMENTS:**

- **Top badge:** `PERSONAL STYLE ANALYSIS` — pill/badge, #FF2A6D text on cream

- **Headline (36–40px, bold, #1E1E1E):**
  > **We're going to analyze your body, your lifestyle, and your wardrobe.**
  > **Then give you a Report.**

- **Sub-headline (18px, #6B6B6B):**
  > Not a generic style guide. Not a mood board. A personalized analysis built from your specific answers — your colors, your proportions, your wardrobe, your life.

- **Report visual mockup:** Illustrated "Your Complete Style Report" document preview — showing a cover page with "[Your Name]'s Style Report" and partially visible internal pages

- **3 trust points (horizontal, icon + text):**
  - 📊 Built from YOUR answers
  - 🔒 One-time purchase — no subscription
  - ⏱ 5-minute analysis

- **CTA Button (#FF2A6D, full-width):**
  > Start My Analysis →

- **Trust line (small, muted):**
  > 147,000+ women have generated their Style Report

---

**DESIGN NOTES:**
- The word "Report" is doing all the work. This is NOT "take our style quiz." This is "we are building something for you."
- "No subscription" appears on the landing page. For the Scroll Comparer who hates subscription fatigue, this alone removes a barrier.
- The report mockup visual creates the object — she's not answering questions, she's generating a document.

---

## SCREEN 3: Age

- **Kind:** Step
- **Progress bar:** ~5%

---

**Report-building context bar (above question, small, pink text):**
> 📊 Building your Style Report — Section 1 of 6: Profile

**Title (28px, bold):**
> How old are you?

**Subtitle (16px, muted):**
> Your Report adjusts for body changes that happen at different life stages.

---

**Question Type:** Single-choice list, auto-advance

**Answer Options:**
- Under 35
- 35–44
- 45–54
- 55–64
- 65+

**Design notes:**
- "Body changes that happen at different life stages" — this is specific Meno-Morpher language without using the word menopause on screen 3. It signals: we know about this.
- The "Section 1 of 6" context bar appears on every question screen going forward. It visually represents the report being built.

---

## SCREEN 4: Body Change Question

- **Kind:** Step
- **Progress bar:** ~10%
- **Report context bar:** 📊 Section 1 of 6: Profile

---

**Title (28px, bold):**
> Has your body changed significantly in the last 3–5 years?

**Subtitle (16px, muted):**
> This affects which formulas your Report recommends.

---

**Question Type:** Single-choice list

**Answer Options:**
- Yes — my body reorganized itself and my old formulas don't work anymore
- Yes — I've gained weight and don't know what works now
- Somewhat — some things fit differently, I'm adapting
- Not much — my body is fairly stable
- I'm not sure what works anymore, regardless of change

**Design notes:**
- "My body reorganized itself" — this is directly from the Meno-Morpher voice guide. It's not standard medical language. It's how she actually experiences it.
- "Old formulas don't work anymore" — this is the exact product vocabulary. She's already using it.
- Selecting the top option begins a branching path within the results section that specifically addresses body-transition formula-building.

---

## SCREEN 5: Body Area Confidence

- **Kind:** Step
- **Progress bar:** ~15%
- **Report context bar:** 📊 Section 1 of 6: Profile

---

**Title (28px, bold):**
> Which parts of your body do you feel most comfortable dressing right now?

**Subtitle (16px, muted):**
> Your Report builds formulas that work WITH your body — starting from what you already feel good about.

---

**Question Type:** Multi-select

**Answer Options:**
- Shoulders and neckline
- Arms and upper body
- Waist and midsection
- Hips and lower body
- Legs
- I feel pretty good about most of it
- Honestly, none of it right now

---

**CTA Button:**
> Continue →

**Design notes:**
- "Starting from what you already feel good about" — this is an important reframe. Not "what are your problem areas?" but "what do you already like?"
- "Honestly, none of it right now" is the honest Meno-Morpher answer and it deserves to be an option.
- This data feeds the results: "Your Report prioritizes formulas that showcase your shoulders and neckline."

---

## SCREEN 6: Proportion Awareness

- **Kind:** Step
- **Progress bar:** ~19%
- **Report context bar:** 📊 Section 1 of 6: Profile

---

**Title (28px, bold):**
> How would you describe your proportions right now?

**Subtitle (16px, muted):**
> "Proportions" means how your top and bottom halves relate — not a size or shape label.

---

**Question Type:** Single-choice list

**Answer Options:**
- More volume on top than bottom
- More volume on bottom than top
- Pretty balanced — similar top and bottom
- Long torso, shorter legs
- Short torso, longer legs
- I genuinely don't know — I've never thought about it this way

**Design notes:**
- The subtitle defines "proportions" in a non-body-type way. No hourglass/pear/apple language. Just descriptive.
- "I've never thought about it this way" is always an option when asking about concepts that many women haven't been taught.
- This is the Scroll Comparer's core frustration: nothing fits because no one talks to her about her actual proportions.

---

## SCREEN 7: Progress Interstitial — Report Building

- **Kind:** Interstitial
- **Progress bar:** ~22%

---

**VISUAL ELEMENTS (centered, warm cream, pink accent):**

**Animated mini progress bar labeled:**
> ✅ Profile section complete

**Centered text (22px, bold):**
> Good. Now we're building Section 2 of your Report:
> **Lifestyle Analysis**

**Below (16px, muted):**
> The clothes you need depend entirely on the life you actually live — not the life you wish you had. This section makes sure your Report works for your real week.

**CTA Button:**
> Continue →

---

**Design notes:**
- Interstitials between sections reinforce the report-compilation feeling. Each section completion feels like progress toward something tangible.
- "The life you actually live — not the life you wish you had" — this is gentle validation for the Meno-Morpher who has a different life than she did 10 years ago, and the Scroll Comparer who's been building a Pinterest board for a life she doesn't have.

---

## SCREEN 8: Lifestyle — Primary Context

- **Kind:** Step
- **Progress bar:** ~26%
- **Report context bar:** 📊 Section 2 of 6: Lifestyle Analysis

---

**Title (28px, bold):**
> What does your typical week look like?

---

**Question Type:** Single-choice list

**Answer Options:**
- Mostly at home (WFH or not working)
- Mix of home and in-person (office, errands, social)
- Office or workplace most days
- Very active social life — events, travel, variety
- Each week is completely different — hard to categorize

**Design notes:**
- The WFH reality is significant for the Meno-Morpher, who may have retired, shifted to part-time, or changed her daily context dramatically.
- The Scroll Comparer who's office-based is specifically frustrated by Pinterest looks that don't translate to a real office — this lifestyle data makes the report feel precise.

---

## SCREEN 9: Social Context

- **Kind:** Step
- **Progress bar:** ~29%
- **Report context bar:** 📊 Section 2 of 6: Lifestyle Analysis

---

**Title (28px, bold):**
> Outside of work or home life, what do you dress for regularly?

**Subtitle (16px, muted):**
> Select everything that's a real part of your life.

---

**Question Type:** Multi-select

**Answer Options:**
- Casual going out (restaurants, coffee, errands)
- Social events — parties, dinners, gatherings
- Travel (weekend trips, vacations)
- Fitness / active activities
- Family occasions (kids' events, family visits)
- Date nights / romantic occasions
- Professional events outside of work
- Not much — my social calendar is quieter than it used to be

**CTA Button:**
> Continue →

**Design notes:**
- "Not much — my social calendar is quieter than it used to be" — this is the Meno-Morpher's reality and the Style Relic's grief without calling it that. Naming it is an act of acknowledgment.
- The multi-select here ensures the Report covers all her actual contexts, not just the dominant one.

---

## SCREEN 10: The Aspiration Gap (Scroll Comparer hook)

- **Kind:** Step
- **Progress bar:** ~33%
- **Report context bar:** 📊 Section 2 of 6: Lifestyle Analysis

---

**Title (28px, bold):**
> When you see an outfit you love online — what usually happens when you try it yourself?

---

**Question Type:** Single-choice list

**Answer Options:**
- It never looks the same on my body — I don't know why
- I can tell it won't work before I even try, so I don't
- Sometimes it works, mostly it doesn't — I can't predict it
- I've stopped saving inspiration because it just frustrates me
- I can usually make it work with some adjustments

**Design notes:**
- "I don't know why" — the Scroll Comparer's defining frustration is not the gap itself but her inability to diagnose it.
- "I've stopped saving inspiration because it just frustrates me" — this is the Scroll Comparer who has given up on the behavior that defined her. This is the deepest version of the archetype.
- The Report will answer "why" — it will explain her proportions and color in a way that makes the gap make sense.

---

## SCREEN 11: Shopping Behavior

- **Kind:** Step
- **Progress bar:** ~36%
- **Report context bar:** 📊 Section 2 of 6: Lifestyle Analysis

---

**Title (28px, bold):**
> How do you shop for clothes right now?

---

**Question Type:** Single-choice list

**Answer Options:**
- Online — based on what I see on social media or influencers
- Online — I browse and buy, but it's hit-or-miss
- In-store — I need to try things on first
- I barely shop — nothing seems right so I avoid it
- I shop a lot but rarely love what I end up with
- I try to buy intentionally but don't always know what I need

**Design notes:**
- "I shop a lot but rarely love what I end up with" — this is the Scroll Comparer in buying mode. High activity, low satisfaction.
- "I barely shop — nothing seems right so I avoid it" — Meno-Morpher who's checked out.
- Both answers are equally valid. Neither is judged.

---

## SCREEN 12: The Savings/Waste Question

- **Kind:** Interstitial (with embedded stat)
- **Progress bar:** ~39%

---

**VISUAL ELEMENTS:**

**Bold centered stat (28px, #FF2A6D):**
> The average woman has $2,000 in clothes she never wears.

**Below (18px, #1E1E1E):**
> Not because she made bad choices.
> Because she was buying without a formula.

**Smaller text (16px, #6B6B6B):**
> Your Report includes a "Stop Buying" list — the specific types of items your data says you already have too many of, and a "Hidden Gems" list — the pieces you own that your formulas don't use yet.

**CTA Button:**
> That's money I'd rather keep — continue →

---

**Design notes:**
- The "Stop Buying" list and "Hidden Gems" list are specific Report deliverables — teasing them here builds desire for the Report before pricing appears.
- This screen converts the shopping frustration from an emotional problem to a financial one — making the $19.99 Report feel like an investment with obvious ROI.

---

## SCREEN 13: Progress Interstitial — Section Transition

- **Kind:** Interstitial
- **Progress bar:** ~42%

---

**Centered text:**

> ✅ Lifestyle section complete

**22px, bold:**
> Now: Section 3 — Color Analysis

**16px, muted:**
> Color is the single biggest variable that determines whether an outfit works on you. Your Report includes your specific color profile — what works, what doesn't, and why.

**CTA Button:**
> Continue →

---

## SCREEN 14: Color Relationship

- **Kind:** Step
- **Progress bar:** ~45%
- **Report context bar:** 📊 Section 3 of 6: Color Analysis

---

**Title (28px, bold):**
> How would you describe your relationship with color in your wardrobe?

---

**Question Type:** Single-choice list

**Answer Options:**
- Mostly neutrals — it feels safe
- I love color but can't figure out what works on me
- I used to wear more color. Something changed and now I don't.
- I wear color freely — this isn't my problem area
- My old colors don't seem to work the same way on me anymore

**Design notes:**
- "Something changed and now I don't" — the Meno-Morpher's experience with color is real: skin tone shifts significantly with hormonal changes, and colors that worked in her 30s can look flat or harsh in her 50s.
- "My old colors don't seem to work the same way on me anymore" — this is the Meno-Morpher color experience named directly.
- The Report's color section will provide specific guidance here — this question makes that guidance feel essential.

---

## SCREEN 15: Skin Tone Context

- **Kind:** Step
- **Progress bar:** ~48%
- **Report context bar:** 📊 Section 3 of 6: Color Analysis

---

**Title (28px, bold):**
> How would you describe your overall skin tone?

**Subtitle (16px, muted):**
> This determines which color families work best — and which ones wash you out.

---

**Question Type:** Single-choice list

**Answer Options:**
- Very fair / light
- Fair with pink/cool undertones
- Medium / olive
- Medium-dark / warm undertones
- Dark / deep
- I genuinely don't know — colors have always confused me

**Design notes:**
- Clean, descriptive options — no racial categories, no undertone jargon.
- "Colors have always confused me" is always a valid option and is likely the Scroll Comparer's answer.

---

## SCREEN 16: Pattern & Print Comfort

- **Kind:** Step
- **Progress bar:** ~51%
- **Report context bar:** 📊 Section 3 of 6: Color Analysis

---

**Title (28px, bold):**
> How do you feel about patterns and prints?

---

**Question Type:** Single-choice list

**Answer Options:**
- I love them but they're hard to style
- I stick to solids — patterns feel risky
- I own some but they never make it out of the closet
- I wear them freely and it works for me
- I used to love them. Not anymore.

**Design notes:**
- "I used to love them. Not anymore." — again, the Style Relic / Meno-Morpher grief without naming it.
- "I love them but they're hard to style" — the Scroll Comparer who saves pattern outfit inspo but can't execute it.

---

## SCREEN 17: Progress Interstitial — Section 4

- **Kind:** Interstitial
- **Progress bar:** ~54%

---

**Centered:**

> ✅ Color analysis complete

**22px bold:**
> Section 4: Wardrobe Audit

**16px muted:**
> This is where we find out what you're actually working with — and what's been hiding in plain sight.

**CTA:**
> Show me what I'm missing →

---

## SCREEN 18: Wardrobe Volume

- **Kind:** Step
- **Progress bar:** ~57%
- **Report context bar:** 📊 Section 4 of 6: Wardrobe Audit

---

**Title (28px, bold):**
> Roughly how many clothing items do you own total?

**Subtitle (16px, muted):**
> Include everything — everyday pieces, occasion wear, things in the back of the closet.

---

**Question Type:** Single-choice list

**Answer Options:**
- Fewer than 30 items
- 30–60 items
- 60–100 items
- 100–150 items
- More than 150 (honestly hard to count)

**Design notes:**
- "Honestly hard to count" normalizes closet volume without shame.
- This data gives the results screen the formula: she owns 100+ items and wears 20% of them = she's sitting on 80+ unworn pieces. That's her "hidden gems" list.

---

## SCREEN 19: The Instagram/Pinterest Graveyard

- **Kind:** Step
- **Progress bar:** ~60%
- **Report context bar:** 📊 Section 4 of 6: Wardrobe Audit

---

**Title (28px, bold):**
> How many things in your closet did you buy because you saw them on someone else — online, in a store, on TV?

**Subtitle (16px, muted):**
> Be honest. No judgment here.

---

**Question Type:** Single-choice list

**Answer Options:**
- Almost everything — I shop based on what I see
- A lot — probably half my closet
- Some — maybe 25-30%
- A few specific pieces I regret
- Barely any — I mostly know what works for me

**Design notes:**
- This question names the Scroll Comparer's behavior precisely: buying based on seeing. The subtitle ("no judgment here") creates safety.
- The data feeds into the "Stop Buying" list section of the report.

---

## SCREEN 20: The Never-Worn Count

- **Kind:** Step
- **Progress bar:** ~63%
- **Report context bar:** 📊 Section 4 of 6: Wardrobe Audit

---

**Title (28px, bold):**
> Roughly how many things in your closet still have tags on them, or have been worn fewer than twice?

---

**Question Type:** Single-choice list

**Answer Options:**
- None or very few — I wear everything I buy
- Maybe 5–10 items
- Somewhere between 10–20
- More than 20 — honestly it's embarrassing
- I don't want to think about this number

**Design notes:**
- "I don't want to think about this number" — this is the answer that needs to be there. Acknowledging the discomfort is more honest than pretending everyone knows their inventory.
- This number directly determines the size of her "Hidden Gems" list in the Report. High never-worn count = more to unlock.

---

## SCREEN 21: What She's Reaching For vs. What She Owns

- **Kind:** Step
- **Progress bar:** ~67%
- **Report context bar:** 📊 Section 4 of 6: Wardrobe Audit

---

**Title (28px, bold):**
> What do you reach for most, even though your closet has so much more?

---

**Question Type:** Multi-select

**Answer Options:**
- The same jeans or trousers
- The same black or neutral top
- Comfortable lounge-adjacent pieces
- A specific dress that always works
- Whatever's clean and requires no thought
- Honestly, just the 4–5 things I know work

**CTA Button:**
> Continue →

**Design notes:**
- "Whatever's clean and requires no thought" — Closet Paralytic voice within the Scroll Comparer blend.
- "Just the 4–5 things I know work" — the wardrobe wearing 20%/80% stat made visible.
- The Report will activate the other 80% with formulas.

---

## SCREEN 22: Wardrobe Goals

- **Kind:** Step
- **Progress bar:** ~70%
- **Report context bar:** 📊 Section 4 of 6: Wardrobe Audit

---

**Title (28px, bold):**
> What would feel like a win for your wardrobe 30 days from now?

---

**Question Type:** Single-choice list

**Answer Options:**
- Getting dressed in 10 minutes or less, consistently
- Wearing things I currently never touch
- Finally understanding what works on MY body
- Feeling like my clothes actually represent who I am now
- Stopping the impulse-buy cycle — buying less, loving more
- All of the above — I want the full reset

**Design notes:**
- "Feeling like my clothes actually represent who I am NOW" — the Meno-Morpher's goal. Not who she was. Who she is now.
- "Finally understanding what works on MY body" — the Scroll Comparer's goal. Not inspiration. Formulas for her specific body.
- The results screen will reflect her answer: "Your Report is built around [GOAL]."

---

## SCREEN 23: Email Capture

- **Kind:** Step — Email input
- **Progress bar:** ~75%

---

**Title (28px, bold):**
> Where should we send your completed Style Report?

**Subtitle (16px, muted):**
> Your Report is almost ready. Enter your email and we'll deliver it there too — permanently accessible.

---

**Report compilation animation (simple, tasteful):**
> 📊 Report compilation: 87% complete...

**Input field:** Email address

**Below (small, muted):**
> We never share your data. Your Report is yours alone.

**CTA Button:**
> Finalize My Report →

---

**Design notes:**
- "Report compilation: 87% complete" creates urgency without pressure — the report is almost done, she just needs to claim it.
- "Permanently accessible" addresses the fear: is this a report I'll lose access to? No. It's yours.

---

## SCREEN 24: Name Capture

- **Kind:** Step — Name input
- **Progress bar:** ~80%

---

**Title (28px, bold):**
> What's your first name?

**Subtitle (16px, muted):**
> Your Report will be personalized with your name.

---

**Input field:** First name

**CTA Button:**
> Finish My Report →

---

## SCREEN 25: Report Loading Screen

- **Kind:** Interstitial — Final compilation
- **Progress bar:** Animated 0–100%

---

**VISUAL ELEMENTS:**

**Report cover mockup animating into view (illustrated document):**
> {{firstName}}'s Complete Style Report

**Large animated progress bar (pink, fills over 12 seconds)**

**Compilation steps visible below bar, checking off one by one:**
- ✅ Profile analysis complete
- ✅ Lifestyle mapping complete
- ✅ Color profile complete
- ✅ Wardrobe audit complete
- ⟳ Generating formula matches...
- ⟳ Building 30-day outfit calendar...

**When bar hits 100%:**
> 📄 {{firstName}}'s Style Report — COMPLETE

---

**Trustpilot-style reviews appear at 70% mark:**

> ⭐⭐⭐⭐⭐
> *"I've tried everything. Apps, Pinterest boards, cleaning out my closet three times. Nothing stuck. The Report told me exactly why — my proportions, my color family, why the influencer looks never translated. Everything finally made sense."*
> — **Claire M.**, 49

> ⭐⭐⭐⭐⭐
> *"My body changed a lot in my late 40s. Nothing fit the same way. The Report gave me actual formulas for the body I have NOW — not the body I used to have. Game changer."*
> — **Susan W.**, 53

---

**Design notes:**
- The report cover with her name on it is the emotional peak of the pre-paywall experience. She has built something. It's done. It's HERS. She just can't open it yet.
- The "checklist" compilation style makes the wait feel earned, not wasted.
- Reviews must be in the Meno-Morpher/Scroll Comparer voice specifically.

---

## SCREEN 26: Report Preview (Partial Reveal)

- **Kind:** Step — Report preview with locked sections
- **Progress bar:** Complete

---

**VISUAL ELEMENTS:**

**Top bar (pink, white text):**
> ⏱ Your Report access expires in [12:00] — unlock now to keep it permanently

**Headline (30px, bold):**
> {{firstName}}, your Style Report is complete.
> Here's a preview:

---

**REPORT CONTENTS — TABLE OF CONTENTS STYLE:**

Each row shows section name, brief preview, and lock status.

```
📋 YOUR COMPLETE STYLE REPORT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SECTION 1: YOUR COLOR PROFILE               ✅ PREVIEW
Your #1 color family is: WARM NEUTRALS + EARTHY TONES
Your accent color: ████████ [LOCKED]
Colors to avoid: ████████████████ [LOCKED]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SECTION 2: YOUR BODY PROPORTION ANALYSIS    🔒 LOCKED
Your balance type: ████████████ [LOCKED]
Your formula priority: ██████████████████ [LOCKED]
Your proportion strategy: ███████████ [LOCKED]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SECTION 3: YOUR FORMULA MATCHES             ✅ PREVIEW
You matched 10 outfit formulas. Here's your top match:
FORMULA #1: [JEANS + STRUCTURED TOP + LAYER]
Full formula details: ████████████████ [LOCKED]
Remaining 9 formulas: ██████████████ [LOCKED]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SECTION 4: YOUR 30-DAY OUTFIT CALENDAR     🔒 LOCKED
Day 1: ███████████████████████████ [LOCKED]
Day 2: ███████████████████████████ [LOCKED]
[30 days of daily outfit suggestions — all locked]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SECTION 5: YOUR STOP BUYING LIST           🔒 LOCKED
Items you already have too many of: ████ [LOCKED]
What to look for instead: ██████████ [LOCKED]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SECTION 6: YOUR HIDDEN GEMS INVENTORY      ✅ PREVIEW
Items in your closet you've been ignoring:
You reported owning [blazers / statement pieces].
Your formulas activate these in 3 specific combinations.
Full activation guide: ████████████████ [LOCKED]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Below table:**
> 🔒 Sections 2, 4, and 5 are locked. Unlock your complete Report to access all 6 sections permanently.

---

**UNLOCK CTA (large, #FF2A6D, full-width):**
> Unlock My Complete Report — $19.99

**Sub-copy:**
> One-time payment. Lifetime access. Not a subscription.

---

**Design notes:**
- The partial reveal is the entire conversion mechanic. She can see enough to know the report is real and specific — but not enough to not need to pay.
- The ████ blurred text is visually striking and creates a specific type of desire: the answer is RIGHT THERE.
- "Warm Neutrals + Earthy Tones" as the visible preview feels personalized — it seems like a real answer drawn from her data.
- The 30-day calendar being entirely locked is the biggest motivator — it's the most concrete, actionable deliverable.

---

## SCREEN 27: PAYWALL — NEBULA ARCHITECTURE
### One-Time Report Purchase (NOT a subscription)

- **Kind:** Custom HTML paywall screen (warm cream background, #FF2A6D accents)
- **Paywall Architecture:** NEBULA — One-time purchase to unlock completed report
- **Checkout URL:** `https://app.outfitformulas.com/checkout/style-report`

---

### CIRCULAR COUNTDOWN TIMER

**Centered, prominent, above pricing:**

```
          ┌─────────────┐
         /               \
        |    11 : 47      |
        |   remaining     |
         \               /
          └─────────────┘
     Your Report access expires when
          this timer reaches zero
```

- Circular SVG timer, pink stroke on cream, counting down from 15:00
- Below timer: "Your report was compiled based on your quiz answers. After the timer, we cannot guarantee the same analysis will be available."

---

### HEADLINE

**Pre-headline (small caps, #FF2A6D, 14px):**
> YOUR COMPLETE STYLE REPORT IS READY

**Main headline (36px, bold, #1E1E1E):**
> **{{firstName}}, unlock everything.**

**Sub-headline (18px, #6B6B6B):**
> Your color profile, proportion analysis, 10 outfit formulas, 30-day outfit calendar, Stop Buying list, and Hidden Gems inventory — all personalized to your answers.

---

### PRICE BLOCK

**Large, centered price display:**

```
┌─────────────────────────────────────────────┐
│                                             │
│     {{firstName}}'s Complete Style Report  │
│                                             │
│            $19.99                           │
│         ONE-TIME PAYMENT                    │
│                                             │
│  ✓ Lifetime access — never expires         │
│  ✓ All 6 report sections unlocked          │
│  ✓ Your 30-day outfit calendar             │
│  ✓ Your formula cheat sheet               │
│  ✓ Stop Buying + Hidden Gems lists         │
│                                             │
│  ✗ NOT a subscription                      │
│  ✗ No recurring charges                    │
│  ✗ No "cancel anytime" to worry about     │
│                                             │
└─────────────────────────────────────────────┘
```

**The "NOT a subscription" block is visually distinct — dark cream background, heavier border — because this is the entire mental model shift.**

---

### PRIMARY CTA BUTTON

```
[ Unlock My Complete Report — $19.99 → ]
```

*Sub-copy beneath button:*
> Secure one-time payment. No subscription. No recurring charges. Permanent access.

---

### SUBSCRIPTION CLARIFICATION (separate callout block)

**Callout card (cream, pink left border, 16px):**

> **This is not a subscription.**
>
> One payment. Your Report is yours permanently — on your account, in your email, accessible any time.
>
> You'll never see another charge unless you choose to upgrade.

---

### REPORT CONTENTS (reminder — full list)

**Section header (20px, bold):**
> What's inside your complete Report:

```
📊 Your Color Profile
   → Your #1 color family and specific colors to reach for (and avoid)

📐 Your Body Proportion Analysis
   → Your specific balance type and the formula approach that works for it

👗 Your Formula Matches (10 formulas)
   → 10 specific outfit combinations built for your body + lifestyle

📅 Your 30-Day Outfit Calendar
   → One outfit per day for 30 days — all from clothes you already own

🚫 Your Stop Buying List
   → The categories you already have enough of (save the money)

💎 Your Hidden Gems Inventory
   → The pieces sitting in your closet that your formulas can activate
```

---

### SOCIAL PROOF

**Stat line:**
> ⭐⭐⭐⭐⭐ 4.8 stars · 147,000+ Reports generated · 12,400+ reviews

**Three testimonials:**

> ⭐⭐⭐⭐⭐
> *"I've done the subscriptions. I always forget and then feel guilty. This was different — $19.99, mine forever, answered the question I've had for two years. What colors actually work on me. Finally."*
> — **Patricia H.**, 51

> ⭐⭐⭐⭐⭐
> *"My body has been different since my late 40s. Not bad-different — just different. I couldn't figure out what worked anymore. My Report gave me 10 formulas that work for my body as it is right now. Not as it was. As it is."*
> — **Karen L.**, 56

> ⭐⭐⭐⭐⭐
> *"I have 847 saved pins. None of them ever worked on me. The Report told me exactly why — my proportions. I've spent less time on Pinterest in the last month than I did in any single day before."*
> — **Amanda S.**, 44

---

### GUARANTEE BLOCK

**Styled card (cream, green border):**

```
🛡️ OUR PROMISE

If you read your full Report, follow even 3 of your
10 formula recommendations for 2 weeks, and feel
zero improvement in how your closet feels to you —
contact us and we'll refund every penny.

No subscription to cancel. No hoops. Just email.

We built this Report for women like you.
We want it to work.
```

---

### OPTIONAL UPGRADE (POST-PURCHASE — appears AFTER payment, not before)

*This section does NOT appear on the paywall screen. It appears on the post-purchase confirmation page:*

---

**POST-PURCHASE UPSELL SCREEN (separate page, after payment confirmed):**

**Headline:**
> Your Report is unlocked. One more thing:

**Body:**
> Want daily outfit suggestions pulled directly from your closet — updated every morning?
>
> That's Outfit Formulas Premium. It takes your Report's formulas and applies them every day, automatically.

**Upgrade offer:**
> Try it free for 7 days → then $9.99/month. Cancel anytime.

**CTA:**
> Yes, add Premium access →

**Skip link:**
> No thanks — I'm good with my Report for now

---

**Design notes for Screen 27:**
- The circular countdown timer is the Nebula signature — it creates urgency without the aggressive "LIMITED TIME OFFER" banner of the Slowdive paywall. It's calm pressure.
- The "NOT a subscription" block with checkmarks AND X-marks is the most important conversion element for this archetype. The Scroll Comparer and Meno-Morpher both have subscription fatigue. Name the fear, then eliminate it.
- The post-purchase upsell (Premium subscription) comes AFTER the one-time report purchase — because introducing a subscription on the paywall screen would undermine the entire mental model. She bought an answer. Now we offer an ongoing service, separately.
- The pricing ($19.99 one-time) vs. alternatives framing: a personal stylist session is $150–$500. A style consultation is $75–$200. This Report is $19.99 and it's forever.
- **Paywall model: NEBULA (one-time report unlock + circular countdown timer)**

---

# FUNNEL L SCREEN SUMMARY

| Screen | Type | Content |
|--------|------|---------|
| 1 | Start node | Entry |
| 2 | Landing | Headline + report concept intro |
| 3 | Single-choice | Age |
| 4 | Single-choice | Body change question |
| 5 | Multi-select | Body area confidence |
| 6 | Single-choice | Proportion awareness |
| 7 | Interstitial | Section 1 complete → Section 2 begins |
| 8 | Single-choice | Lifestyle — primary context |
| 9 | Multi-select | Social context / what she dresses for |
| 10 | Single-choice | The aspiration gap (Scroll Comparer hook) |
| 11 | Single-choice | Shopping behavior |
| 12 | Interstitial | $2,000 unworn clothes stat + report tease |
| 13 | Interstitial | Section 2 complete → Section 3 begins |
| 14 | Single-choice | Color relationship |
| 15 | Single-choice | Skin tone context |
| 16 | Single-choice | Pattern & print comfort |
| 17 | Interstitial | Section 3 complete → Section 4 begins |
| 18 | Single-choice | Wardrobe volume |
| 19 | Single-choice | Instagram/Pinterest graveyard |
| 20 | Single-choice | Never-worn count |
| 21 | Multi-select | What she reaches for vs. what she owns |
| 22 | Single-choice | Wardrobe goals |
| 23 | Email input | Email capture + report compilation progress |
| 24 | Name input | Name capture |
| 25 | Interstitial | Final compilation loading screen |
| 26 | Report preview | Partial reveal — locked/blurred sections |
| 27 | Paywall | Nebula architecture (one-time purchase) |

**Total: 27 screens** ✅

---

---

# COMBINED VOICE REFERENCE — FUNNELS K & L

## Funnel K Voice (Closet Paralytic + Style Relic)
- "Full closet, nothing to wear"
- "I stare at my closet for 20 minutes"
- "I wear the same 4 pieces"
- "I used to know how to dress"
- "Getting dressed was FUN"
- "Buried under leggings and life"
- "I try on 5 things, hate them all, go back to the same jeans"
- "Visibility problem, not a wardrobe problem"

## Funnel L Voice (Scroll Comparer + Meno-Morpher)
- "847 Pinterest pins"
- "Nothing works on MY body"
- "The aspiration-reality gap"
- "My body reorganized itself"
- "Unfamiliar with this body"
- "Old formulas don't work anymore"
- "The body I have NOW — not the body I had"

## Never Use (Both Funnels)
- Capsule wardrobe
- Curated / curated essentials
- Elevated
- Effortless chic
- Slimming
- Age-appropriate
- Anti-aging
- Polished → say "put-together"
- Decision fatigue → say "that morning where nothing works"
- Body type (as classification) → say "your body" or "your proportions"

---

*End of Outfit Formulas Funnels K & L. Total: 55 screens across 2 funnels.*
