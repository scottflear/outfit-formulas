# Outfit Formulas — Funnels I & J
## Complete Quiz Funnel Specifications

---

# FUNNEL I: "See Your Style Transformation"
## TodayIsTheDay Paywall Architecture
**Target Archetypes:** Weight Waiter + Meno-Morpher blend
**Quiz Length:** 28 screens
**Paywall:** TodayIsTheDay — Before/After emotional comparison + intro pricing → full price renewal

---

# WHY THIS FUNNEL WORKS FOR WEIGHT WAITERS + MENO-MORPHERS

## The Core Insight

These two archetypes share one thing: their relationship with their body has been interrupted. The Weight Waiter interrupted herself — she pressed pause, decided her body wasn't good enough yet, and is waiting for a different version of herself before she's allowed to feel good about getting dressed. The Meno-Morpher had the interruption done *to* her — her body reorganized without her permission, and the formulas she relied on for decades stopped working overnight.

The result is the same: she is dressing badly for her actual body, right now. And she knows it. And she hates every morning because of it.

The before/after in this funnel is not about how she looks. It is entirely about how she **feels** — and the emotional gap between her current morning experience and the morning experience she is capable of having. That gap is where the conversion happens.

---

## Stage-by-Stage Psychology Breakdown

### Stage 1 — The Body Truth
**What it does:** Gets her to tell the truth about her current body and her current relationship with getting dressed.

**Why it works for this blend:**

The Weight Waiter has never said it out loud: "I'm waiting." It lives in her head as a private negotiation — I'll fix my wardrobe when I lose the weight. I'll buy nice things after. I'll care about how I look once I'm back to myself. This funnel asks her directly, in her own vocabulary, and she recognizes herself in the answer choices before she even clicks.

The Meno-Morpher has been trying to explain something to herself that she can't quite put words to. Her body isn't what it was. The jeans that always worked don't work anymore. The strategies she learned in her thirties don't apply. She feels like she's been handed a new body with no instruction manual. The moment this quiz says "your body reorganized itself," she stops scrolling. She's found someone who gets it.

Zero-friction entry: Age → Body change experience → Current dressing situation. These feel like profile questions, not an interrogation. By the time emotional questions appear, she's already in the habit of honest answers.

---

### Stage 2 — The Wardrobe Confession
**What it does:** Forces her to inventory the evidence of her avoidance — the things she owns, the things she won't buy, the things she puts on and immediately takes off.

**Why it works:**

The Weight Waiter's closet is a crime scene. She has three different sizes in there. Things still with tags. Things she bought "for when." Things from before. She's never told anyone this. When the quiz reflects it back — "Do you have clothes in your closet from a previous size?" — she clicks Yes and feels a specific pang of recognition that is almost relief. Someone knows.

The Meno-Morpher has a closet full of things that used to work and now don't. She hasn't purged them because letting go feels like giving up. The quiz asking "How many pieces in your closet still feel like the body you used to have?" is not cruel — it's honest. She is not broken for having this problem. She is not alone.

Each confession is a micro-commitment. By the end of Stage 2, she has told the quiz — and herself — the truth about her wardrobe. The cost of not fixing it is now in writing.

---

### Stage 3 — The Daily Cost
**What it does:** Translates her abstract wardrobe sadness into the concrete daily experience of a bad morning.

**Why it works:**

"I don't love how I dress right now" is ignorable. "I spent 23 minutes this morning trying on clothes, gave up, and wore the same thing I wore Wednesday, and then avoided the full-length mirror on my way out" is not ignorable. That is a tax. A daily tax on her time, her mood, and her self-image.

The multi-select frustration screen is a mirror held up at 7 AM. She sees "I own things I haven't worn in over a year" and "I buy things that don't work with anything I own" and "I cancel plans because I can't figure out what to wear" and she checks every single one. The more boxes checked, the deeper the problem-ownership. By the time Stage 3 ends, the problem has a price tag: 120 hours a year. Two thousand dollars in unworn clothes. Plans she didn't go to.

---

### Stage 4 — The Reframe
**What it does:** Shifts the diagnosis from "I have bad taste / the wrong body / no style" to "I don't have the right formulas for my body as it is right now."

**Why it works:**

This is the pivot on which everything turns. Both archetypes believe — deeply, privately — that the real problem is them. The Weight Waiter thinks the problem is her body. The Meno-Morpher thinks the problem is that her body betrayed her. Neither is true. The problem is that the outfit formulas they have been using were designed for bodies they don't currently have. The formulas are broken. Not them.

This reframe is not a consolation prize. It is the actual truth. And it opens the door to the solution: new formulas for the body she has right now.

---

### Stage 5 — The Before/After and the Promise
**What it does:** Makes her transformation concrete, emotional, and personal — with a specific start date.

**Why it works:**

The before/after is devastating in the best possible way. It doesn't show thinner bodies. It shows two entirely different emotional lives. The NOW column is Tuesday morning at 6:58 AM — she knows exactly what that feels like. The YOUR GOAL column is the morning she actually wants — she knows what that feels like too, because she used to have it, or she can imagine it vividly.

"Your transformation begins April 5, 2026." That specificity — today's date — makes this real. Not someday. Not when she loses the weight. Today.

---

## The Central Conversion Mechanism

The quiz never sells the app. It sells the moment she realizes:

1. Her body has changed (Weight Waiter: stalled. Meno-Morpher: reorganized.) — Stage 1
2. Her wardrobe reflects that stuck place — Stage 2
3. It is costing her something real every single day — Stage 3
4. The problem is the formulas, not her — Stage 4
5. The fix starts today, not after — Stage 5

The paywall offers her a plan — personalized to her quiz answers — that begins immediately. Not after she's different. Now.

---

# THE COMPLETE 28-SCREEN FUNNEL

---

## SCREEN 1: Start (Entry Node)
- **Kind:** Start (invisible entry node)
- **Notes:** Automatically transitions to Screen 2. No visible content. Platform handles routing.

---

## SCREEN 2: Landing / Entry

- **Kind:** Step — Landing page + single-choice entry
- **Progress bar:** None (first screen)
- **Background:** Soft cream (#FFF8F5)

---

**VISUAL ELEMENTS:**

- **Top badge:** `STYLE TRANSFORMATION QUIZ` — pill style, #FF2A6D border and text
- **Headline (36–40px, bold, #1E1E1E):**
  > **YOUR BODY CHANGED.**
  > **YOUR STYLE DOESN'T HAVE TO STAY STUCK.**

- **Subheadline (18px, #6B6B6B):**
  > Find out which outfit formulas actually work for your body right now. Takes 4 minutes. Built for women who are tired of mornings that don't work.

- **Badge:** `⏱ 4-MINUTE QUIZ` — centered, #FF2A6D background, white text

- **Trust line (small, below badge):**
  > 147,000+ women have found their formula. Your turn.

---

**QUESTION TYPE:** Single-choice, 2-option visual layout

**Question text:** *(none — images act as the prompt)*

**Answer Options:**
- 🖼️ **"My body has changed and I haven't figured out how to dress it yet"**
- 🖼️ **"I've been putting off dealing with my wardrobe until my body is different"**

**Behaviour:** Auto-advances on click.

**Footer text (small, muted):**
> By continuing you agree to our Terms of Use and Privacy Policy.

---

**DESIGN NOTES:**
- Background: warm cream (#FFF8F5) — this should feel like a friend's living room, not a gym
- Headline font: Inter Bold — confident, not trendy
- Both answer options name her. Either one she clicks, she's in.
- No mention of Outfit Formulas as a product yet. This is her quiz.

---

## SCREEN 3: Age

- **Kind:** Step
- **Progress bar:** ~5%
- **Background:** Warm cream (#FFF8F5)

---

**Title (28px, bold):**
> How old are you?

**Subtitle (16px, #6B6B6B):**
> Bodies change differently at different stages of life. We need this to find formulas that are actually right for you.

---

**Question Type:** Single-choice list

**Answer Options (auto-advance on click):**
- 25–34
- 35–44
- 45–54
- 55–64
- 65+

**Design notes:**
- The subtitle does quiet reassurance work — "bodies change differently at different stages of life" tells the 52-year-old that her experience is known and expected, not aberrant
- No "Under 25" option — this quiz skews older by design

---

## SCREEN 4: Early Social Proof Interstitial

- **Kind:** Step — interstitial (no question)
- **Progress bar:** ~8%
- **Background:** Deep charcoal (#1E1E1E)

---

**Visual:** Simple centered layout, white text

**Headline (24px, bold, white):**
> You're not the only one who feels this way.

**Body text (16px, #B0B0B0):**
> 73% of women say they have "nothing to wear" — even when their closet is full.
>
> The average woman has $2,000 worth of clothes she never wears.
>
> And she spends 120+ hours a year standing in front of her closet feeling bad about it.
>
> None of that is about her taste. It's about her formulas.

**Transition:** Auto-advances after 4 seconds, or tap to continue

**Continue button:** `Keep going →` — #FF2A6D, full-width

---

## SCREEN 5: Body Change Experience

- **Kind:** Step
- **Progress bar:** ~12%

---

**Title (28px, bold):**
> How has your body changed in the last few years?

**Subtitle (16px, #6B6B6B):**
> Select the one that feels most true.

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- "My weight has shifted and I haven't adjusted my wardrobe"
- "My shape changed — waist, hips, chest — things fit differently now"
- "Both — weight AND shape changed"
- "My body is fine but I've stopped caring about how I dress it"

---

**DESIGN NOTES:**
- Every option is a variant of "something changed." There's no shame option. No "I've let myself go." She is simply at a point in her life where her body is different from what she was dressing before.
- Meno-Morpher will gravitate toward option 2 or 3. Weight Waiter will take option 1 or 3.

---

## SCREEN 6: The Waiting Question

- **Kind:** Step
- **Progress bar:** ~16%

---

**Title (28px, bold):**
> Have you put buying new clothes on hold — waiting until something changes?

**Subtitle (16px, #6B6B6B):**
> There's no wrong answer. We're just trying to understand where you're at.

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- "Yes — I keep telling myself I'll deal with it after I lose weight"
- "Yes — but I'm not waiting to lose weight, I just don't know what works on me anymore"
- "I've been buying things, but nothing's really working"
- "I've basically given up on my wardrobe for now"

---

**DESIGN NOTES:**
- This is the Weight Waiter's core question, and the answer she clicks will feel like a confession — the private negotiation she's been having with herself, named.
- Meno-Morpher takes option 2 — she's not in denial, she's lost.
- Option 4 is the self-abandonment acknowledgment that sometimes comes after months or years of struggle.

---

## SCREEN 7: Current Wardrobe Reality

- **Kind:** Step
- **Progress bar:** ~20%

---

**Title (28px, bold):**
> When you open your closet right now, what do you see?

**Subtitle (16px, #6B6B6B):**
> Be honest — this is just between us.

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- "Mostly things that don't fit the body I have right now"
- "A mix of stuff — some fits, most of it just hangs there"
- "Clothes from multiple different sizes — I don't know which 'me' to dress"
- "A lot of clothes I never wear and can't explain why I bought"

---

## SCREEN 8: Multi-Select — The Wardrobe Inventory

- **Kind:** Step
- **Progress bar:** ~24%

---

**Title (28px, bold):**
> Which of these are true about your wardrobe right now?

**Subtitle (16px, #6B6B6B):**
> Select all that apply.

---

**Question Type:** Multi-select list

**Answer Options (checkboxes, select multiple):**
- [ ] I have clothes from a smaller size "for when I get there"
- [ ] I have things I bought that still have tags on them
- [ ] I reach for the same 5–7 things on repeat
- [ ] I've bought things that don't go with anything I own
- [ ] There are pieces I haven't touched in over a year
- [ ] My "nice" clothes sit there while I wear the easy stuff

**CTA Button:** `That's my closet →` — #FF2A6D, full-width

---

**DESIGN NOTES:**
- The multi-select is deliberately structured so that almost every item rings true for her — the goal is high overlap, high recognition. She should be checking 4–6 boxes.
- "Same 5–7 things on repeat" is the Weight Waiter's signature pattern. "Bought things that don't go with anything" is the Meno-Morpher's shopping confusion.

---

## SCREEN 9: The Morning

- **Kind:** Step
- **Progress bar:** ~27%

---

**Title (28px, bold):**
> What does getting dressed look like on a typical morning?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- "I try on multiple things, reject them all, and go back to what I always wear"
- "I pick the one thing I know works and don't experiment"
- "I stand there for way too long and still leave feeling blah"
- "I've basically automated it — same rotation, every week"

---

## SCREEN 10: Time Spent

- **Kind:** Step
- **Progress bar:** ~30%

---

**Title (28px, bold):**
> How long does it usually take you to get dressed in the morning?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- "5 minutes or less (but I'm not happy with how I look)"
- "10–20 minutes"
- "20–40 minutes — it's a whole thing"
- "It varies wildly — some mornings are fine, others are a disaster"

---

## SCREEN 11: Emotional Cost Interstitial

- **Kind:** Step — interstitial (no question)
- **Progress bar:** ~33%
- **Background:** Deep charcoal (#1E1E1E)

---

**Headline (24px, bold, white):**
> That morning feeling has a name.

**Body text (16px, #B0B0B0):**
> It's not just frustration about clothes.
>
> It's starting every day with proof that something isn't working. That the version of yourself you want to be — the one who looks put-together, who walks out the door with confidence — is just slightly out of reach. Again.
>
> The worst part? You're probably blaming the wrong thing.

**Continue button:** `Keep going →` — #FF2A6D, full-width

---

## SCREEN 12: Likert — "I avoid buying clothes because nothing feels right on me right now"

- **Kind:** Step — Likert scale
- **Progress bar:** ~37%

---

**Title (24px, bold):**
> "I avoid buying clothes because nothing feels right on me right now."

**Subtitle (14px, #6B6B6B):**
> How much does this sound like you?

---

**Question Type:** Single-choice, 5-point scale

**Scale options (horizontal row):**
- Strongly disagree
- Disagree
- Neutral
- Agree
- **Strongly Agree**

**Design notes:** The statement is written to be nearly impossible to answer "Disagree" for a Weight Waiter or Meno-Morpher. The emotional recognition of selecting "Agree" or "Strongly Agree" is the conversion moment.

---

## SCREEN 13: Likert — "I know my old formulas stopped working but I haven't found new ones"

- **Kind:** Step — Likert scale
- **Progress bar:** ~40%

---

**Title (24px, bold):**
> "My old tricks for getting dressed stopped working, and I haven't figured out what to replace them with."

**Subtitle (14px, #6B6B6B):**
> How much does this sound like you?

---

**Question Type:** Single-choice, 5-point scale

**Scale:** Strongly disagree → Strongly Agree

---

## SCREEN 14: Likert — "I feel like I'm just waiting until I can deal with my wardrobe properly"

- **Kind:** Step — Likert scale
- **Progress bar:** ~43%

---

**Title (24px, bold):**
> "There's a version of me that dresses well — I'm just not her right now."

**Subtitle (14px, #6B6B6B):**
> How much does this sound like you?

---

**Question Type:** Single-choice, 5-point scale

**Scale:** Strongly disagree → Strongly Agree

---

## SCREEN 15: Multi-Select — The Real Cost

- **Kind:** Step
- **Progress bar:** ~47%

---

**Title (28px, bold):**
> When your wardrobe doesn't work, what actually happens?

**Subtitle (16px, #6B6B6B):**
> Select everything that's true.

---

**Question Type:** Multi-select list

**Answer Options:**
- [ ] I skip events or cancel plans because I can't figure out what to wear
- [ ] I walk out the door feeling bad about myself before the day even starts
- [ ] I avoid full-length mirrors
- [ ] I spend money on things I end up not wearing
- [ ] I feel invisible in rooms I used to feel confident in
- [ ] I haven't been photographed in years because I hate how I look
- [ ] I know I'm presenting a version of myself that doesn't match how I feel inside

**CTA Button:** `This is what it costs →` — #FF2A6D, full-width

---

**DESIGN NOTES:**
- "I know I'm presenting a version of myself that doesn't match how I feel inside" is the deepest one on the list. It names the identity gap without judgment. It will be the box that hurts most to check — and the one she is most relieved to have acknowledged.

---

## SCREEN 16: The Reframe Interstitial

- **Kind:** Step — interstitial (no question)
- **Progress bar:** ~50%
- **Background:** Deep charcoal (#1E1E1E)

---

**Headline (28px, bold, white):**
> Here's what's actually going on.

**Body text (16px, #B0B0B0):**
> You don't have a style problem.
>
> You don't have a body problem.
>
> You have a **formula problem.**
>
> The outfit combinations that worked for you before — the ones you figured out over years of trial and error — were built for a body you don't have anymore. Of course they feel wrong. They are wrong. For right now.
>
> Your body changed. The formulas didn't update.
>
> That's fixable. And it doesn't require losing weight first.

**Continue button:** `Show me what's possible →` — #FF2A6D, full-width

---

## SCREEN 17: Goal Clarity

- **Kind:** Step
- **Progress bar:** ~53%

---

**Title (28px, bold):**
> What would getting dressed feel like if it actually worked?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- "Done in 5 minutes — and I'd feel good walking out"
- "I'd stop dreading my closet. That would be enough."
- "I'd feel like myself again when I look in the mirror"
- "I'd actually look forward to getting dressed instead of dreading it"

---

## SCREEN 18: Style Confidence Before

- **Kind:** Step
- **Progress bar:** ~57%

---

**Title (28px, bold):**
> Was there a time in your life when you felt really good about how you dressed?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- "Yes — before my body changed"
- "Yes — when I was younger / before life got complicated"
- "Sort of — I had phases of it"
- "Not really — I've always struggled with this"

---

**DESIGN NOTES:**
- This question activates nostalgia for the Style Relic threads in the Meno-Morpher — the woman who used to know what worked, who had a formula. Now it's gone. The follow-up possibility (that it can come back) is the emotional underpinning of the results screen.

---

## SCREEN 19: The Compliment Question

- **Kind:** Step
- **Progress bar:** ~60%

---

**Title (28px, bold):**
> When did you last receive a genuine compliment about the way you looked?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- "Recently — but it's not consistent"
- "A while ago — months or longer"
- "I honestly can't remember"
- "I've stopped tracking. I've stopped expecting them."

---

## SCREEN 20: Body Comfort Now

- **Kind:** Step
- **Progress bar:** ~63%

---

**Title (28px, bold):**
> How comfortable are you in your body right now?

**Subtitle (16px, #6B6B6B):**
> Not about weight. About how it feels to be in it.

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- "Pretty uncomfortable — I'm avoiding it"
- "Somewhere in between — I have okay days and bad days"
- "I've made a kind of peace with it, but getting dressed still isn't working"
- "I feel fine about my body — the clothes are the problem, not the body"

---

## SCREEN 21: Multi-Select — What She's Tried

- **Kind:** Step
- **Progress bar:** ~67%

---

**Title (28px, bold):**
> Have you tried any of these to fix this?

**Subtitle (16px, #6B6B6B):**
> Select everything you've attempted.

---

**Question Type:** Multi-select list

**Answer Options:**
- [ ] Bought things I thought would fix it, then never wore them
- [ ] Watched YouTube / followed Instagram accounts for outfit ideas
- [ ] Asked friends or family for help
- [ ] Went through my closet to "declutter"
- [ ] Bought things because they looked good on someone else
- [ ] Told myself I'd deal with it once things calmed down / changed

**CTA Button:** `None of it really worked →` — #FF2A6D, full-width

---

**DESIGN NOTES:**
- The CTA button copy does real work here. She didn't click all those options for fun — she's showing the quiz her history of attempts. The button acknowledges the futility without shaming her for trying.

---

## SCREEN 22: The Formula Concept

- **Kind:** Step — interstitial with soft question
- **Progress bar:** ~70%
- **Background:** Warm cream (#FFF8F5)

---

**Title (24px, bold):**
> What if the problem wasn't you — it was the approach?

**Body text (16px, #6B6B6B):**
> Most style advice is built around shopping, trends, and body types that don't match yours.
>
> Outfit Formulas works differently. Instead of telling you what to buy, it shows you which combinations of things you **already own** look great together — based on your colors, your proportions, and your life right now.
>
> No shopping required. No waiting until you look different.

**Single question below body text:**

> **Does this sound like what you've been missing?**

**Answer Options (auto-advance):**
- "Yes — I need formulas, not inspiration"
- "I'm not sure — tell me more"
- "I've heard things like this before"

---

## SCREEN 23: Lifestyle Context

- **Kind:** Step
- **Progress bar:** ~73%

---

**Title (28px, bold):**
> What does a typical week look like for you?

**Subtitle (16px, #6B6B6B):**
> We use this to find formulas that work for your actual life — not someone else's.

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- "Working — mix of home and office"
- "Working — mostly from home"
- "Working — I'm in public/client-facing most of the week"
- "Not currently working — family, retirement, or transition"

---

## SCREEN 24: Special Occasions

- **Kind:** Step
- **Progress bar:** ~77%

---

**Title (28px, bold):**
> Are there specific situations where your wardrobe really lets you down?

**Subtitle (16px, #6B6B6B):**
> Select all that apply.

---

**Question Type:** Multi-select list

**Answer Options:**
- [ ] Getting dressed for work in the morning
- [ ] Going out socially — dinner, events, parties
- [ ] Travel (I never know what to pack)
- [ ] Seeing people I haven't seen in a while
- [ ] Being photographed
- [ ] Just everyday — it's always a problem

**CTA Button:** `Got it →` — #FF2A6D, full-width

---

## SCREEN 25: Email Capture

- **Kind:** Step — email gate
- **Progress bar:** ~82%
- **Background:** Deep charcoal (#1E1E1E)

---

**Headline (28px, bold, white):**
> We're almost done.

**Body text (16px, #B0B0B0):**
> Enter your email to unlock your personalized Style Transformation Plan — which formulas work for your body, your wardrobe, and your life right now.

---

**Input field:** Email address (placeholder: "your@email.com")

**CTA Button:** `See my transformation plan →` — #FF2A6D, full-width

**Privacy note (small, muted):**
> We'll never share your email. Unsubscribe any time.

---

## SCREEN 26: Name Capture

- **Kind:** Step
- **Progress bar:** ~85%

---

**Headline (24px, bold):**
> One more thing —

**Question:** What's your first name?

**Input field:** First name

**CTA Button:** `Almost there →` — #FF2A6D, full-width

---

## SCREEN 27: Results Loading Screen

- **Kind:** Step — interstitial with loading animation
- **Progress bar:** ~90%
- **Background:** Deep charcoal (#1E1E1E)

---

**Headline (24px, bold, white):**
> Building your Style Transformation Plan, {{firstName}}...

**Loading animation:** Progress bar, fills over ~5 seconds

**Rotating copy beneath the bar (changes every 1.5 seconds):**
> "Analyzing your body change profile..."
> "Matching formulas to your wardrobe..."
> "Identifying your transformation path..."
> "Finding outfits hiding in what you already own..."

**Social proof (appears when loading bar hits ~80%):**

> ⭐⭐⭐⭐⭐
> *"I hadn't felt good about getting dressed in four years. Within two weeks I had five new outfits from clothes that had been sitting in my closet the whole time."*
> — **Deborah K.**, 51

> ⭐⭐⭐⭐⭐
> *"My body changed a lot in my late forties and nothing I owned made sense anymore. The formulas made it click."*
> — **Marie T.**, 49

---

## SCREEN 28: Results + Before/After + Paywall (Custom HTML)

- **Kind:** Custom HTML — results + paywall
- **Paywall Architecture:** TODAYISTHEDAY — Before/After emotional comparison + intro pricing → full price renewal
- **Background:** Warm cream (#FFF8F5)

---

### RESULTS HEADER

**Pre-headline (small caps, #FF2A6D):**
> YOUR STYLE TRANSFORMATION PLAN

**Main Headline (36px, bold, #1E1E1E):**
> {{firstName}}, here's what we found.

**Subheadline (18px, #6B6B6B):**
> Based on your quiz, you're in transition — your body has changed, and your wardrobe hasn't caught up. The good news: you don't need to buy anything. You need new formulas for the body you have right now.

---

### BEFORE / AFTER COMPARISON BLOCK

**Section label (small caps, #FF2A6D):** `YOUR STYLE TRANSFORMATION`

**Layout:** Two-column comparison card (full-width on mobile = stacked)

---

**LEFT COLUMN — Dark background (#1E1E1E), white text:**

```
NOW

Morning dread.
Standing there for 20 minutes.
Same jeans again.
Feeling invisible.
Canceling plans because nothing works.
Avoiding mirrors.
That feeling of not recognizing yourself.
```

---

**RIGHT COLUMN — #FF2A6D background, white text:**

```
YOUR GOAL

5-minute outfit, done.
Walking out feeling like yourself.
Getting compliments again.
Actually looking forward to getting dressed.
Showing up — to the dinner, the party, the photo.
Feeling like the woman you actually are.
```

---

**Below the comparison block:**

```
Your transformation begins April 5, 2026.
```

*(Dynamic: renders today's date)*

---

### PROOF STRIP (below comparison)

```
★★★★★  4.7/5 from 11,200+ reviews   |   147,000+ style plans created   |   Supported by style psychology research
```

---

### PLAN SELECTOR

**Section header (24px, bold):**
> Choose your plan — personalized to your profile:

**Note beneath header (14px, #6B6B6B):**
> Introductory pricing. Auto-renews at full price after your first period. Cancel anytime.

---

**PLAN CARD — 1-Month** *(PRE-SELECTED — pink border glow, "Recommended for your profile" badge)*

```
┌──────────────────────────────────────────────────────┐
│  ✦ RECOMMENDED FOR YOUR PROFILE                       │
│  Based on your quiz: body-change + early transition  │
│                                                       │
│  1 Month                                              │
│  ~~$9.99~~ → $4.99 first month                        │
│  Just $0.17/day                                       │
│                                                       │
│  Then $9.99/month — cancel anytime                    │
└──────────────────────────────────────────────────────┘
```

**Why it's recommended (shown inside or below card):**
> Your quiz shows you're in early style transition. A month gives you enough time to build your formula habits — and most women know within 2 weeks whether it's working.

---

**PLAN CARD — 3-Month** *(unselected)*

```
┌──────────────────────────────────────────────────────┐
│  🏆 TOP CHOICE FOR STYLE REBUILDERS                   │
│                                                       │
│  3 Months                                             │
│  ~~$59.97~~ → $29.99 for 3 months                     │
│  Just $0.33/day                                       │
│                                                       │
│  Then $19.99/month — cancel anytime                   │
└──────────────────────────────────────────────────────┘
```

---

**PLAN CARD — 6-Month** *(unselected)*

```
┌──────────────────────────────────────────────────────┐
│  ⭐ BEST VALUE                                        │
│                                                       │
│  6 Months                                             │
│  ~~$89.94~~ → $39.99 for 6 months                     │
│  Just $0.22/day                                       │
│                                                       │
│  Then $14.99/month — cancel anytime                   │
└──────────────────────────────────────────────────────┘
```

---

### PRIMARY CTA BUTTON

```
[ Start My Transformation — April 5, 2026 → ]
```

*Sub-copy beneath:* "Secure checkout. Cancel anytime."

---

### GUARANTEE BLOCK

```
🛡️ RISK-FREE GUARANTEE

Cancel at any time before your renewal date
and you won't be charged the full price.
No hoops. No awkward conversation.
Your transformation, your timeline.
```

---

### TESTIMONIALS (mixing Weight Waiter + Meno-Morpher voices)

> ⭐⭐⭐⭐⭐
> *"I spent three years waiting until I lost the weight before I'd 'deal with' my wardrobe. The quiz told me I didn't have to wait. The first week I found six outfits from stuff I already owned. I don't know why I waited so long."*
> — **Sandra L.**, 46

> ⭐⭐⭐⭐⭐
> *"My body reorganized itself after menopause and nothing I owned made sense anymore. The formulas gave me a system for this body — not the one I used to have. I actually got dressed this morning and felt like myself."*
> — **Carol M.**, 54

> ⭐⭐⭐⭐⭐
> *"I have so many clothes and I never felt good in any of them. Turns out I was combining them all wrong. The formula system changed how I think about my whole closet."*
> — **Janet R.**, 48

---

### FEATURES LIST (below testimonials)

**Included with every plan:**

- Daily outfit suggestions from your existing wardrobe
- Your personal formula library (combinations that work for your body)
- Color analysis matched to what you actually own
- "What to wear to..." decision tool
- Morning routine optimizer — 5-minute or less
- New formulas added weekly

---

### FINE PRINT (small, #6B6B6B)

> Introductory pricing applies to the first billing period only. Plans auto-renew at the standard rate shown. You can cancel at any time from your account settings. See full Terms of Service for details.

---

**DESIGN NOTES for Screen 28:**
- The before/after is the emotional peak — it must be visually arresting. Dark left column vs. vibrant pink right column creates a stark visual divide that mirrors the emotional contrast
- "Your transformation begins [today's date]" is the single most powerful line on the page — the present tense makes this real and immediate
- "Recommended for your profile" on the 1-month plan uses the quiz data signal — body change + early transition = lower commitment threshold is appropriate
- The guarantee language is specifically "cancel before your renewal date" — not "30 days" — which removes the time-pressure around the guarantee while being legally clear
- Testimonials are named, aged, and specific — no generic quotes

---

# SUMMARY: FUNNEL I SCREEN MAP

| Screen | Type | Purpose |
|--------|------|---------|
| 1 | Start node | Auto-entry |
| 2 | Landing + single-choice | Entry / self-identification |
| 3 | Single-choice | Age |
| 4 | Interstitial | Early social proof |
| 5 | Single-choice | Body change type |
| 6 | Single-choice | The waiting question |
| 7 | Single-choice | Current closet reality |
| 8 | Multi-select | Wardrobe inventory |
| 9 | Single-choice | Morning experience |
| 10 | Single-choice | Time spent getting dressed |
| 11 | Interstitial | Emotional cost bridge |
| 12 | Likert | "I avoid buying clothes" |
| 13 | Likert | "My old formulas stopped working" |
| 14 | Likert | "There's a version of me that dresses well" |
| 15 | Multi-select | Real cost of wardrobe failure |
| 16 | Interstitial | The reframe — formula problem, not body problem |
| 17 | Single-choice | Goal clarity |
| 18 | Single-choice | Style confidence before |
| 19 | Single-choice | Last compliment |
| 20 | Single-choice | Body comfort now |
| 21 | Multi-select | What she's tried |
| 22 | Interstitial + soft question | Formula concept introduction |
| 23 | Single-choice | Lifestyle context |
| 24 | Multi-select | Situations where wardrobe fails |
| 25 | Email capture | Email gate |
| 26 | Text input | Name capture |
| 27 | Loading interstitial | Results building animation |
| 28 | Custom HTML | Results + Before/After + Paywall |

**Total: 28 screens** ✅

---

# COPY RULES FOR FUNNEL I

1. **Never say "your journey"** — say "what's next" or "your plan"
2. **Never reference weight loss as the goal** — the transformation is emotional, not physical
3. **Use "right now" constantly** — "your body right now," "your wardrobe right now." The present tense is the entire point.
4. **The Weight Waiter's voice:** "I haven't bought anything in years," "waiting to lose the weight," "I don't want to give up"
5. **The Meno-Morpher's voice:** "My body reorganized itself," "the waist I could always count on? Gone," "nothing fits the same way"
6. **Never say "slimming," "age-appropriate," "anti-aging"** — these are the exact words that made her feel judged by every other style resource
7. **Permission-giving over prescriptive** — "you don't have to wait" not "you should dress for your body now"
8. **Today is always the start date** — dynamic date renders on results + paywall

---
---

# FUNNEL J: "Get Matched with Your Formula"
## The Coach Paywall Architecture
**Target Archetypes:** Mom Ghost + Style Relic blend
**Quiz Length:** 28 screens
**Paywall:** The Coach — Massive SAVE% badges + expert authority + countdown timer

---

# WHY THIS FUNNEL WORKS FOR MOM GHOSTS + STYLE RELICS

## The Core Insight

These two archetypes lost their style for opposite reasons — but they're standing in the same place.

The Mom Ghost disappeared into motherhood. She used to be a woman with a wardrobe, preferences, and a sense of how she showed up in the world. Then the kids arrived, and slowly — so slowly she almost didn't notice — she became "just a mom." She wears what won't get destroyed. She stopped being a person with style and became a function. And somewhere deep underneath the mom guilt and the practical considerations, she misses herself. She's just not sure she's allowed to want that back.

The Style Relic had it and lost it. She used to dress well. Compliments were normal. Getting dressed was fun — she knew her formulas, knew what worked, moved through her closet with confidence. Then life got complicated. Career, maybe. Relationship change, maybe. Kids, maybe. Time, definitely. And somehow over the course of years, she stopped. She doesn't know exactly when it happened. She just knows it's been a while. And she's nostalgic for that version of herself.

The expert authority in this funnel matters for both of them. The Mom Ghost needs to be told by someone with credentials that caring about her appearance isn't selfish — it's supported by actual style psychology. The Style Relic needs confirmation that her instinct is right: she used to have this, she can get it back, and there's a real system to do it.

---

## Stage-by-Stage Psychology Breakdown

### Stage 1 — The Identity Excavation
**What it does:** Gets her to identify where she is in her relationship with her own style identity.

**Why it works for this blend:**

The Mom Ghost has been so deep in function-mode that she's forgotten she had a style identity at all. The first few questions act like an excavation — each one uncovering a layer she hasn't thought about in years. "When did you last buy something just for yourself?" is almost painful to answer honestly. But answering it out loud (in a quiz format, to a screen, privately) is the beginning of permission.

The Style Relic knows exactly where her style went. It didn't disappear — it got buried under leggings and life. She can name the last time she felt well-dressed. She can describe the version of herself that existed before. This quiz lets her speak that version of herself back into existence.

Zero-friction entry: Age → Life stage → Current dressing situation. These feel like context questions, not therapy. The emotional depth arrives at Screen 5.

---

### Stage 2 — The Motherhood Mirror (or the "Before" Reel)
**What it does:** Forces her to describe, in concrete terms, what getting dressed looks like vs. what it used to look like.

**Why it works:**

The Mom Ghost's contrast is functional vs. personal. She wears what won't show the handprint. What she can run in. What won't need ironing at 6:30 AM. There was a version of her that wore silk tops and ankle boots. That woman is still in there. She just stopped dressing her.

The Style Relic's contrast is before vs. now. Before, she had a formula. A signature. Things that were reliably, uniquely hers. Now it's just... clothes. Safe, boring, uninspired clothes. She knows what she's missing, which makes it hurt more.

Both women get to see their contrast in this stage. By the end, they've described both sides of the gap — and the gap is motivating.

---

### Stage 3 — Expert Validation Drops
**What it does:** Introduces image consultant and style psychology perspectives that validate her experience as real, researched, and fixable.

**Why it works:**

The Mom Ghost needs permission. Real permission — not just encouragement, but authority. If an image consultant with credentials says "this is a known phenomenon — maternal identity loss affects how women present themselves, and it's fixable" — that is permission granted. She's not being vain. This is real.

The Style Relic needs confirmation that her instinct is correct. She always had good style instincts — she just lost the framework. An expert saying "your style memory is intact — you just need the right formulas to access it" speaks directly to her self-image as a woman who once had this figured out.

Expert interstitials are dropped at calculated moments — right after she's described a particularly painful truth. The expert appears like a trusted friend who was listening.

---

### Stage 4 — Commitment and Goal Setting
**What it does:** Gets her to articulate what she actually wants, and begin mentally rehearsing the outcome.

**Why it works:**

The Mom Ghost is not used to naming what she wants for herself. This is where the funnel gives her the scaffolding to do it — in a quiz format, in safe, private terms. "What would it mean to feel like yourself again?" She clicks an answer. She's committed to the idea of herself as someone who deserves this.

The Style Relic knows what she wants. She wants to feel the way she felt when she used to walk out the door and know she looked great. The quiz lets her name that and claim it.

By the end of Stage 4, she has stated her desire. The paywall offers her the path.

---

### Stage 5 — The Expert Match
**What it does:** Delivers her "matched formula" results with expert endorsement — creating the sense of a personalized recommendation from a credible professional.

**Why it works:**

"Your Personal Stylist Match" lands very differently from "here's your subscription." She's not buying software — she's being matched. The quiz analyzed her profile. Image consultants and color analysts reviewed the methodology. Her formula type has been identified. All she needs to do is say yes.

For the Mom Ghost: this is someone finally giving her something. Not asking. Giving.
For the Style Relic: this is the professional confirmation she was right — she had style before, she can have it again, here's the system.

---

## The Central Conversion Mechanism

The quiz never sells the app. It sells the match. By the time the paywall appears, she has:

1. Identified herself — Mom Ghost or Style Relic — in explicit, recognized terms (Stage 1)
2. Described the gap between how she dresses and how she used to / wants to dress (Stage 2)
3. Received expert validation that her experience is real and fixable (Stage 3)
4. Named what she actually wants for herself (Stage 4)
5. Received her personalized formula match with expert endorsement (Stage 5)

The paywall doesn't ask her to buy. It asks her to claim her match.

---

# THE COMPLETE 28-SCREEN FUNNEL

---

## SCREEN 1: Start (Entry Node)
- **Kind:** Start (invisible entry node)
- **Notes:** Automatically transitions to Screen 2. No visible content.

---

## SCREEN 2: Landing / Entry

- **Kind:** Step — Landing page + single-choice entry
- **Progress bar:** None (first screen)
- **Background:** Warm cream (#FFF8F5)

---

**VISUAL ELEMENTS:**

- **Top badge:** `PERSONAL FORMULA MATCH QUIZ` — pill style, #FF2A6D border and text
- **Headline (36–40px, bold, #1E1E1E):**
  > **YOU USED TO KNOW HOW TO DRESS.**
  > **LET'S FIND YOUR WAY BACK.**

- **Subheadline (18px, #6B6B6B):**
  > A 4-minute quiz — developed with image consultants and style psychologists — to match you with the outfit formulas that actually work for your life right now.

- **Expert badge (small, muted):**
  > Developed in collaboration with certified image consultants and color analysts

- **Badge:** `⏱ 4-MINUTE QUIZ` — centered, #FF2A6D

- **Trust line:**
  > 147,000+ women have found their formula. Avg. style confidence improvement: 90% within 2 weeks.

---

**QUESTION TYPE:** Single-choice, 2-option layout

**Question text:** Which of these feels more like you?

**Answer Options (auto-advance):**
- "I used to have a style I was proud of — and somewhere along the way I lost it"
- "I've been so focused on everyone else that I've kind of forgotten how to dress for myself"

**Footer text (small, muted):**
> By continuing you agree to our Terms of Use and Privacy Policy.

---

**DESIGN NOTES:**
- Both options are the same person at different stages of the same story — Style Relic and Mom Ghost respectively
- No mention of Outfit Formulas yet. This is her quiz.
- The expert badge in the subheadline establishes authority before the first question

---

## SCREEN 3: Age

- **Kind:** Step
- **Progress bar:** ~5%

---

**Title (28px, bold):**
> How old are you?

**Subtitle (16px, #6B6B6B):**
> Style formulas are built around your actual life — and that changes by decade.

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- 25–34
- 35–44
- 45–54
- 55–64
- 65+

---

## SCREEN 4: Life Stage

- **Kind:** Step
- **Progress bar:** ~8%

---

**Title (28px, bold):**
> Which of these best describes where you are in life right now?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- "Parent — kids still at home, most of my energy goes to them"
- "Parent — kids are older / launched, figuring out who I am again"
- "Working hard and haven't prioritized how I look"
- "Life changed — relationship, job, move — and my wardrobe never caught up"
- "I've just been putting myself last for a long time"

---

**DESIGN NOTES:**
- Mom Ghost takes option 1. Style Relic may take option 2, 3, or 4. Both archetypes are covered.
- "Figuring out who I am again" in option 2 is the Style Relic's deeper theme — she knows she has to reclaim something.

---

## SCREEN 5: The Style Loss Question

- **Kind:** Step
- **Progress bar:** ~12%

---

**Title (28px, bold):**
> When did getting dressed stop being something you actually enjoyed?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- "When I had kids — it just slowly stopped mattering"
- "Gradually — over years. I couldn't tell you exactly when."
- "There was a specific point when things changed and it never recovered"
- "I'm not sure it was ever that easy, honestly"

---

## SCREEN 6: Expert Interstitial #1

- **Kind:** Step — expert interstitial (no question)
- **Progress bar:** ~15%
- **Background:** Deep charcoal (#1E1E1E)

---

**Expert card layout:**

```
┌──────────────────────────────────────────────────────┐
│  [Photo: woman, professional, warm expression]        │
│                                                       │
│  CLAIRE HOFFMAN                                       │
│  Certified Image Consultant, 14 years                 │
│  Member, Association of Image Consultants Intl.       │
│                                                       │
│  "The number one thing I see in my practice is       │
│  women who had real, confident personal style —      │
│  and lost it gradually, without noticing.            │
│                                                       │
│  It's not about taste. It's about having formulas    │
│  that match your life as it is right now. When       │
│  life changes and the formulas don't update,         │
│  getting dressed stops working."                     │
└──────────────────────────────────────────────────────┘
```

**Below the card (white text):**
> 90% of women with similar style profiles report feeling more confident within 2 weeks of following their formula.

**Continue button:** `This sounds familiar →` — #FF2A6D, full-width

---

## SCREEN 7: Current Wardrobe Reality

- **Kind:** Step
- **Progress bar:** ~18%

---

**Title (28px, bold):**
> What does your closet look like right now?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- "Mostly practical stuff — things that work but don't feel like me"
- "A mix I've accumulated over the years with no real system"
- "A lot of things I don't wear but can't bring myself to get rid of"
- "Things from a version of me that feels like a long time ago"

---

**DESIGN NOTES:**
- "Things from a version of me that feels like a long time ago" is the Style Relic's heartbeat line. She has things in her closet from when she still felt like herself. They don't fit her life anymore — but she can't let go.
- "Mostly practical stuff that doesn't feel like me" is pure Mom Ghost.

---

## SCREEN 8: The Mom Question

- **Kind:** Step
- **Progress bar:** ~22%

---

**Title (28px, bold):**
> How much of your wardrobe would you describe as "practical" or "mom clothes" — things you wear because they survive your actual day?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- "Almost all of it — I basically dress for survival"
- "More than half"
- "Some — but I still have things I wear for myself"
- "This doesn't really apply to me (I don't have kids)"

---

**DESIGN NOTES:**
- Option 4 keeps the quiz flowing for Style Relics who aren't parents. The quiz adapts.
- "Dress for survival" is the Mom Ghost's exact internal language.

---

## SCREEN 9: What She Wears for Herself

- **Kind:** Step
- **Progress bar:** ~25%

---

**Title (28px, bold):**
> When did you last buy something — or wear something — just for you? Not for a function, not because it was practical. Just because you liked it?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- "Recently-ish — but not consistently"
- "A while ago — longer than I'd like to admit"
- "I honestly cannot remember"
- "I feel guilty spending on myself when I think of everything else that needs attention"

---

**DESIGN NOTES:**
- Option 4 is for the Mom Ghost who has turned self-denial into a virtue. She needs to be seen in this answer — and she needs permission.

---

## SCREEN 10: Multi-Select — The Getting-Dressed Reality

- **Kind:** Step
- **Progress bar:** ~29%

---

**Title (28px, bold):**
> What does a typical morning getting dressed actually look like?

**Subtitle (16px, #6B6B6B):**
> Select all that are true.

---

**Question Type:** Multi-select list

**Answer Options:**
- [ ] I grab whatever is easiest and try not to think about it
- [ ] I put on the same rotation of things I always wear
- [ ] I try something on, hate it, and go back to the usual
- [ ] I occasionally find something that feels good — but I don't know why it works
- [ ] Getting dressed feels like a chore, not something I enjoy
- [ ] I dress for other people's comfort, not my own

**CTA Button:** `That's my morning →` — #FF2A6D, full-width

---

## SCREEN 11: The Before Question

- **Kind:** Step
- **Progress bar:** ~33%

---

**Title (28px, bold):**
> Was there a time in your life when you felt really good about how you dressed?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- "Yes — I had a real style. I knew what worked on me."
- "Yes — and people noticed. I got compliments."
- "Sort of — I had moments, but it was never really consistent"
- "Not really — I've always struggled with this"

---

**DESIGN NOTES:**
- Options 1 and 2 are the Style Relic's emotional home. She reads these and feels the nostalgia sharpen.
- Option 3 is the Mom Ghost who never quite had it locked in — she was figuring it out when motherhood arrived.

---

## SCREEN 12: What Getting Dressed Used to Feel Like

- **Kind:** Step
- **Progress bar:** ~36%

---

**Title (28px, bold):**
> What would you say was different then?

**Subtitle (16px, #6B6B6B):**
> Select the one that feels truest.

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- "Getting dressed was actually fun. I enjoyed it."
- "I had a signature. Something that was reliably, recognizably me."
- "I had formulas — combinations that always worked. Now I don't."
- "I just didn't think about it as much. It was easy."

---

## SCREEN 13: Expert Interstitial #2

- **Kind:** Step — expert interstitial (no question)
- **Progress bar:** ~39%
- **Background:** Deep charcoal (#1E1E1E)

---

**Expert card layout:**

```
┌──────────────────────────────────────────────────────┐
│  [Photo: woman, warm and professional]                │
│                                                       │
│  DIANA REYES                                          │
│  Color Analyst + Personal Stylist, 11 years           │
│  Trained: London College of Fashion                   │
│                                                       │
│  "Women often tell me they've 'lost their style.'    │
│  What I actually see is a woman who still has great  │
│  instincts — she just stopped trusting them because  │
│  the formulas she was using stopped working.         │
│                                                       │
│  When life changes, you need new formulas. Not a     │
│  new wardrobe. Not a new body. New formulas."        │
└──────────────────────────────────────────────────────┘
```

**Below card (white text, #B0B0B0):**
> The average woman has 8–12 complete outfits hiding in her existing wardrobe that she's never seen.

**Continue button:** `I need to see those →` — #FF2A6D, full-width

---

## SCREEN 14: Likert — "I'm not a woman anymore. I'm a mom."

- **Kind:** Step — Likert scale
- **Progress bar:** ~42%

---

**Title (24px, bold):**
> "There are days when I feel like I've completely disappeared into my role — and forgotten that I'm also a person with my own style."

**Subtitle (14px, #6B6B6B):**
> How much does this sound like you?

---

**Question Type:** Single-choice, 5-point scale

**Scale:** Strongly disagree → Strongly Agree

---

## SCREEN 15: Likert — "I used to know how to dress."

- **Kind:** Step — Likert scale
- **Progress bar:** ~45%

---

**Title (24px, bold):**
> "I used to know how to dress. It was part of who I was. And somewhere in the last few years, that just... stopped."

**Subtitle (14px, #6B6B6B):**
> How much does this sound like you?

---

**Question Type:** Single-choice, 5-point scale

**Scale:** Strongly disagree → Strongly Agree

---

## SCREEN 16: Likert — "I feel guilty wanting this."

- **Kind:** Step — Likert scale
- **Progress bar:** ~48%

---

**Title (24px, bold):**
> "Sometimes I feel guilty for even wanting to care about how I look — like it's selfish or shallow when there are more important things."

**Subtitle (14px, #6B6B6B):**
> How much does this sound like you?

---

**Question Type:** Single-choice, 5-point scale

**Scale:** Strongly disagree → Strongly Agree

---

**DESIGN NOTES:**
- This Likert is specifically for the Mom Ghost, but Style Relics who've internalized the "style is frivolous" message will also feel it.
- What follows (Expert Interstitial #3) directly addresses the guilt — timing is intentional.

---

## SCREEN 17: Expert Interstitial #3 — The Permission Screen

- **Kind:** Step — expert interstitial (no question)
- **Progress bar:** ~51%
- **Background:** Deep charcoal (#1E1E1E)

---

**Expert card layout:**

```
┌──────────────────────────────────────────────────────┐
│  [Photo: woman, warm, slightly older]                 │
│                                                       │
│  SARAH MCALLISTER                                     │
│  Style Psychologist + Image Consultant                │
│  Contributor: Psychology Today, Real Simple           │
│                                                       │
│  "Wanting to feel good about how you look is not     │
│  vanity. It is self-respect.                         │
│                                                       │
│  Research consistently shows that women who feel     │
│  confident in their appearance show up differently   │
│  — in their relationships, their work, their energy. │
│                                                       │
│  You are not being selfish. You are being smart."   │
└──────────────────────────────────────────────────────┘
```

**Continue button:** `I'm not being selfish →` — #FF2A6D, full-width

---

**DESIGN NOTES:**
- This screen is THE permission moment for the Mom Ghost. She has been told implicitly — by mom culture, by the way she's been living — that caring about herself is indulgent. A credentialed expert directly contradicts that. This is the emotional unlock.

---

## SCREEN 18: Multi-Select — The Real Cost

- **Kind:** Step
- **Progress bar:** ~54%

---

**Title (28px, bold):**
> When you don't feel good about how you're dressed, what actually happens?

**Subtitle (16px, #6B6B6B):**
> Select all that apply.

---

**Question Type:** Multi-select list

**Answer Options:**
- [ ] I hold back in rooms I used to walk into confidently
- [ ] I avoid being photographed
- [ ] I say no to things — events, dinners, outings — because I can't figure out what to wear
- [ ] I feel like I'm presenting a version of myself that doesn't match how I actually feel
- [ ] I compare myself to other women and feel invisible
- [ ] I envy women who look like they have it together — and wonder where that went for me

**CTA Button:** `This is what it costs →` — #FF2A6D, full-width

---

## SCREEN 19: What She Actually Wants

- **Kind:** Step
- **Progress bar:** ~57%

---

**Title (28px, bold):**
> What would it actually mean to you to get this back?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- "Feeling like myself again when I walk out the door"
- "Showing up in rooms and not feeling invisible"
- "Enjoying getting dressed instead of dreading it"
- "Having a version of myself I'm proud to be again"

---

## SCREEN 20: Wardrobe Inventory

- **Kind:** Step
- **Progress bar:** ~60%

---

**Title (28px, bold):**
> What does your actual wardrobe look like right now?

**Subtitle (16px, #6B6B6B):**
> Be honest — this is how we find your hidden outfits.

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- "Lots of things but nothing really works together"
- "Some good pieces buried under a lot of mediocre stuff"
- "Pieces from a few different eras of my life — nothing cohesive"
- "Mostly basics and practical things — not much I love"

---

## SCREEN 21: Color Confidence

- **Kind:** Step
- **Progress bar:** ~63%

---

**Title (28px, bold):**
> Do you know which colors work best on you?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- "Yes — I've figured out my colors over the years"
- "Sort of — I have a general sense but I'm not confident"
- "Not really — I tend to default to black and neutrals"
- "No idea — I buy things and sometimes they work, sometimes they don't"

---

## SCREEN 22: Lifestyle Context

- **Kind:** Step
- **Progress bar:** ~67%

---

**Title (28px, bold):**
> What does a typical week look like for you?

**Subtitle (16px, #6B6B6B):**
> Your formulas need to work for your actual life.

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- "Working — mix of home and office, or fully office"
- "Working from home most of the time"
- "At home — raising kids, caregiving, or in transition"
- "Mix of everything — no two weeks look the same"

---

## SCREEN 23: Multi-Select — What She's Tried

- **Kind:** Step
- **Progress bar:** ~70%

---

**Title (28px, bold):**
> Have you tried any of these?

**Subtitle (16px, #6B6B6B):**
> Select everything you've attempted.

---

**Question Type:** Multi-select list

**Answer Options:**
- [ ] Cleared out my closet and tried to "start fresh"
- [ ] Followed style accounts on Instagram or Pinterest for inspiration
- [ ] Bought things that looked good on someone else and didn't work on me
- [ ] Considered hiring a personal stylist but it felt like too much money
- [ ] Told myself I'd deal with it when things calmed down
- [ ] Asked my partner or a friend for help

**CTA Button:** `None of it stuck →` — #FF2A6D, full-width

---

## SCREEN 24: Commitment Question

- **Kind:** Step
- **Progress bar:** ~74%

---

**Title (28px, bold):**
> If you had access to formulas that actually worked — combinations from your own closet, matched to your body and your life — how much time would you be willing to spend on this each day?

---

**Question Type:** Single-choice list (auto-advance)

**Answer Options:**
- "5 minutes or less — it needs to be quick"
- "10–15 minutes — I can make that work"
- "Whatever it takes to actually feel good again"
- "Just give me a system and I'll follow it"

---

## SCREEN 25: Email Capture

- **Kind:** Step — email gate
- **Progress bar:** ~79%
- **Background:** Deep charcoal (#1E1E1E)

---

**Headline (28px, bold, white):**
> We've almost matched you.

**Body text (16px, #B0B0B0):**
> Enter your email to unlock your Personal Stylist Match — the specific outfit formulas that fit your profile, your wardrobe, and your life right now.

**Expert note (small, muted, below field):**
> Your match was reviewed using image consultant methodology. This isn't generic advice.

---

**Input field:** Email address

**CTA Button:** `See my stylist match →` — #FF2A6D, full-width

**Privacy note:** > Your email stays with us. Unsubscribe any time.

---

## SCREEN 26: Name Capture

- **Kind:** Step
- **Progress bar:** ~83%

---

**Headline (24px, bold):**
> And your first name?

**Input field:** First name

**CTA Button:** `Show me my match →` — #FF2A6D, full-width

---

## SCREEN 27: Results Loading Screen

- **Kind:** Step — interstitial with loading animation
- **Progress bar:** ~90%
- **Background:** Deep charcoal (#1E1E1E)

---

**Headline (24px, bold, white):**
> Matching your profile, {{firstName}}...

**Loading animation:** Progress bar, fills over ~5 seconds

**Rotating copy beneath:**
> "Analyzing your style history..."
> "Identifying your formula type..."
> "Matching your wardrobe to combinations that work..."
> "Reviewing your match with our style consultant team..."

**Social proof (appears at ~80% load):**

> ⭐⭐⭐⭐⭐
> *"I used to love getting dressed. After my kids were born, I basically gave up. The formula match showed me I still had good instincts — I just needed a system. I'm back."*
> — **Lisa M.**, 43

> ⭐⭐⭐⭐⭐
> *"Getting dressed was fun once. Then it wasn't. Then I tried this and it clicked back on. I don't know what happened but it works."*
> — **Renee T.**, 51

---

## SCREEN 28: Results + Expert Match + Paywall (Custom HTML)

- **Kind:** Custom HTML — results + paywall
- **Paywall Architecture:** THE COACH — Massive SAVE% badges + expert authority + countdown timer
- **Background:** Warm cream (#FFF8F5)

---

### COUNTDOWN TIMER HEADER (sticky, pinned to top)

```
⏱ Your formula match is reserved for: [14:47]   |   This offer expires when the timer reaches zero
```

- Background: #FF2A6D, white bold text, full-width
- Timer counts down in real time

---

### RESULTS HEADER

**Pre-headline (small caps, #FF2A6D):**
> YOUR PERSONAL STYLIST MATCH

**Main Headline (36px, bold, #1E1E1E):**
> {{firstName}}, we found your formula type.

**Subheadline (18px, #6B6B6B):**
> Based on your quiz, you're a **Formula Rebuilder** — a woman who had real personal style, let it drift during a busy season of life, and is ready to reconnect with it. Your match includes the specific combinations that work for your body, your wardrobe, and the woman you actually are.

---

### EXPERT MATCH CARD

```
┌──────────────────────────────────────────────────────┐
│  [Photo: Claire Hoffman]                              │
│                                                       │
│  CLAIRE HOFFMAN — Certified Image Consultant          │
│                                                       │
│  "Based on the profile {{firstName}} submitted, I'd  │
│  classify her as a classic Formula Rebuilder.        │
│                                                       │
│  She has the instincts. She has the wardrobe          │
│  foundation. She just needs the right combinations   │
│  surfaced. Women in this category typically feel a   │
│  measurable shift in confidence within 2 weeks."    │
└──────────────────────────────────────────────────────┘
```

---

### PROOF STRIP

```
★★★★★  4.7/5 from 11,200+ reviews   |   147,000+ style plans created   |   Developed with certified image consultants
```

---

### PLAN SELECTOR

**Section header (24px, bold):**
> Claim your formula match — choose your plan:

---

**PLAN CARD — 6 Months** *(unselected)*

```
┌──────────────────────────────────────────────────────┐
│  🏷️ SAVE 78%                                          │
│                                                       │
│  6 Months                                             │
│  ~~$89.94~~ → $19.99 for 6 months                     │
│  Just $0.11/day                                       │
│                                                       │
│  Renews at $29.99/month — cancel anytime             │
└──────────────────────────────────────────────────────┘
```

---

**PLAN CARD — 3 Months** *(PRE-SELECTED — pink border glow, "Most Popular" badge)*

```
┌──────────────────────────────────────────────────────┐
│  ⭐ MOST POPULAR   🏷️ SAVE 71%                        │
│                                                       │
│  3 Months                                             │
│  ~~$44.97~~ → $12.99 for 3 months                     │
│  Just $0.14/day                                       │
│                                                       │
│  Renews at $19.99/month — cancel anytime             │
└──────────────────────────────────────────────────────┘
```

---

**PLAN CARD — 1 Month** *(unselected)*

```
┌──────────────────────────────────────────────────────┐
│  1 Month                                              │
│                                                       │
│  ~~$14.99~~ → $4.99 first month                       │
│  Just $0.17/day                                       │
│                                                       │
│  Renews at $14.99/month — cancel anytime             │
└──────────────────────────────────────────────────────┘
```

---

**Note on renewal pricing:**
> The 6-month plan renews at $29.99/month (middle tier). The 3-month renews at $19.99/month. The 1-month renews at $14.99/month. Three-tier renewal psychology: the 6-month intro buyer renews at a price that is dramatically below the original price ($89.94) but above the promotional intro — this feels like a fair, sustained deal rather than sticker shock.

---

### PRIMARY CTA BUTTON (large, full-width, #FF2A6D)

```
[ Claim My Formula Match → ]
```

*Sub-copy beneath:* "SSL Secure Checkout. 100% money-back guarantee. Cancel anytime."

**SSL badge row:**
```
[🔒 SSL Secure]  [✓ 100% Money-Back]  [4-Week Results Promise]
```

---

### 4-WEEK RESULTS PROMISE

```
┌──────────────────────────────────────────────────────┐
│  🛡️ 100% MONEY-BACK + 4-WEEK RESULTS PROMISE         │
│                                                       │
│  Follow your formula for 4 weeks.                    │
│  If you don't feel noticeably more confident         │
│  getting dressed — we'll refund every penny.         │
│  No explanations required.                            │
│                                                       │
│  90% of women with your profile report feeling       │
│  more confident within 2 weeks.                      │
│  We're confident you'll be one of them.              │
└──────────────────────────────────────────────────────┘
```

---

### EXPERT ENDORSEMENTS SECTION

**Section header (24px, bold):** Style experts who contributed to your formula system:

---

**Expert 1:**
```
[Photo: Claire Hoffman]
CLAIRE HOFFMAN
Certified Image Consultant, 14 years
Association of Image Consultants International

"The Outfit Formulas system is the closest thing to
having an image consultant in your pocket. I recommend
it specifically to women who are rebuilding their style
identity after a major life transition."
```

---

**Expert 2:**
```
[Photo: Diana Reyes]
DIANA REYES
Color Analyst + Personal Stylist
London College of Fashion trained

"What sets this apart is that it works with what you
own — not what you should buy. That's real styling,
not retail therapy."
```

---

**Expert 3:**
```
[Photo: Sarah McAllister]
SARAH MCALLISTER
Style Psychologist + Image Consultant
Published: Psychology Today, Real Simple

"The research is clear: how women feel about their
appearance affects everything — confidence, energy,
how they show up in every room they walk into.
Outfit Formulas gives that back."
```

---

### TESTIMONIALS (Mom Ghost + Style Relic voices)

> ⭐⭐⭐⭐⭐
> *"I wear what my kids won't destroy. That was my whole wardrobe philosophy for six years. I forgot I used to actually enjoy clothes. The formula match reminded me I still have instincts — I just stopped trusting them."*
> — **Melissa J.**, 39, mother of three

> ⭐⭐⭐⭐⭐
> *"Getting dressed used to be fun. It's been years. The expert match process felt like someone finally taking my style seriously. Two weeks in and I'm getting compliments again."*
> — **Patricia W.**, 52

> ⭐⭐⭐⭐⭐
> *"I used to know how to dress. People told me I had great style. Somewhere in my late forties that just disappeared under leggings and elastic waistbands. I'm back now. It didn't take as long as I thought it would."*
> — **Karen B.**, 54

> ⭐⭐⭐⭐⭐
> *"I felt guilty even doing this quiz — like spending time on how I look was selfish when I had everything else going on. The expert on screen 17 basically gave me permission. That changed something."*
> — **Rachel D.**, 44, stay-at-home mom

---

### FEATURES LIST

**Included with your formula match:**

- Your personal formula library — outfits from what you already own
- Daily outfit suggestions matched to your lifestyle
- Color palette guidance based on your existing wardrobe
- "What to wear when..." decision tool (the events you dread most)
- Morning routine optimizer — 5 minutes, done
- Expert-reviewed formula updates added weekly
- Community of women in the same style season

---

### STICKY FOOTER (always visible while scrolling)

```
⏱ Offer expires in [14:47]   |   [ Claim My Match → ]
```

- Background: #FF2A6D, white text
- CTA scrolls to plan selector

---

### FINE PRINT (small, #6B6B6B)

> Introductory pricing applies to first billing period only. Plans auto-renew at the rate shown in each plan card. Cancel anytime from your account settings. 100% money-back guarantee applies within 30 days of purchase for qualifying plans. See full Terms of Service for details.

---

**DESIGN NOTES for Screen 28:**
- The countdown timer appears in the HEADER and the STICKY FOOTER — urgency is always visible regardless of scroll position
- The "Most Popular" 3-month plan is pre-selected — this is the decoy pricing anchor. The 6-month SAVE 78% is mathematically better, but most women will take the 3-month as the safe middle choice
- Three-tier renewal pricing creates a sustainable feel: she doesn't get shocked at renewal
- Expert photos must be warm and professional — not stock photo clinical. Real women, real credentials.
- The permission moment (Screen 17 reference in the testimonial) creates a closing callback to the most emotionally resonant screen in the quiz

---

# SUMMARY: FUNNEL J SCREEN MAP

| Screen | Type | Purpose |
|--------|------|---------|
| 1 | Start node | Auto-entry |
| 2 | Landing + single-choice | Entry / self-identification |
| 3 | Single-choice | Age |
| 4 | Single-choice | Life stage |
| 5 | Single-choice | When style was lost |
| 6 | Expert interstitial #1 | Claire Hoffman — formula problem framing |
| 7 | Single-choice | Current wardrobe reality |
| 8 | Single-choice | Mom clothes question |
| 9 | Single-choice | Last thing bought for herself |
| 10 | Multi-select | Morning getting-dressed reality |
| 11 | Single-choice | Was there a time she felt good? |
| 12 | Single-choice | What was different then? |
| 13 | Expert interstitial #2 | Diana Reyes — style memory intact |
| 14 | Likert | "Disappeared into my role" |
| 15 | Likert | "Used to know how to dress" |
| 16 | Likert | "I feel guilty wanting this" |
| 17 | Expert interstitial #3 | Sarah McAllister — permission screen |
| 18 | Multi-select | Real cost of wardrobe failure |
| 19 | Single-choice | What she actually wants |
| 20 | Single-choice | Wardrobe inventory |
| 21 | Single-choice | Color confidence |
| 22 | Single-choice | Lifestyle context |
| 23 | Multi-select | What she's tried |
| 24 | Single-choice | Commitment question |
| 25 | Email capture | Email gate |
| 26 | Text input | Name capture |
| 27 | Loading interstitial | Match-building animation |
| 28 | Custom HTML | Results + Expert Match + Paywall |

**Total: 28 screens** ✅

---

# COPY RULES FOR FUNNEL J

1. **Never say "self-care"** — say "feeling like yourself" or "showing up"
2. **Never say "invest in yourself"** — the Mom Ghost has been told this by every wellness brand and it bounces off. Instead: "you're not being selfish"
3. **Mom Ghost voice:** "I'm not a woman anymore. I'm a mom." / "I wear what my kids won't destroy." / "I feel guilty spending on myself"
4. **Style Relic voice:** "I used to know how to dress." / "Getting dressed was FUN." / "It's been years." / "People used to compliment me."
5. **Expert authority is the primary conversion element** — use it generously, but make it feel like real people, not titles
6. **The guilt acknowledgment is essential** — the Mom Ghost cannot convert until she has permission. The Style Relic converts on nostalgia + confirmation.
7. **"Formula match" not "subscription"** — she's not buying a service, she's claiming her match
8. **SAVE% badges must be huge** — this is the architecture's core mechanic. The savings feel so extreme they make the Mom Ghost feel smart for taking it, not indulgent.
9. **Never use "capsule wardrobe," "curated," "elevated," "effortless chic"** — these are the words from every article that ever made her feel worse
10. **"90% of women with similar profiles" stat** appears multiple times — it's the most reassuring number in the funnel

---

*End of Funnel J documentation. Total screens: 28.*

---
*End of of-funnels-IJ.md. Both funnels complete.*
