# Outfit Formulas — Quiz Funnels C & D
## Complete Screen-by-Screen Specifications

---

# FUNNEL C: "Discover Your Style Identity"
## Mom Ghost Archetype | Parenting Leader Paywall Architecture
### 22 Screens Total

---

# WHY THIS FUNNEL WORKS FOR THE MOM GHOST

## The Core Insight

The Mom Ghost doesn't think she has a style problem. She thinks she has a herself problem. She stopped being a woman with taste and preferences somewhere between the third trimester and the third year of school drop-offs. What she's telling herself — what she genuinely believes — is that wanting to look like herself again is shallow. Vain. A betrayal of her priorities.

This funnel's entire job is to dissolve that belief before she even reaches the paywall.

The conversion mechanism isn't pricing psychology or urgency tricks. It's **permission**. Permission to want this. Permission to feel invisible and have that be real, not dramatic. Permission to reclaim the version of herself she packed away because nobody told her she was allowed to keep it.

The Parenting Leader paywall works here because the Mom Ghost trusts authority she can see and touch — awards, magazine logos, institutional recognition. She doesn't trust sales copy. She trusts *proof that other people in her situation chose this and it worked.* The trust badges do that work. The email gate with a "surprise gift" activates the feeling that someone is finally giving HER something, for once.

---

## Stage-by-Stage Psychology Breakdown

### Stage 1 — The Identity Excavation
**What it does:** Gets her to articulate, in her own words, the moment she disappeared.

**Why it works for the Mom Ghost specifically:**

She has a very specific memory. The last time she got dressed and felt like herself. The jeans that fit before. The jacket she loved. She put it on last year and it felt wrong — not because it didn't fit, but because the person wearing it felt like a stranger. These early questions don't diagnose. They ask her to describe her own life. She does the diagnosing herself.

The zero-friction principle: age → how long she's been a mom → wardrobe question. These feel like registration. By question 4, she's already in the habit of honest answers.

### Stage 2 — The Mirror Questions
**What it does:** Reflects her specific morning back to her with enough precision that she thinks the quiz was written about her personally.

**Why it works for the Mom Ghost:**

The Mom Ghost's defining frustration isn't that she has nothing to wear. It's that she has things to wear — they're just not *hers* anymore. Athleisure she bought for comfort. Dark washes that won't show the toddler handprints. A rotation of seven tops she circulates because deciding anything else requires energy she doesn't have. When the quiz names these things specifically, she leans forward. *They know.*

### Stage 3 — The Cost of Invisibility
**What it does:** Moves the pain from abstract feeling to concrete, daily cost.

**Why it works for the Mom Ghost:**

"Feeling invisible" is easy to dismiss. "Skipping your work colleague's birthday drinks because you couldn't face getting dressed" is not. The Mom Ghost has cancelled things. She has declined photos. She has stood in the bathroom before a school event convincing herself it doesn't matter, then spent the whole event feeling like a background extra in her own life. When the quiz names these specific avoidance behaviors, the cost of the problem becomes real and undeniable.

### Stage 4 — The Permission Injection
**What it does:** Pre-emptively dissolves the guilt that would otherwise kill conversion.

**Why it works for the Mom Ghost:**

The Mom Ghost's #1 objection to any style purchase is: *I shouldn't be spending this on myself.* Before she even gets to the paywall, the funnel must dismantle this belief. The info screens validate: wanting to feel like herself isn't about her children — it's about them too. She is better at every other part of her life when she feels like herself. This isn't vanity. This is care.

### Stage 5 — The Style Identity Reveal
**What it does:** Gives her the result she earned — a named, specific style identity that describes who she actually is, not who she became by default.

**Why it works for the Mom Ghost:**

She has been dressing for function for years. She has forgotten that she has a style — a real one, with preferences, aesthetics, things that make her feel *like her*. The Style Identity Card gives that back. It's not a type or a label. It's a mirror that shows her what's been there all along, waiting.

**The Parenting Leader paywall then asks for her email to unlock it.** The awards and trust badges around the email gate tell her: this isn't just another app. This was built for women exactly like you, recognized by the people who recognize things that matter. She's not buying style advice. She's being seen by something credible.

---

## The Central Conversion Mechanism

The quiz never sells the app. It sells **her identity back to her**. By the time the results screen appears, she has:

1. Excavated the specific moment she disappeared (Stage 1)
2. Had her exact morning reflected back to her (Stage 2)
3. Named the real cost — avoidance, invisibility, cancelling her life (Stage 3)
4. Been given permission to want this for herself (Stage 4)
5. Seen her actual style identity — not what she settled for, what's actually hers (Stage 5)

The app is just the mechanism for living in that identity daily.

---

# THE COMPLETE 22-SCREEN FUNNEL

---

## SCREEN 1: Start (Entry Node)

- **Kind:** Start (invisible entry node)
- **Notes:** Automatically transitions to Screen 2. No visible content. Platform handles routing.

---

## SCREEN 2: Landing / Entry

- **Kind:** Step — landing page + single-choice
- **Progress bar:** None

---

**VISUAL ELEMENTS:**

- **Top badge:** `STYLE IDENTITY QUIZ` — pill style, #FF2A6D border, cream text on pink
- **Headline (36–40px, bold, #1E1E1E):**
  > **FIND OUT WHO YOU WERE**
  > **BEFORE YOU BECAME "MOM"**

- **Subheadline (18px, #6B6B6B):**
  > Take the 4-minute quiz and get your Style Identity Card — what your authentic personal style actually is, based on who you are, not what's easiest to grab.

- **Badge:**
  > `⏱ 4-MINUTE QUIZ · 147,000+ WOMEN HAVE TAKEN THIS`

- **Trust line (small, below badge):**
  > As seen in Vogue · Good Housekeeping · Real Simple

---

**QUESTION TYPE:** Single-choice, 2-column grid

**Question text:** *(none — images act as CTA)*

**Answer Options:**
- 🖼️ **I'm a mom** — a warm, candid photo of a real woman (not stock-perfect), casual clothes, genuine expression
- 🖼️ **I'm a woman** — same style photo but different woman, slightly more dressed up

**Behaviour:** Both options advance. This is identity priming — she's choosing how she sees herself right now.

**Footer text (small, legal):**
> By continuing you agree to our Terms of Use and Privacy Policy.

---

**DESIGN NOTES:**
- Background: warm cream (#FFF8F5)
- Headline tells her exactly what this is about — her identity, not her wardrobe
- "Before you became 'Mom'" is the needle. She clicks before she's even aware she decided to.
- No mention of Outfit Formulas as a product yet

---

## SCREEN 3: Age

- **Kind:** Step — question
- **Progress bar:** ~6%

---

**Title (28px, bold):**
> How old are you?

**Subtitle (16px, #6B6B6B):**
> Style formulas look different at 28 versus 42. We personalize yours.

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- Under 28
- 28–34
- 35–42
- 43–50
- 51+

---

**Design notes:**
- Subtitle pre-empts "is this for my age?" without making age feel like a limitation
- Keep it warm. No "mature woman" language.

---

## SCREEN 4: Early Social Proof Interstitial

- **Kind:** Step — interstitial (no question)
- **Progress bar:** ~10%

---

**Visual Element:** Row of circular portraits — real women, diverse ages, warm lighting, all looking directly at camera with quiet confidence (not ecstatic, not posed)

**Title (large, #FF2A6D):**
> 147,000 women

**Body text (bold, centred, #1E1E1E):**
> have already found their Style Identity.

**Supporting text (16px, muted):**
> Most of them thought they'd just "lost it." They hadn't.

**Button:** Continue →

---

**Design notes:**
- "They hadn't lost it" plants the reframe seed before any diagnosis questions
- Portraits must look real — not aspirational. She needs to see women who look like her.

---

## SCREEN 5: Q1 — How Long She's Been a Mom

- **Kind:** Step — question
- **Progress bar:** ~14%
- **Question Number:** Q1 of 18

---

**Title (28px, bold):**
> How long have you been a mom?

**Subtitle (muted):**
> We're not asking to judge the phase — we're using it to calibrate your formula.

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ Less than 1 year — *"Still figuring out who this new version of me is"*
- 🖼️ 1–3 years — *"I'm starting to resurface but my wardrobe hasn't caught up"*
- 🖼️ 4–7 years — *"I have vague memories of having style"*
- 🖼️ 8–12 years — *"My kids are getting older. I'm wondering where I went."*
- 🖼️ 13+ years — *"It's been a long time since I got dressed and felt like me"*
- 🖼️ I'm not a mom — *"But I've still lost my style somewhere"*

---

**Design notes:**
- The answer sub-copies are written as her actual inner monologue — she reads them and thinks the quiz already knows her
- The last option keeps non-moms in the funnel (they convert too)

---

## SCREEN 6: Q2 — The Wardrobe Ratio

- **Kind:** Step — question
- **Progress bar:** ~18%
- **Question Number:** Q2 of 18

---

**Title (28px, bold):**
> Look at your wardrobe right now. How much of it is actually *yours*?

**Subtitle (muted):**
> "Yours" means: clothes you love, that feel like you — not just functional.

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **Almost none** — "It's mostly things that survive kids, washing machines, and nothing spilling"
- 🖼️ **Maybe 20–30%** — "There are a few things I love buried in there"
- 🖼️ **About half** — "Some of it's mine, some of it's just... practical"
- 🖼️ **Most of it** — "I've kept hold of my style even through the chaos"

---

**Design notes:**
- "Not just functional" does a lot of work — it names the word she uses herself
- Most women select option 1 or 2 — this is the first self-labelling moment

---

## SCREEN 7: Q3 — The Last Memory

- **Kind:** Step — question (first emotionally resonant question)
- **Progress bar:** ~22%
- **Question Number:** Q3 of 18

---

**Title (28px, bold):**
> When did you last get dressed and feel like *yourself*?

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **This week** — "Getting dressed still feels like me, mostly"
- 🖼️ **Within the past few months** — "It happens occasionally, when I make the effort"
- 🖼️ **More than a year ago** — "I can't remember the last time I genuinely liked what I put on"
- 🖼️ **I can picture a specific moment** — "There was a time. I just don't know where that went."
- 🖼️ **I honestly can't remember** — "It's been so long I've stopped thinking about it"

---

**Design notes:**
- "I can picture a specific moment" hits hard — she will immediately think of something. That micro-memory is emotionally powerful.
- Last option gives permission to admit the depth of disconnection
- This is where the emotional engine starts

---

## SCREEN 8: Validation Interstitial — "You're Not Vain"

- **Kind:** Step — interstitial (no question)
- **Progress bar:** ~25%

---

**Background:** Warm cream (#FFF8F5). No photo.

**Eyebrow text (small caps, #FF2A6D):**
> BEFORE WE GO FURTHER

**Title (28–32px, bold, #1E1E1E):**
> Wanting to feel like yourself again isn't vain.

**Body copy (18px, #1E1E1E, generous line spacing):**

> It's not a luxury. It's not something to squeeze in after everyone else is sorted.
>
> When you feel invisible — when you look in the mirror and don't recognize the person looking back — that's real. That's not drama.
>
> You spent years making yourself smaller so everyone else could be bigger.
>
> This quiz isn't going to tell you to shop more. It's going to help you see what's already there — the real you, buried under the leggings and the "it'll do" tops and the clothes you bought because they were practical.
>
> She's still there.

**Button:** I'm ready to find her →

---

**Design notes:**
- This is the emotional core of the funnel — the permission screen
- Short paragraphs. Never more than two sentences together.
- "She's still there" is the line that converts. It must land quietly, not triumphantly.
- No image. The words are the only thing on the page. That's intentional.

---

## SCREEN 9: Q4 — The Morning Routine

- **Kind:** Step — question
- **Progress bar:** ~28%
- **Question Number:** Q4 of 18

---

**Title (28px, bold):**
> Describe your typical morning getting dressed.

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **I try on multiple things and hate them all** — "I go back to the safe, boring option every time"
- 🖼️ **I go straight to the rotation** — "Same 5-7 things on repeat. I stopped thinking about it."
- 🖼️ **I grab whatever's clean** — "Freshness is the main criteria right now"
- 🖼️ **I actually enjoy it sometimes** — "But I know I'm capable of enjoying it more"

---

**Design notes:**
- "Same 5-7 things on repeat. I stopped thinking about it." is the Mom Ghost's most common answer
- The last option keeps engaged women in the funnel without alienating them

---

## SCREEN 10: Q5 — The "Mom Clothes" Question

- **Kind:** Step — question
- **Progress bar:** ~32%
- **Question Number:** Q5 of 18

---

**Title (28px, bold):**
> Do you have a mental category called "mom clothes"?

**Subtitle (muted):**
> The stuff that's fine. Practical. Won't ruin if something gets spilled.

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **Yes, and it's basically everything I own** — "My whole wardrobe is in that category now"
- 🖼️ **Yes, most of my wardrobe** — "The 'real' clothes are a small minority"
- 🖼️ **Some of it** — "There are mom clothes and then there are the things I actually love"
- 🖼️ **Not really** — "I've managed to keep my style through all of it"

---

**Design notes:**
- "Mom clothes" is the exact language she uses — not styling language, her language
- "The 'real' clothes are a small minority" hits the nail on the head

---

## SCREEN 11: Q6 — What She Used to Wear

- **Kind:** Step — question
- **Progress bar:** ~35%
- **Question Number:** Q6 of 18

---

**Title (28px, bold):**
> Think back to before kids. What was your style like?

**Subtitle (muted):**
> Not perfectly — just the feeling of it.

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **Put-together. I cared about how I looked and it showed.** — "Getting dressed was actually fun"
- 🖼️ **Casual but intentional.** — "I didn't do formal, but I had my look"
- 🖼️ **A bit everywhere.** — "I was figuring it out but it felt like me"
- 🖼️ **Honestly, I've always struggled with it** — "Style has never been my strong suit"

---

**Design notes:**
- First three options all point toward identity reclamation — she had something, it's recoverable
- Fourth option validates women who've always felt lost — they're still the right customer

---

## SCREEN 12: Q7 — The Guilt Question

- **Kind:** Step — question
- **Progress bar:** ~38%
- **Question Number:** Q7 of 18

---

**Title (28px, bold):**
> When you think about spending time or money on your style, what's the first feeling that comes up?

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **Guilt** — "There are other things that money should go towards"
- 🖼️ **It feels pointless** — "What's the point? I'm just going to school pickup anyway"
- 🖼️ **Mild defensiveness** — "I shouldn't have to justify it but I feel like I do"
- 🖼️ **Excitement mixed with guilt** — "I want it but I feel bad wanting it"
- 🖼️ **Fine, actually** — "I've made peace with wanting this for myself"

---

**Design notes:**
- This question names the guilt so she doesn't have to carry it alone
- "What's the point? I'm just going to school pickup anyway" is devastating in its accuracy
- Last option validates women who've already overcome this — they're still converting

---

## SCREEN 13: Q8 — Identity Feelings (Likert agreement)

- **Kind:** Step — question (Likert scale)
- **Progress bar:** ~42%
- **Question Number:** Q8 of 18

---

**Title (28px, bold):**
> How much does this sound like you?

**Subtitle:**
> *"I'm a woman with my own personality and taste. I just don't look like it right now."*

---

**Question Type:** Single-choice, 5-point scale

**Answer Options:**
- Completely — this is exactly me
- Mostly yes
- Somewhat
- Not really
- Not at all

---

**Design notes:**
- Likert format gives clinical weight to a vulnerable question
- Almost every Mom Ghost selects "Completely" or "Mostly yes"
- The statement plants the core belief of the funnel: she HAS a style. It's just hidden.

---

## SCREEN 14: Q9 — Likert: The Invisible Feeling

- **Kind:** Step — question (Likert scale)
- **Progress bar:** ~45%
- **Question Number:** Q9 of 18

---

**Title (28px, bold):**
> How much does this sound like you?

**Subtitle:**
> *"Sometimes I feel invisible. Not just to other people — to myself."*

---

**Question Type:** Single-choice, 5-point scale

**Answer Options:**
- Completely — I know exactly what this feels like
- Mostly yes
- Sometimes
- Not really
- Not at all

---

**Design notes:**
- "Not just to other people — to myself" is the line that lands
- For the Mom Ghost, this gets a "Completely" almost every time
- Back-to-back Likerts maintain clinical credibility — this feels like a real assessment

---

## SCREEN 15: Q10 — The Avoidance Question

- **Kind:** Step — question
- **Progress bar:** ~48%
- **Question Number:** Q10 of 18

---

**Title (28px, bold):**
> Have you ever avoided something — an event, a photo, a night out — because you couldn't face getting dressed?

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **Yes, more than once** — "I've passed on things I actually wanted to do"
- 🖼️ **Yes, once or twice** — "I've given 'I'm tired' as the reason when that wasn't really it"
- 🖼️ **I've thought about it but gone anyway** — "I showed up feeling terrible about how I looked"
- 🖼️ **No, I always push through** — "But it costs me something to do it"
- 🖼️ **This hasn't really been an issue for me**

---

**Design notes:**
- The parenthetical answers under the first two options are the emotional gut-punch
- "I've given 'I'm tired' as the reason" is the specific lie she tells herself — she will recognize it instantly
- This expands the cost from wardrobe frustration to real life missed

---

## SCREEN 16: Q11 — Multi-Select: The Real Frustrations

- **Kind:** Step — question (multi-select)
- **Progress bar:** ~52%
- **Question Number:** Q11 of 18

---

**Title (28px, bold):**
> Which of these do you recognize? Pick everything that applies.

---

**Question Type:** Multi-select (tap to select, "Continue" button appears after first selection)

**Answer Options:**
- [ ] I look frumpy even in things that should work
- [ ] I buy things that seem right in the store and never wear them
- [ ] Everything in my wardrobe feels "not quite right"
- [ ] I know I have the pieces but I can't make them into outfits
- [ ] I've stopped noticing what I'm wearing because it doesn't feel worth noticing
- [ ] I feel like I've let myself go — and I hate that phrase but it's accurate
- [ ] I see other women my age looking like themselves and I feel sad
- [ ] Getting dressed used to be fun. I miss that.

**Button:** This is my closet →

---

**Design notes:**
- "Frumpy" is the #1 word — it must be first
- "I've stopped noticing what I'm wearing" is the deepest level of disconnection — it hits
- "I hate that phrase but it's accurate" — the self-awareness here is important. She's smart. She knows.
- Most women will select 5–7 of these. Every selection is a micro-commitment.

---

## SCREEN 17: Q12 — What She Actually Buys For

- **Kind:** Step — question
- **Progress bar:** ~55%
- **Question Number:** Q12 of 18

---

**Title (28px, bold):**
> When you buy clothes now, what's the main thing you're looking for?

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **Practicality** — "Will it survive real life? Can I wash it easily?"
- 🖼️ **Something to hide in** — "Dark colors. Loose fit. Nothing that draws attention."
- 🖼️ **Something to feel better in** — "I keep hoping the next purchase will fix it"
- 🖼️ **Things that actually work with what I have** — "I'm trying to be more strategic"
- 🖼️ **Things I love** — "I haven't given up on dressing well"

---

**Design notes:**
- "Something to hide in" is brutal and specific and she will recognize herself immediately
- "I keep hoping the next purchase will fix it" — the shopping-as-therapy loop that doesn't work

---

## SCREEN 18: Q13 — The Dream Version

- **Kind:** Step — question
- **Progress bar:** ~58%
- **Question Number:** Q13 of 18

---

**Title (28px, bold):**
> If getting dressed tomorrow morning felt *good* — what would that mean to you?

**Subtitle (muted):**
> Not about looking perfect. About how you'd feel.

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **I'd feel like myself again** — "Not invisible. Not frumpy. Just... me."
- 🖼️ **I'd feel confident going into my day** — "Without having to convince myself I look fine"
- 🖼️ **I'd feel like I'd given myself something** — "Like I'd looked after myself for once"
- 🖼️ **I'd feel less exhausted** — "The decision fatigue alone drains me before 9am"
- 🖼️ **I'd stop feeling like a background character in my own life**

---

**Design notes:**
- "Not invisible. Not frumpy. Just... me." — the two exact words from her vocabulary
- Last option is the most powerful in the set — she will pause before clicking it

---

## SCREEN 19: Q14 — The Last Purchase (Herself)

- **Kind:** Step — question
- **Progress bar:** ~62%
- **Question Number:** Q14 of 18

---

**Title (28px, bold):**
> When did you last buy something for yourself — that was genuinely *for* you, not for function?

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **Recently** — "Within the last few months"
- 🖼️ **Last year** — "I can remember it specifically"
- 🖼️ **A couple of years ago** — "It's been a while"
- 🖼️ **I can't remember** — "Kids' needs, house things — I go last"
- 🖼️ **I don't, really** — "I feel wrong spending on myself"

---

**Design notes:**
- This question turns spending guilt into tangible evidence of self-deprioritization
- "I go last" — she will read this and feel both seen and sad. That's the right emotional note before the permission screens.

---

## SCREEN 20: Q15 — Style Goals (Multi-select)

- **Kind:** Step — question (multi-select)
- **Progress bar:** ~65%
- **Question Number:** Q15 of 18

---

**Title (28px, bold):**
> What do you most want to feel when you get dressed? (Pick all that apply)

---

**Question Type:** Multi-select

**Answer Options:**
- [ ] Like myself — not like someone's mom
- [ ] Put-together without trying too hard
- [ ] Comfortable in my own skin
- [ ] Like I didn't just grab the nearest thing
- [ ] Visible. Actually seen.
- [ ] Proud of how I look
- [ ] Like getting dressed is something I enjoy again

**Button:** These are my goals →

---

**Design notes:**
- "Visible. Actually seen." — the invisibility theme made concrete
- These answers will be surfaced in the results screen personalisation
- Every selection is a commitment to wanting this

---

## SCREEN 21: Q16 — Style Aesthetic (Feeling-Based)

- **Kind:** Step — question
- **Progress bar:** ~70%
- **Question Number:** Q16 of 18

---

**Title (28px, bold):**
> When you imagine a version of yourself that's dressed like *you*, what does that feel like?

**Subtitle (muted):**
> Not a celebrity. Not Instagram. Just: you, looking good, feeling right.

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **Warm, easy, approachable** — "Relaxed but put-together. Soft colors. Natural fabrics."
- 🖼️ **Clean, strong, pulled-together** — "Simple silhouettes. I want to look like I have my act together."
- 🖼️ **Colorful, interesting, a bit unexpected** — "I used to be the one with the great jacket"
- 🖼️ **Feminine but not fussy** — "I like looking like a woman without it being complicated"
- 🖼️ **Honestly, I'm not sure yet** — "I lost touch with my own preferences"

---

**Design notes:**
- These descriptions become part of the Style Identity Card result
- "I lost touch with my own preferences" — a heartbreaking answer she will select without embarrassment here, because the quiz has made her feel safe

---

## SCREEN 22: Q17 — Referral Source

- **Kind:** Step — question
- **Progress bar:** ~73%
- **Question Number:** Q17 of 18

---

**Title (28px, bold):**
> How did you hear about this quiz?

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ Instagram or Facebook
- 🖼️ A friend sent it to me
- 🖼️ TikTok
- 🖼️ Pinterest
- 🖼️ Google search
- 🖼️ I don't remember

---

**Design notes:**
- Data collection for attribution — keep it fast, no emotional weight

---

## SCREEN 23: Q18 — Commitment Question

- **Kind:** Step — question
- **Progress bar:** ~78%
- **Question Number:** Q18 of 18

---

**Title (28px, bold):**
> If we showed you exactly which outfits are hiding in your current wardrobe — would you actually use them?

**Subtitle (muted):**
> Be honest. No judgment either way.

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **Yes, absolutely** — "I'm ready to actually do something about this"
- 🖼️ **I think so** — "I want to. I'm just not sure I'll stick with it"
- 🖼️ **Maybe, if it's genuinely easy** — "I have zero time for complicated systems"
- 🖼️ **I'm not sure** — "I want to want it, if that makes sense"

---

**Design notes:**
- All answers advance — even "I'm not sure" is honest engagement
- "I want to want it" is real Mom Ghost language — permission to be ambivalent
- The question plants expectation: we ARE going to show you the outfits. That's the promise.

---

## SCREEN 24: Loading / Analysis Screen

- **Kind:** Step — interstitial (loading/results building)
- **Progress bar:** ~85%

---

**Visual:** Progress animation. Bar fills. Or stepping checklist with checkmarks appearing one by one.

**Headline (24px, bold):**
> Building your Style Identity Card...

**Animated checklist items (appear one by one, each with pink checkmark):**
- ✓ Analyzing your current style stage
- ✓ Matching your aesthetic preferences
- ✓ Finding your signature outfit formulas
- ✓ Generating your Style Identity Card

**Testimonials strip (carousel, rotates while loading):**

> ⭐⭐⭐⭐⭐
> *"I'd completely forgotten I even had a style. Looking at my Style Identity Card was like meeting someone I used to know."*
> — **Kirsty L.**, mom of 3, Leeds

> ⭐⭐⭐⭐⭐
> *"I cried a little reading the results. It said things I'd been feeling but couldn't articulate."*
> — **Sarah M.**, 38, Edinburgh

> ⭐⭐⭐⭐⭐
> *"I went through the whole quiz thinking 'this is exactly me.' That hasn't happened with anything in years."*
> — **Jessica T.**, mom of 2, Austin

**Auto-advance after 4 seconds**

---

## SCREEN 25: Results — Style Identity Card

- **Kind:** Step — results (custom display, no question)
- **Progress bar:** 90%

---

**Background:** Warm cream. Premium card design. Pink (#FF2A6D) accents.

**Pre-headline (small caps, #FF2A6D):**
> YOUR STYLE IDENTITY CARD

**Card visual (centered, bordered in pink, warm cream background):**
```
┌─────────────────────────────────────────────┐
│            OUTFIT FORMULAS                  │
│          Style Identity Card                │
│                                             │
│  Style Identity:  [DYNAMIC — based on Q16]  │
│  e.g., "THE WARM MINIMALIST"                │
│       "THE QUIETLY BOLD"                    │
│       "THE EASE SEEKER"                     │
│       "THE SOFT MAXIMALIST"                 │
│                                             │
│  Your Style Stage: Recovering               │
│  Formula Match:  High                       │
│  Hidden Outfits in Your Closet:  30–50+     │
│                                             │
└─────────────────────────────────────────────┘
```

**Body copy below card (18px, #1E1E1E):**

> This is your starting point. Not a label — a compass.
>
> Based on what you've told us, your authentic style has been there all along. It just hasn't had a framework to live in.
>
> You have an estimated **30–50+ outfits** in your current wardrobe you've never seen. Your Style Identity Card is the key to finding them.
>
> To unlock the full card and your personalized outfit formulas, enter your email below.

---

**TRUST BADGE ROW (centred, horizontal, below copy):**

```
[🏆 App Store Editor's Choice]  [⭐ Women's Choice Award 2026]
[📰 Featured in Vogue · Good Housekeeping · Real Simple]
```

- Each badge styled as a small seal/logo with icon
- Pink and cream color palette — editorial, not techy
- These badges are NOT at the bottom. They are BETWEEN the results and the email CTA.

---

**Note:** Full Style Identity Card details are intentionally "locked" — blurred or partially revealed. Email unlocks the full card.

---

## SCREEN 26: Email Gate (Parenting Leader Paywall — Step 1)

- **Kind:** Step — email capture (Parenting Leader architecture)
- **Progress bar:** 95%

---

**Background:** Warm cream transitioning to soft pink gradient at bottom

**Eyebrow text (small caps, #FF2A6D):**
> UNLOCK YOUR STYLE IDENTITY CARD

**Headline (32px, bold, #1E1E1E):**
> Enter your email to get your full results — plus a free gift.

**Sub-headline (18px, #6B6B6B):**
> Your Style Identity Card + a FREE copy of the **"5-Minute Outfit Formula" guide** — normally $12.99, yours free today.

---

**AWARD/TRUST SECTION (immediately above email field):**

```
┌─────────────────────────────────────────────────────┐
│                                                     │
│  🏆  App Store Editor's Choice                      │
│      "The best style app we've ever featured"       │
│                                                     │
│  ⭐  Women's Choice Award 2026                      │
│      Voted #1 style app by women's recommendation   │
│                                                     │
│  📰  As seen in:                                    │
│      [Vogue]  [Good Housekeeping]  [Real Simple]    │
│                                                     │
└─────────────────────────────────────────────────────┘
```

---

**Email input field:**
```
[  Your email address          ]
```
Placeholder: `hello@email.com`

**CTA Button (full-width, #FF2A6D, bold, 18px):**
```
[ Send Me My Style Identity Card + Free Guide → ]
```

**Sub-copy beneath button (small, #6B6B6B):**
> We'll never send spam. Unsubscribe any time.

---

**GIFT PREVIEW BLOCK:**
```
🎁 YOUR FREE GIFT INCLUDED:

"The 5-Minute Outfit Formula" — a quick-start guide
showing you exactly how to use formula-based dressing
starting with the clothes you already own.

Instant download. Yours free.
```

---

**Design notes:**
- The awards/trust badges are the PRIMARY selling mechanism — positioned between the user's emotional investment in her results and the email field
- The "gift" framing is critical: she's not handing over data, she's receiving something
- Award copy is warm and editorial, not techy or salesy
- This is not a "sign up" — it's "send me my results"

---

## SCREEN 27: Post-Email — Plan Page (Parenting Leader Architecture)

- **Kind:** Step — pricing/plan page
- **Progress bar:** 100%

---

**Background:** Warm cream. Clean layout. No urgency timers. No countdown.

**Pre-headline (small caps, #FF2A6D):**
> YOUR STYLE IDENTITY CARD IS ON ITS WAY

**Headline (32px, bold, #1E1E1E):**
> One last step: unlock your daily outfit formulas.

**Sub-headline (18px, #6B6B6B):**
> Your Style Identity Card tells you who you are. Outfit Formulas shows you what to wear every single day — from clothes you already own.

---

**PLAN CARDS (three tiers, clean card layout):**

---

**PLAN CARD 1 — Weekly**
```
┌─────────────────────────────────────┐
│  Weekly                             │
│                                     │
│  $4.99 / week                       │
│  $0.71/day                          │
│                                     │
│  ✓ Daily outfit suggestions         │
│  ✓ Formula-based dressing           │
│  ✓ Closet visibility system         │
│  ✓ Cancel anytime                   │
└─────────────────────────────────────┘
```

---

**PLAN CARD 2 — Monthly** *(pre-selected, pink border, "MOST POPULAR" badge)*
```
┌─────────────────────────────────────┐
│  ⭐ MOST POPULAR                    │
│                                     │
│  Monthly                            │
│  $9.99 / month                      │
│  Just $0.33/day                     │
│                                     │
│  ✓ Daily outfit suggestions         │
│  ✓ Formula-based dressing           │
│  ✓ Closet visibility system         │
│  ✓ Style Identity integration       │
│  ✓ Cancel anytime                   │
└─────────────────────────────────────┘
```

---

**PLAN CARD 3 — Annual** *(pink "BEST VALUE" badge, 58% savings)*
```
┌─────────────────────────────────────┐
│  🏆 BEST VALUE — SAVE 58%           │
│                                     │
│  Annual                             │
│  $49.99 / year  (~$4.17/month)      │
│  Just $0.14/day                     │
│                                     │
│  ✓ Everything in Monthly            │
│  ✓ Full formula library access      │
│  ✓ 5-Minute Outfit Formula guide    │
│  ✓ Priority support                 │
│  ✓ Cancel anytime                   │
└─────────────────────────────────────┘
```

---

**CTA Button (full-width, #FF2A6D, bold):**
```
[ Start My Free 7-Day Trial → ]
```

*Sub-copy beneath button:* "No charge today. Cancel before day 7 and you're never billed."

---

**TRUST ROW (below CTA):**
```
[🔒 Secure Checkout]  [⭐ 4.8 Stars — 22,000+ Reviews]  [🛡️ 30-Day Guarantee]
```

---

**TESTIMONIAL (below trust row):**

> ⭐⭐⭐⭐⭐
> *"I downloaded this as a skeptic. I had my formula in 20 minutes. I've gotten more compliments in the past month than in the last two years."*
> — **Rachel P.**, mom of 2, Portland

> ⭐⭐⭐⭐⭐
> *"The Style Identity Card showed me exactly what I'd lost. The app helped me get it back. I feel like me again."*
> — **Diane W.**, 41, Chicago

---

**COMPARISON BLOCK (below testimonials):**

```
Personal stylist:         $1,500–$4,000
Outfit Formulas annual:   $49.99/year

Same result. From your existing wardrobe.
```

---

**Design notes:**
- NO countdown timer. NO urgency. The Parenting Leader model sells on trust, not pressure.
- Awards already converted her at the email gate — this page just needs to be clear and frictionless
- The testimonials reinforce the Style Identity Card experience she just had, not generic praise
- Free 7-day trial lowers final barrier to zero

---

# SUMMARY OF FUNNEL C SCREENS

| # | Type | Description |
|---|------|-------------|
| 1 | Start (invisible) | Entry node |
| 2 | Single-choice grid | Landing / identity selection |
| 3 | Single-choice list | Age |
| 4 | Interstitial | Early social proof |
| 5 | Single-choice list | Q1 — How long she's been a mom |
| 6 | Single-choice list | Q2 — Wardrobe ratio |
| 7 | Single-choice list | Q3 — Last memory of feeling herself |
| 8 | Interstitial | Permission screen — "You're not vain" |
| 9 | Single-choice list | Q4 — Morning routine |
| 10 | Single-choice list | Q5 — "Mom clothes" |
| 11 | Single-choice list | Q6 — What she used to wear |
| 12 | Single-choice list | Q7 — Guilt question |
| 13 | Likert (5-point) | Q8 — "A woman with my own taste" |
| 14 | Likert (5-point) | Q9 — The invisible feeling |
| 15 | Single-choice list | Q10 — Avoidance behavior |
| 16 | Multi-select | Q11 — Real frustrations |
| 17 | Single-choice list | Q12 — What she buys for |
| 18 | Single-choice list | Q13 — The dream version |
| 19 | Single-choice list | Q14 — Last purchase for herself |
| 20 | Multi-select | Q15 — Style goals |
| 21 | Single-choice list | Q16 — Style aesthetic (feeling-based) |
| 22 | Single-choice list | Q17 — Referral source |
| 23 | Single-choice list | Q18 — Commitment question |
| 24 | Interstitial | Loading / results building |
| 25 | Custom display | Results — Style Identity Card |
| 26 | Email capture | Parenting Leader email gate + trust badges |
| 27 | Custom paywall | Plan page — 3 tiers, 7-day trial |

**Total: 27 screens (22 quiz + 2 interstitials + 1 results + 2 paywall)**
**Questions: 18 (Q1–Q18)**

---

# KEY COPY RULES FOR FUNNEL C

1. **"Frumpy"** is used exactly once — Q11, as first option. It lands because it's specific.
2. **"Invisible"** is the emotional thread — appears in Q9, Q14, Q18, and results
3. **Never say "capsule wardrobe"** — say "the clothes you reach for"
4. **Never say "put-together"** with irony — she wants to look put-together and that's valid
5. **Permission language throughout** — "you're allowed to want this"
6. **Her words, not styling words** — "mom clothes," "the rotation," "something to hide in"
7. **Identity over appearance** — "feel like yourself" not "look great"
8. **The awards sell, not the copy** — trust badges do the conversion work at the paywall

---
---
---

# FUNNEL D: "Your Style Recovery Plan"
## Meno-Morpher Archetype | Nerva Clinical Architecture
### 28 Screens Total

---

# WHY THIS FUNNEL WORKS FOR THE MENO-MORPHER

## The Core Insight

The Meno-Morpher's problem is not that she doesn't know how to dress. She dressed well for twenty years. She had formulas that worked. She knew her body.

Then her body changed — and not just in weight. It *reorganized itself.* The waist that used to cinch. The proportions she'd mastered. The silhouettes that were automatic. All of it stopped working seemingly overnight. She's been standing in her wardrobe for three years trying to make the old rules apply to a body they were never built for.

This is not a wardrobe problem. **This is an outdated formula problem.**

The Nerva architecture works here because the Meno-Morpher has been failed by non-clinical, non-specific advice. Pinterest hasn't helped. Magazine tips haven't helped. "Dress for your body type" hasn't helped — she doesn't want to dress for a type, she wants her *specific* formulas back. The clinical framing says: this is a real, specific, solvable problem with a real, specific, measurable solution. The Results Date makes it feel like a treatment plan, not another subscription.

---

## Stage-by-Stage Psychology Breakdown

### Stage 1 — The Body Change Timeline
**What it does:** Gets her to articulate, in her own words, exactly when and how things changed.

**Why it works for the Meno-Morpher specifically:**

She has a very precise memory of when her old formulas stopped working. It wasn't gradual. It was a Tuesday when the trousers that always fit suddenly didn't — or more accurately, they fit but looked completely different. She has been holding a diagnosis of herself ("I've gained weight") that doesn't fully explain what she's experiencing. The quiz validates a different, more accurate diagnosis: "Your body reorganized itself. Your formulas didn't adapt."

### Stage 2 — The Validation of Confusion
**What it does:** Normalizes her specific confusion (not "weight gain" confusion — body-change confusion).

**Why it works:**

The Meno-Morpher's specific shame is that she can't understand why things that used to work don't work anymore. She hasn't "let herself go." She's wearing the same brands. She's in the same price range. She's doing everything she used to do. The quiz explains why this isn't her fault: her formulas were built for a different body. Not a worse body. A different one.

### Stage 3 — The Expert Credibility Build
**What it does:** Establishes the clinical/expert framing that will make the Results Date and paywall credible.

**Why it works:**

She has tried the general advice. "Wear A-line skirts." "Empire waists are your friend." "Focus on your assets." These are not formulas — they're platitudes. The expert framing says: we went further than that. We built this with people who understand body changes at a physiological level, not just a fashion level.

### Stage 4 — The Results Date Setup
**What it does:** Transforms a subscription purchase into a treatment timeline.

**Why it works:**

The Meno-Morpher is not impulsive. She has been burned by quick fixes. The Results Date (21 days from now) works because it converts "am I buying an app?" into "am I starting a recovery plan with a measurable endpoint?" The answer is obviously yes. The "89% of women" stat gives her a base rate for success — she's a likely beneficiary, not a gambler.

### Stage 5 — The Recovery Plan Reveal
**What it does:** Shows her a personalized, specific, measurable plan with her own Results Date.

**Why it works:**

The clinical-style output — not a "score" or a "type" but a *recovery plan* with a date — is the most powerful piece of this funnel. She's not buying style inspiration. She's starting a recovery. The pre-paywall social proof stats screen further confirms she's in the right place. The free 7-day trial removes the last friction.

---

## The Central Conversion Mechanism

By the time the paywall appears, she has:

1. Named exactly when and how her body changed (Stage 1)
2. Had the accurate diagnosis confirmed: formulas need updating, not weight (Stage 2)
3. Seen that this was built by people who understand body changes specifically (Stage 3)
4. Been given her personal Results Date 21 days from today (Stage 4)
5. Seen social proof that women like her see measurable results within 3 weeks (Stage 5)

She is not buying an app. She is starting her Style Recovery Plan. Today's date is Day 1.

---

# THE COMPLETE 28-SCREEN FUNNEL

---

## SCREEN 1: Start (Entry Node)

- **Kind:** Start (invisible entry node)
- **Notes:** Automatically transitions to Screen 2.

---

## SCREEN 2: Landing / Entry

- **Kind:** Step — landing page + single-choice
- **Progress bar:** None

---

**VISUAL ELEMENTS:**

- **Top badge:** `STYLE RECOVERY QUIZ` — pill style, #FF2A6D border

- **Expert credibility line (small, above headline):**
  > Developed with image consultants and body-positivity researchers

- **Headline (36–40px, bold, #1E1E1E):**
  > **YOUR OLD FORMULAS AREN'T BROKEN**
  > **BECAUSE YOU DID SOMETHING WRONG**

- **Subheadline (18px, #6B6B6B):**
  > They're broken because they were built for a body you don't have anymore. Take this 5-minute quiz and get your personalized Style Recovery Plan.

- **Badge:**
  > `⏱ 5-MINUTE QUIZ · 147,000+ WOMEN HAVE TAKEN THIS`

- **Press logos (small, below badge):**
  > As seen in: [Vogue] [Real Simple] [Well+Good] [InStyle]

---

**QUESTION TYPE:** Single-choice, 2-column grid

**Answer Options:**
- 🖼️ **My body has changed** — "I need formulas for the body I have now"
- 🖼️ **My style has stopped working** — "Everything used to work. Now nothing does."

**Behaviour:** Both options advance. Both are right for this user.

**Footer text (small, legal):**
> By continuing you agree to our Terms of Use and Privacy Policy.

---

**DESIGN NOTES:**
- The headline is the entire reframe. It does the full permission-giving work in 12 words.
- "Built for a body you don't have anymore" — this is the most important sentence in the funnel
- Clinical expert line above the headline establishes authority before she's even clicked

---

## SCREEN 3: Age

- **Kind:** Step — question
- **Progress bar:** ~5%

---

**Title (28px, bold):**
> How old are you?

**Subtitle (16px, #6B6B6B):**
> Body-change patterns vary significantly across decades. This calibrates your recovery plan.

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- Under 35
- 35–42
- 43–50
- 51–58
- 59+

---

**Design notes:**
- "Body-change patterns" is clinical language that validates this as a real, known phenomenon
- Note the age ranges are calibrated for perimenopause onset (typically 40–51)

---

## SCREEN 4: Expert Credibility Interstitial

- **Kind:** Step — interstitial
- **Progress bar:** ~8%

---

**Visual Element:** Clean panel. No clutter. White coat doesn't fit the brand — instead: a warm photo of two women in a professional setting, looking at fabric or photos, confident.

**Eyebrow text (small caps, #FF2A6D):**
> BUILT DIFFERENTLY

**Title (28px, bold, #1E1E1E):**
> This isn't another "dress for your body type" quiz.

**Body copy (16px, #6B6B6B):**

> Those rules were built for women in their 20s and 30s.
>
> Outfit Formulas was developed with image consultants and body-positivity researchers who specialize in body changes — not body types. The difference matters.
>
> We don't classify your body. We identify the formulas that work for your body as it is right now. Then we show you how to apply them to what you already own.

**Social proof line:**
> Over 147,000 women have already found their Style Recovery Plan.

**Button:** I'm ready →

---

**Design notes:**
- "Those rules were built for women in their 20s and 30s" — this is the Meno-Morpher's exact feeling articulated
- "Right now" is important — not "forever." Formulas adapt.
- The competitor reframe ("not another body type quiz") is doing heavy lifting

---

## SCREEN 5: Q1 — When Things Changed

- **Kind:** Step — question
- **Progress bar:** ~12%
- **Question Number:** Q1 of 22

---

**Title (28px, bold):**
> When did you first notice your old way of dressing stopped working?

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **In the last year** — "It's recent. I'm still trying to figure out what's happened."
- 🖼️ **1–3 years ago** — "I've been struggling for a while now"
- 🖼️ **3–5 years ago** — "I've adapted — but not well. I've just settled."
- 🖼️ **More than 5 years ago** — "It's been a long time since getting dressed felt good"
- 🖼️ **It was gradual — I can't pin it down** — "It's like it crept up on me"

---

**Design notes:**
- First question establishes a timeline — clinical intake feels
- "I've adapted — but not well. I've just settled." — this is devastating and accurate

---

## SCREEN 6: Q2 — How Her Body Changed

- **Kind:** Step — question (multi-select)
- **Progress bar:** ~15%
- **Question Number:** Q2 of 22

---

**Title (28px, bold):**
> What changed? Pick everything that feels true.

**Subtitle (muted):**
> No judgment — just data. This shapes your formula system.

---

**Question Type:** Multi-select

**Answer Options:**
- [ ] My midsection is completely different — it's not about weight, it's about shape
- [ ] I gained weight and it went somewhere new
- [ ] My proportions shifted — things that used to balance don't anymore
- [ ] My bust changed (larger or smaller)
- [ ] My hips and waist changed relative to each other
- [ ] I'm in perimenopause or menopause and my body reorganized itself
- [ ] I had a baby and my body hasn't gone back
- [ ] Something changed after a medication or health event
- [ ] I can't explain it — things just stopped working

**Button:** This is what changed →

---

**Design notes:**
- "My body reorganized itself" is the Meno-Morpher's #1 phrase — it must appear here verbatim
- Clinical multi-select format creates intake form feeling — this is a diagnosis, not a survey
- "I can't explain it — things just stopped working" captures the disorientation she can't articulate

---

## SCREEN 7: Q3 — The Formulas That Broke

- **Kind:** Step — question (multi-select)
- **Progress bar:** ~18%
- **Question Number:** Q3 of 22

---

**Title (28px, bold):**
> Which of these specifically stopped working? Pick all that apply.

---

**Question Type:** Multi-select

**Answer Options:**
- [ ] The silhouettes I always relied on look wrong now
- [ ] Tops that used to work now sit differently on my shoulders and chest
- [ ] High-waisted things that looked great now feel uncomfortable or wrong
- [ ] My go-to jeans cut no longer flatters me
- [ ] Things I loved for ten years suddenly don't work
- [ ] I go back to stores where I always found things and leave empty-handed
- [ ] I'm wearing the same few things on repeat because nothing else feels right

**Button:** Yes, these →

---

**Design notes:**
- Specific, anatomical — "shoulders and chest," "high-waisted," "jeans cut"
- This level of specificity creates deep recognition — she has thought exactly these thoughts
- "Stores where I always found things and leave empty-handed" is a specific grief

---

## SCREEN 8: Expert Validation Interstitial

- **Kind:** Step — interstitial
- **Progress bar:** ~22%

---

**Background:** Warm cream. Centered text. No photo.

**Eyebrow text (small caps, #FF2A6D):**
> HERE'S WHAT'S ACTUALLY HAPPENING

**Title (28–32px, bold, #1E1E1E):**
> Your old formulas aren't broken because you did something wrong.

**Body copy (18px, #1E1E1E):**

> They're broken because they were built for a body you don't have anymore.
>
> This is a calibration problem — not a you problem.
>
> For most women, body changes after 40 aren't about weight alone. They're about proportion shifts — the relationship between waist, hip, and shoulder changes in ways that make old formulas genuinely not work.
>
> The answer isn't to find better clothes. It's to build new formulas for the body you're in right now.
>
> That's what the next few minutes will help you do.

**Button:** Keep going →

---

**Design notes:**
- "A calibration problem — not a you problem" is the single most important reframe in this funnel
- Clinical, explanatory language — she's smart and she wants the real answer, not reassurance
- Short paragraphs. Each one a complete thought.

---

## SCREEN 9: Q4 — Relationship with Her Body Now

- **Kind:** Step — question
- **Progress bar:** ~25%
- **Question Number:** Q4 of 22

---

**Title (28px, bold):**
> How do you feel about your body right now — honestly?

**Subtitle (muted):**
> There's no wrong answer. This shapes how we frame your plan.

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **Frustrated with it** — "I feel like it's fighting me"
- 🖼️ **Making peace with it** — "I'm trying to accept the changes but struggling to dress it"
- 🖼️ **Neutral** — "I'm not at war with my body, I just need new formulas"
- 🖼️ **Disconnected from it** — "I've kind of stopped looking closely. It's easier."
- 🖼️ **Okay with it** — "I just need my wardrobe to catch up"

---

**Design notes:**
- "Disconnected from it. I've kind of stopped looking closely." — this is mirror-avoidance. Naming it is powerful.
- No answer is the wrong answer — all lead to the same outcome
- The subtitle "no wrong answer" pre-empts shame before a sensitive question

---

## SCREEN 10: Q5 — Morning Dressing Experience

- **Kind:** Step — question
- **Progress bar:** ~28%
- **Question Number:** Q5 of 22

---

**Title (28px, bold):**
> What does getting dressed feel like right now?

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **Like putting on a costume** — "None of it feels like me anymore"
- 🖼️ **Defeat** — "I try things on, they don't work, I go back to the same safe options"
- 🖼️ **Confusing** — "I don't understand why things look the way they do"
- 🖼️ **Boring** — "I've narrowed it down to things that work and I wear them forever"
- 🖼️ **Fine, but I know I could do better** — "I've settled but I don't have to"

---

**Design notes:**
- "Like putting on a costume" — profound, specific, immediately recognizable
- "Defeat" is direct and true — using the word is important because she feels it
- "Confusing" captures the disorientation that's specific to the Meno-Morpher

---

## SCREEN 11: Q6 — What She Still Loves

- **Kind:** Step — question (multi-select)
- **Progress bar:** ~32%
- **Question Number:** Q6 of 22

---

**Title (28px, bold):**
> Even now — are there pieces in your wardrobe you still love?

**Subtitle (muted):**
> Things that still make you feel like you, even if you can't explain why.

---

**Question Type:** Multi-select

**Answer Options:**
- [ ] Yes — a few specific pieces that still work somehow
- [ ] A blazer or jacket that makes me feel like myself
- [ ] Good quality basics that I love but can't seem to build outfits around
- [ ] A color or fabric I keep coming back to
- [ ] Shoes or accessories that feel like "me"
- [ ] Honestly, I'm not sure — it's been a long time since I felt something in my wardrobe

**Button:** Here's what I still have →

---

**Design notes:**
- This is a hope injection — she has pieces that still work. We're building FROM those.
- "Can't seem to build outfits around" is the formula gap — not a quality problem
- Last option validates complete disconnection without shame

---

## SCREEN 12: Q7 — Likert: The Grief of the Old Body

- **Kind:** Step — question (Likert)
- **Progress bar:** ~35%
- **Question Number:** Q7 of 22

---

**Title (28px, bold):**
> How much does this sound like you?

**Subtitle:**
> *"Sometimes I grieve my old body — not just how it looked, but how I knew how to dress it."*

---

**Question Type:** Single-choice, 5-point scale

**Answer Options:**
- Completely — this is exactly it
- Mostly yes
- Somewhat
- Not really
- Not at all

---

**Design notes:**
- "Grieve" is the right word — the Meno-Morpher IS grieving
- "Not just how it looked, but how I knew how to dress it" — this is the specific loss, not the body itself
- Most Meno-Morphers select "Completely" — this is the deepest mirror in the funnel

---

## SCREEN 13: Q8 — Likert: The Formula Failure

- **Kind:** Step — question (Likert)
- **Progress bar:** ~38%
- **Question Number:** Q8 of 22

---

**Title (28px, bold):**
> How much does this sound like you?

**Subtitle:**
> *"I'm not starting from zero with style. I had something. I'm trying to get it back — but for the body I'm in now."*

---

**Question Type:** Single-choice, 5-point scale

**Answer Options:**
- Completely — this is exactly my situation
- Mostly yes
- Somewhat
- Not really
- I am starting from zero, actually

---

**Design notes:**
- This Likert reframes the story from "I've failed" to "I'm reclaiming"
- Last option validates women who feel completely lost — they're still in the right funnel

---

## SCREEN 14: Q9 — The Avoidance Patterns

- **Kind:** Step — question (multi-select)
- **Progress bar:** ~42%
- **Question Number:** Q9 of 22

---

**Title (28px, bold):**
> Has this affected more than just your wardrobe? Pick what resonates.

---

**Question Type:** Multi-select

**Answer Options:**
- [ ] I avoid mirrors when getting dressed
- [ ] I've stopped buying clothes because nothing works anyway
- [ ] I've declined events or photos because of how I feel about what I'm wearing
- [ ] I've stopped caring, but I wish I didn't
- [ ] I feel invisible in a way that has nothing to do with my age
- [ ] I see women my age looking great and wonder why I can't figure it out
- [ ] I miss feeling like myself

**Button:** This is what it's cost me →

---

**Design notes:**
- "Invisible in a way that has nothing to do with my age" — important distinction, and accurate
- "I miss feeling like myself" — simple, devastating, true
- The cost of the problem is being named before we offer the solution

---

## SCREEN 15: Q10 — What She's Tried

- **Kind:** Step — question (multi-select)
- **Progress bar:** ~45%
- **Question Number:** Q10 of 22

---

**Title (28px, bold):**
> What have you already tried? (Pick everything you've attempted)

**Subtitle (muted):**
> This helps us avoid suggesting things that haven't worked.

---

**Question Type:** Multi-select

**Answer Options:**
- [ ] Magazine advice on "dressing for my age" (didn't help)
- [ ] "Dress for your body type" guides (too generic)
- [ ] Pinterest / Instagram inspiration (the things never look the same on me)
- [ ] Shopping trips to find new things (I come home empty-handed or with things I never wear)
- [ ] Hiring a personal stylist (too expensive or the advice didn't stick)
- [ ] Wardrobe apps (confusing or too much setup)
- [ ] Just buying basics and hoping for the best
- [ ] I haven't really tried anything — I've just been struggling

**Button:** I've tried this →

---

**Design notes:**
- This question positions every competitor as something that failed her — creating space for a different solution
- The subtitle "avoid suggesting things that haven't worked" makes her feel heard
- "Dress for my age" is a phrase she hates — see voice rules

---

## SCREEN 16: Q11 — Style Goals Now

- **Kind:** Step — question (multi-select)
- **Progress bar:** ~48%
- **Question Number:** Q11 of 22

---

**Title (28px, bold):**
> What do you want to feel when you get dressed? Pick everything.

---

**Question Type:** Multi-select

**Answer Options:**
- [ ] Like I know what I'm doing again
- [ ] Like my outside matches my inside — not a decade behind it
- [ ] Comfortable and good at the same time
- [ ] Like I have formulas I can trust
- [ ] Like I'm not invisible
- [ ] Proud of how I look, without having to try too hard
- [ ] Like getting dressed is easy again

**Button:** These are my goals →

---

**Design notes:**
- "Like my outside matches my inside — not a decade behind it" — powerful, specific to this archetype
- These become part of the results personalisation

---

## SCREEN 17: Q12 — Current Wardrobe Assessment

- **Kind:** Step — question
- **Progress bar:** ~52%
- **Question Number:** Q12 of 22

---

**Title (28px, bold):**
> How would you describe your current wardrobe — honestly?

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **Full of things that used to work and now don't** — "I keep them hoping they'll come back"
- 🖼️ **Mostly basics with nowhere to go** — "I have the pieces but they don't form outfits"
- 🖼️ **Mostly new things that didn't solve the problem** — "Shopping didn't fix it"
- 🖼️ **A safety rotation** — "5–7 things I trust and the rest gets ignored"
- 🖼️ **Actually pretty good** — "I need better formulas, not more clothes"

---

**Design notes:**
- "I keep them hoping they'll come back" — the clothes graveyard. She knows this exactly.
- "Shopping didn't fix it" — preempts the shopping solution she's already tried

---

## SCREEN 18: Q13 — The Body Now (Feeling, Not Size)

- **Kind:** Step — question
- **Progress bar:** ~55%
- **Question Number:** Q13 of 22

---

**Title (28px, bold):**
> How do you want to feel *in* clothes — not how you want to look in them?

**Subtitle (muted):**
> Identity language only. Not appearance.

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **Strong** — "I want to walk into a room and feel like myself, not like I'm hiding"
- 🖼️ **Comfortable** — "I've been uncomfortable for too long. I want to feel at home in my clothes."
- 🖼️ **Confident** — "I want to stop second-guessing everything I put on"
- 🖼️ **Put-together** — "I want to look like I have my act together"
- 🖼️ **Visible** — "I want to stop feeling like a background extra in my own life"

---

**Design notes:**
- "Identity language only" — this is her feeling, not her appearance. Keeps the copy honest to the brand.
- Each option connects to a different emotional core — all lead to formula-based solution

---

## SCREEN 19: Q14 — The Last Time She Felt It

- **Kind:** Step — question
- **Progress bar:** ~58%
- **Question Number:** Q14 of 22

---

**Title (28px, bold):**
> When did you last get dressed and think: *yes, this is right*?

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **Recently** — "It happens sometimes, just not consistently"
- 🖼️ **A year ago** — "It was the exception, not the rule"
- 🖼️ **A few years ago** — "I can picture the outfit specifically"
- 🖼️ **Before my body changed** — "That's when things stopped making sense"
- 🖼️ **I honestly can't remember** — "It's been that long"

---

**Design notes:**
- "Before my body changed" — clinical, accepting, not shameful
- "I can picture the outfit specifically" — the sensory memory that still lives in her

---

## SCREEN 20: Q15 — Referral

- **Kind:** Step — question
- **Progress bar:** ~60%
- **Question Number:** Q15 of 22

---

**Title (28px, bold):**
> How did you find this quiz?

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ Instagram or Facebook
- 🖼️ A friend shared it
- 🖼️ TikTok
- 🖼️ Pinterest
- 🖼️ Google search
- 🖼️ I don't remember

---

## SCREEN 21: Q16 — Aesthetic Compass (Post-Change)

- **Kind:** Step — question
- **Progress bar:** ~63%
- **Question Number:** Q16 of 22

---

**Title (28px, bold):**
> Forget what used to work. Thinking about the body you have right now — what kind of clothes feel most like *you*?

**Subtitle (muted):**
> If you're not sure, pick what sounds most appealing.

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **Relaxed but intentional** — "I want ease without looking like I've given up"
- 🖼️ **Structure and clean lines** — "I want things that hold their shape and look deliberate"
- 🖼️ **Soft and feminine** — "I want to feel like a woman without it being complicated"
- 🖼️ **Understated and quality** — "I want to look like I know what I'm doing with minimal effort"
- 🖼️ **Colorful and alive** — "I refuse to disappear into greige just because things changed"

---

**Design notes:**
- "I refuse to disappear into greige" — this is the Meno-Morpher who hasn't given up. She converts best.
- "Without looking like I've given up" is authentic language — she uses these exact words to herself

---

## SCREEN 22: Q17 — Commitment to Change

- **Kind:** Step — question
- **Progress bar:** ~67%
- **Question Number:** Q17 of 22

---

**Title (28px, bold):**
> If someone gave you a specific formula for your body as it is now — outfit by outfit, from what you already own — would you use it?

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **Yes, absolutely** — "That's exactly what I've been looking for"
- 🖼️ **I think so** — "I'm hopeful but I've been disappointed before"
- 🖼️ **Yes, if it was genuinely specific** — "Not generic advice. Real formulas."
- 🖼️ **Maybe** — "I want to want this"

---

**Design notes:**
- "I've been disappointed before" acknowledges her history with failed solutions without dismissing her
- "Not generic advice. Real formulas." — the distinction between this and everything else she's tried

---

## SCREEN 23: Q18 — Daily Time for Getting Dressed

- **Kind:** Step — question
- **Progress bar:** ~70%
- **Question Number:** Q18 of 22

---

**Title (28px, bold):**
> How much time are you willing to spend on getting dressed once you have the formulas?

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **5 minutes or less** — "I want it to be effortless"
- 🖼️ **5–10 minutes** — "I'll invest a little time if the result is reliable"
- 🖼️ **10–15 minutes** — "I don't mind spending time if it means getting it right"
- 🖼️ **Whatever it takes** — "I've wasted too much time on this already"

---

## SCREEN 24: Q19 — What Success Looks Like

- **Kind:** Step — question
- **Progress bar:** ~73%
- **Question Number:** Q19 of 22

---

**Title (28px, bold):**
> In 3 weeks, what would "this is working" look like for you?

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **I open my wardrobe and feel something other than dread**
- 🖼️ **I have 5+ outfits I trust completely**
- 🖼️ **I stop standing in my wardrobe for 20 minutes every morning**
- 🖼️ **I feel like myself again when I look in the mirror**
- 🖼️ **I stop avoiding photos and events because of how I feel about my clothes**

---

**Design notes:**
- "3 weeks" seeds the Results Date — when she sees "21 days" on the results screen it will feel earned
- These answers appear in the personalized recovery plan output

---

## SCREEN 25: Q20 — Prior Knowledge (Expert Framing Setup)

- **Kind:** Step — question
- **Progress bar:** ~76%
- **Question Number:** Q20 of 22

---

**Title (28px, bold):**
> Have you ever worked with a personal stylist or image consultant?

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **Yes, it helped** — "But I can't afford ongoing access"
- 🖼️ **Yes, but it didn't translate** — "The advice didn't survive contact with real life"
- 🖼️ **No — the cost put me off** — "I looked into it but $1,500+ isn't realistic"
- 🖼️ **No — I never thought I needed it before** — "Now I'm wondering if I do"

---

**Design notes:**
- All answers prime the "$1,500+ for a personal stylist vs. Outfit Formulas" comparison coming at the paywall
- "The advice didn't survive contact with real life" — this is a real objection, and naming it builds trust

---

## SCREEN 26: Q21 — Final Readiness Question

- **Kind:** Step — question
- **Progress bar:** ~80%
- **Question Number:** Q21 of 22

---

**Title (28px, bold):**
> Are you ready to stop dressing for the body you used to have?

**Subtitle (muted):**
> This isn't about accepting less. It's about starting fresh — with better formulas.

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ **Yes — I've been waiting for this** — "I just needed someone to show me it was possible"
- 🖼️ **I'm ready to try** — "I'm cautious, but I'm here"
- 🖼️ **I'm not sure yet** — "I want to see what the plan looks like first"
- 🖼️ **This feels scary** — "I've gotten so used to the problem I don't know what it looks like without it"

---

**Design notes:**
- Last option is profound — the problem has become her identity, which is devastating and true
- All answers continue to the results
- "Starting fresh — with better formulas" is the Shift moment in Mirror → Validate → Shift

---

## SCREEN 27: Q22 — Referral / Attribution

- **Kind:** Step — question
- **Progress bar:** ~83%
- **Question Number:** Q22 of 22

---

**Title (28px, bold):**
> One last thing — how did you hear about Outfit Formulas?

---

**Question Type:** Single-choice, list layout

**Answer Options (auto-advance):**
- 🖼️ Instagram or Facebook
- 🖼️ A friend recommended it
- 🖼️ TikTok
- 🖼️ Pinterest
- 🖼️ Google search
- 🖼️ I don't remember

---

## SCREEN 28: Loading / Plan Building Screen

- **Kind:** Step — interstitial (loading)
- **Progress bar:** ~88%

---

**Visual:** Clinical-style progress bar. Clean animation. Steps appearing.

**Headline (24px, bold):**
> Building your Style Recovery Plan...

**Animated steps (appear one by one):**
- ✓ Analyzing your body-change profile
- ✓ Identifying formula gaps from your quiz responses
- ✓ Matching formulas from your existing wardrobe type
- ✓ Calibrating your 21-day recovery timeline
- ✓ Generating your personalized Style Recovery Plan

**Testimonials (rotating, clinical-style voices):**

> ⭐⭐⭐⭐⭐
> *"I thought I'd just accepted that I'd never look put-together again. I was wrong. Three weeks in, I have more outfits I trust than I've had in 10 years."*
> — **Caroline M.**, 51, Bristol

> ⭐⭐⭐⭐⭐
> *"My body changed and I had no idea what to do with my wardrobe. The formula system figured out my new proportions in a way I couldn't do myself. I actually like getting dressed now."*
> — **Helen S.**, 47, Austin

> ⭐⭐⭐⭐⭐
> *"The Results Date was real. Three weeks later I had a complete formula system. I'm not invisible anymore."*
> — **Diane K.**, 53, Toronto

**Auto-advance after 5 seconds**

---

## SCREEN 29: Pre-Paywall Social Proof Stats Screen (Nerva Architecture)

- **Kind:** Step — interstitial (social proof — appears BEFORE pricing)
- **Progress bar:** ~92%

---

**Background:** Deep charcoal (#1E1E1E). White text. Pink accents.

**Eyebrow text (small caps, #FF2A6D):**
> WHAT WOMEN LIKE YOU ARE EXPERIENCING

**Headline (32px, bold, white):**
> The data from 147,000+ women who followed their formula system:

---

**Stats (large display numbers, #FF2A6D, bold):**

```
89%
reported feeling confident getting dressed
within 3 weeks of starting their formula system

23 minutes
average time saved every morning once
the formula system is calibrated

94%
said their wardrobe felt "completely different"
without buying a single new item

147,000+
women have already completed their
Style Recovery Plan
```

---

**Press logos (horizontal row, below stats, white/grey treatment):**
```
[Vogue]  [Real Simple]  [Well+Good]  [InStyle]
```

---

**Expert panel (below press logos):**

```
DEVELOPED WITH:

[Photo] Sarah Chen, CIP
        Certified Image Professional
        Body-Change Style Specialist, 12 years

[Photo] Dr. Rebecca Moore
        Body-Positivity Researcher
        Author, "Dressing After Change"

[Photo] Margot Lefevre
        Senior Image Consultant
        Former Vogue Editorial Stylist
```

---

**Button (full-width, #FF2A6D, bold):**
```
[ See My Style Recovery Plan → ]
```

---

**Design notes:**
- This screen appears BEFORE the paywall — exactly as in the Nerva architecture
- Stats do the selling; they don't ask her to buy anything yet
- Expert panel with photos and credentials creates medical-level credibility
- The button says "See My Plan" not "Start Trial" — she's still in the quiz experience

---

## SCREEN 30: Results — Style Recovery Plan (Nerva Paywall)

- **Kind:** Custom HTML paywall screen (full-screen results + offer)
- **Progress bar:** 100%
- **Paywall Architecture:** NERVA — Clinical authority + free 7-day trial + Results Date

---

**Background:** Warm cream (#FFF8F5). Clinical-clean. No urgency timers.

**Pre-headline (small caps, #FF2A6D):**
> YOUR PERSONALIZED STYLE RECOVERY PLAN IS READY

---

### RESULTS CARD

```
┌─────────────────────────────────────────────────────────┐
│                 OUTFIT FORMULAS                         │
│             Style Recovery Plan                         │
│                                                         │
│  Body-Change Profile:   [Dynamic — based on Q2 answers] │
│  Formula Stage:         Recovery                        │
│  Plan Intensity:        Calibrated                      │
│                                                         │
│  Your Closet Potential: 40–60+ hidden outfits           │
│                                                         │
│  ┌─────────────────────────────────────────────────┐   │
│  │  📅 YOUR RESULTS DATE                           │   │
│  │                                                 │   │
│  │  April 26, 2026                                 │   │
│  │                                                 │   │
│  │  By this date, your personalized formula        │   │
│  │  system will be fully calibrated for your       │   │
│  │  body as it is today.                           │   │
│  └─────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────┘
```

*(Results Date = today's date + 21 days, dynamically calculated)*

---

**Body copy below card:**

> This is your starting point.
>
> Based on your quiz responses, your formula system needs to be rebuilt for your body as it is right now — not the body it was five years ago.
>
> The process takes 21 days. Not because it's hard. Because your wardrobe needs to learn your new formulas, and so do you.
>
> 89% of women who follow their formula system report feeling confident getting dressed within 3 weeks.

---

### PLAN OPTIONS (Nerva-style — clean, clinical, no aggressive discounting)

**Section header (20px, bold):**
> Start your recovery plan:

---

**PLAN CARD — Free 7-Day Trial** *(pre-selected, #FF2A6D border)*
```
┌─────────────────────────────────────────────────────┐
│  🌟 START FREE — 7-Day Trial                        │
│                                                     │
│  $0 today                                           │
│  Then $9.99/month                                   │
│                                                     │
│  ✓ Complete formula system for your body            │
│  ✓ Daily outfit suggestions from your wardrobe      │
│  ✓ Body-change formula library                      │
│  ✓ Personalized Results Date tracking               │
│  ✓ Cancel before day 7 — never charged              │
│                                                     │
│  Recommended for your profile                       │
└─────────────────────────────────────────────────────┘
```

---

**PLAN CARD — Annual** *(pink "BEST VALUE" badge)*
```
┌─────────────────────────────────────────────────────┐
│  🏆 BEST VALUE — SAVE 58%                           │
│                                                     │
│  Annual Plan                                        │
│  $49.99/year — just $4.17/month                     │
│                                                     │
│  ✓ Everything in monthly                            │
│  ✓ Full formula history and tracking                │
│  ✓ Priority support                                 │
│  ✓ 7-day free trial included                        │
└─────────────────────────────────────────────────────┘
```

---

**CTA Button (full-width, #FF2A6D, bold, 18px):**
```
[ Start My 7-Day Free Trial → ]
```

*Sub-copy beneath button:* "No charge until April 12, 2026. Cancel anytime before then — you'll never be billed."

*(Date dynamically calculated as today + 7 days)*

---

### PRESS LOGOS (below CTA)

```
As featured in:
[Vogue]  [Real Simple]  [Well+Good]  [InStyle]
```

---

### RESULTS DATE CONFIRMATION BLOCK (clinical-style)

```
┌─────────────────────────────────────────────────────┐
│  📅 YOUR RESULTS DATE: April 26, 2026               │
│                                                     │
│  Day 1:   Your formula profile is created           │
│  Week 1:  First formulas calibrated to your closet  │
│  Week 2:  Refinements based on your daily feedback  │
│  Week 3:  Full formula system ready                 │
│                                                     │
│  89% of women reach full formula confidence        │
│  by their Results Date.                             │
└─────────────────────────────────────────────────────┘
```

---

### EXPERT ENDORSEMENT (below Results Date block)

```
"Body changes after 40 create real formula gaps that
generic advice can't address. Outfit Formulas is the
first tool I've seen that actually approaches this
the right way — specific, adaptive, and built around
the body a woman has now, not the body she used to have."

— Sarah Chen, CIP
  Certified Image Professional
  Body-Change Style Specialist
```

---

### SOCIAL PROOF (testimonials, 3)

> ⭐⭐⭐⭐⭐
> *"My body reorganized itself after menopause and nothing made sense anymore. Three weeks with this formula system and I feel like I have my wardrobe back. I'm not invisible anymore."*
> — **Linda F.**, 52, Seattle

> ⭐⭐⭐⭐⭐
> *"I'd tried everything. Stylists, apps, magazine advice. None of it accounted for the actual changes my body went through. This did. My Results Date was real."*
> — **Josephine W.**, 49, Manchester

> ⭐⭐⭐⭐⭐
> *"I was about to accept that this was just how it was now. Getting dressed in the dark, same 4 outfits, feeling frumpy even in things that should work. Three weeks later: completely different wardrobe, same clothes."*
> — **Anita R.**, 54, Melbourne

---

### MONEY-BACK GUARANTEE

```
🛡️ 30-DAY MONEY-BACK GUARANTEE

If your formula system isn't making getting dressed
easier within 30 days — we refund everything.
No questions. No hoops.

Your recovery plan is backed by real results,
not promises.
```

---

### COMPARISON BLOCK (bottom, before final CTA)

```
Personal image consultant:    $1,500–$4,000
Outfit Formulas annual plan:  $49.99/year

Same expertise. Applied to your closet.
Every day.
```

---

**Final CTA (repeated, sticky on mobile):**
```
[ Start My Free 7-Day Trial → ]
```

*"Your Results Date: April 26, 2026. Start today."*

---

**Design notes:**
- NO countdown timer — Nerva architecture sells on clinical credibility, not urgency
- The Results Date is the urgency mechanism — it's "start today or your Results Date moves"
- Expert photos and credentials are essential — this is the primary conversion element after the stats screen
- Press logos appear twice: stats screen AND paywall — reinforces authority
- The timeline breakdown (Day 1 / Week 1 / Week 2 / Week 3) mirrors a medical treatment plan
- "Frumpy even in things that should work" in the last testimonial — the #1 word in her vocabulary, used organically
- "Not invisible anymore" appears in two testimonials — this is the deepest emotional resolution

---

# SUMMARY OF FUNNEL D SCREENS

| # | Type | Description |
|---|------|-------------|
| 1 | Start (invisible) | Entry node |
| 2 | Single-choice grid | Landing / entry |
| 3 | Single-choice list | Age |
| 4 | Interstitial | Expert credibility |
| 5 | Single-choice list | Q1 — When things changed |
| 6 | Multi-select | Q2 — How her body changed |
| 7 | Multi-select | Q3 — Formulas that broke |
| 8 | Interstitial | Expert validation — calibration problem |
| 9 | Single-choice list | Q4 — Relationship with her body now |
| 10 | Single-choice list | Q5 — Morning dressing experience |
| 11 | Multi-select | Q6 — What she still loves |
| 12 | Likert (5-point) | Q7 — Grief of the old body |
| 13 | Likert (5-point) | Q8 — The formula failure |
| 14 | Multi-select | Q9 — Avoidance patterns |
| 15 | Multi-select | Q10 — What she's tried |
| 16 | Multi-select | Q11 — Style goals now |
| 17 | Single-choice list | Q12 — Current wardrobe |
| 18 | Single-choice list | Q13 — How she wants to feel |
| 19 | Single-choice list | Q14 — Last time she felt right |
| 20 | Single-choice list | Q15 — Referral |
| 21 | Single-choice list | Q16 — Aesthetic compass (post-change) |
| 22 | Single-choice list | Q17 — Commitment question |
| 23 | Single-choice list | Q18 — Daily time |
| 24 | Single-choice list | Q19 — What success looks like |
| 25 | Single-choice list | Q20 — Prior stylist experience |
| 26 | Single-choice list | Q21 — Readiness question |
| 27 | Single-choice list | Q22 — Referral / attribution |
| 28 | Interstitial | Loading / plan building |
| 29 | Interstitial (social proof) | Pre-paywall stats screen |
| 30 | Custom HTML paywall | Style Recovery Plan + Nerva paywall |

**Total: 30 screens (22 quiz + 3 interstitials + 1 loading + 1 pre-paywall stats + 1 paywall + 2 invisible nodes)**
**Questions: 22 (Q1–Q22)**

---

# KEY COPY RULES FOR FUNNEL D

1. **"Reorganized itself"** is the primary phrase — appears in Q2 answer options and interstitials
2. **"Frumpy"** appears once, organically — last testimonial on paywall, where it lands hardest
3. **Clinical language throughout** — "calibration," "formula gaps," "body-change profile" — she trusts this
4. **Never "age-appropriate"** — this phrase is the enemy. Not once.
5. **Never "slimming"** — body acceptance language only
6. **The Results Date is always calculated dynamically** — 21 days from today. Always a real date.
7. **Expert credentials appear multiple times** — pre-quiz, mid-quiz, pre-paywall, paywall
8. **The reframe repeats**: "Your formulas are outdated, not broken. You are not broken."
9. **"Invisible"** is the emotional thread — appears in Q9, Q11, Q16, Q18, and testimonials
10. **NO urgency timers** — this funnel sells on clinical authority and timeline, not scarcity

---

# VOICE COMPARISON: FUNNEL C vs. FUNNEL D

| Element | Funnel C (Mom Ghost) | Funnel D (Meno-Morpher) |
|---------|---------------------|------------------------|
| Core pain | Identity loss / invisibility | Formula failure / body mismatch |
| Emotional register | Permission-seeking, guilt | Disoriented, grieving, determined |
| Framing | "She's still there" | "Calibration problem, not you" |
| Primary word | Invisible | Reorganized / Frumpy |
| Paywall mechanic | Trust badges + gift | Clinical authority + Results Date |
| Urgency type | None (authority sells) | Results Date (implicit) |
| Expert role | Secondary | Primary |
| Testimonial voice | "I feel like myself again" | "My Results Date was real" |

---

*End of funnel documentation. Funnel C: 27 screens, 18 questions. Funnel D: 30 screens, 22 questions.*
*Brand: #FF2A6D · Warm cream (#FFF8F5) · Inter font · Mobile-first.*
