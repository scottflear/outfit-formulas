# Outfit Formulas — Quiz Funnels E & F
## Complete Screen-by-Screen Specifications

---

# FUNNEL E: "Find Your Formula"
## Outfit Formula Match for the Style Relic
**Target Archetype:** The Style Relic — "I used to have amazing style. Lost it somewhere."
**Architecture:** Hypnozio — NO Free Trial. 3 duration plans, slashed prices, conditional guarantee.
**Quiz Length:** 28 screens
**Paywall:** Screen 28 (Hypnozio model)
**Brand:** #FF2A6D pink, #FFF8F5 cream, Inter font

---

# WHY THIS FUNNEL WORKS FOR THE STYLE RELIC

## The Core Insight

The Style Relic doesn't have a style problem. She has a grief problem.

She isn't confused about what good style looks like — she HAD it. She wore it. People noticed. Getting dressed used to be one of the good parts of her day. And then something happened. Life. Kids. A job that swallowed her. A relationship that ended. A body that changed. And now she stands in front of a closet full of things she barely recognises, reaching for the same leggings because that's just easier.

The grief is real. The loss is real. And she carries quiet shame about it — because she KNOWS what she used to have. This isn't someone who was never stylish. This is someone who WAS stylish, and somewhere in the shuffle of her actual life, style became a luxury she stopped allowing herself.

The job of this funnel is not to teach her about fashion. It's to give her permission to come back.

---

## Stage-by-Stage Psychology Breakdown

### Stage 1 — The Identity Excavation
**What it does:** Reminds her of who she was. Gets her to locate the exact moment she stopped being that person.

**Why it works for the Style Relic specifically:**

She remembers. That's the whole thing. She hasn't forgotten what it felt like to get dressed and feel put-together. She remembers specific outfits. She remembers the compliment someone gave her at a dinner party. She remembers when she stopped receiving those compliments.

Asking her to locate that version of herself — to articulate when she last felt stylish — isn't painful. It's validating. Someone is finally asking. Someone cares that she used to be this person. The questions don't make her feel like she failed. They make her feel seen.

The zero-friction principle: age → what used to describe her style → when she last received a compliment. By the time the harder questions arrive ("what stopped you"), she's already in the habit of being honest.

---

### Stage 2 — The Wardrobe Archaeology
**What it does:** Forces her to look at what she's kept and why. Surfaces the buried identity in her actual closet.

**Why it works for the Style Relic specifically:**

She still owns them. That's the tell. That blouse she bought in 2018 that she never wears but can't throw out. The jeans that fit her when she felt most like herself. The blazer she bought for a job she eventually loved.

These clothes are not clothes. They're artifacts. They're evidence that the person she misses actually existed.

When the quiz asks "do you still own clothes from when you felt most like yourself?", the answer is almost always yes. And then — "what's stopping you from wearing them?" — is the most important question in the entire funnel. Because the answer reveals her actual block. It's not that she doesn't have clothes. It's that she doesn't believe she gets to be that person anymore.

---

### Stage 3 — The Cost of Going Invisible
**What it does:** Converts abstract wistfulness into a concrete, real-world problem with real daily costs.

**Why it works for the Style Relic specifically:**

She's been tolerating the dull ache for years. It's background noise. The funnel's job is to make that background noise loud enough that she has to deal with it.

"120+ hours per year standing in front of a closet, feeling like you're not quite right." That's real time. Fifteen days a year. She's spending fifteen days a year feeling bad about herself before 8am.

The multi-select frustration screen gives language to feelings she's been vague about: "I wear the same 5 things on rotation," "I avoid events because I don't know what to wear," "I look at photos and feel disappointed." These aren't vanity complaints. These are identity complaints. By the time this stage ends, the problem has a price tag.

---

### Stage 4 — The Reframe: It's Not Gone. It's Buried.
**What it does:** Flips the story from "I lost my style" to "my style is still here, just buried."

**Why it works for the Style Relic specifically:**

This is the emotional pivot that makes the funnel convert. She's been telling herself a story: *I used to be stylish but I'm not anymore.* That story implies permanent loss. That something was taken and won't come back.

The reframe is surgical: Your style isn't gone. It's buried under leggings and life. The formulas you used to use — pairing the blazer with the right thing, knowing which shoes tied it together — those are learnable again. You didn't forget how to ride a bike. You just haven't been on one.

Critically: this is NOT about buying new clothes. This is about rediscovering the formulas that used to work and applying them to what she already owns. That's the OF promise. It's not "become someone new." It's "find the person who's been there all along."

---

### Stage 5 — The Formula Match
**What it does:** Makes the solution feel personal, specific, and immediately actionable.

**Why it works for the Style Relic specifically:**

She's been drowning in general fashion advice for years. Colour theory. Body type rules. Capsule wardrobe lists. None of it sticks because none of it is for HER.

The "Formula Match" result gives her a specific match — not a category ("you're a Classic") but an actual formula set. The DNA of how she used to dress, reconstructed from her quiz answers. Seeing herself reflected back specifically — the colours she gravitates to, the pieces she already reaches for — creates the conviction that this worked because it's real.

The No Trial commitment is the closing mechanism. She's not being asked to try it. She's being asked to come back. This isn't low-stakes testing — it's a decision about her comeback. That framing is for someone who doesn't need convincing. She's already convinced. She just needs the right container.

---

## The Central Conversion Mechanism

This quiz never sells a subscription. It sells a homecoming.

By the time results appear, she has:
1. Located the version of herself she's been missing (Stage 1)
2. Realized the evidence of that self is still hanging in her closet (Stage 2)
3. Named the real cost of tolerating the gray area every morning (Stage 3)
4. Heard the reframe that changes everything: it's not gone, it's buried (Stage 4)
5. Seen her own style DNA reflected back as a specific formula (Stage 5)

The app is just the tool that executes the comeback she's already decided to make.

---

# THE COMPLETE 28-SCREEN FUNNEL

---

## SCREEN 1: Start (Entry Node)
- **Kind:** Start — invisible entry node
- **Notes:** Automatically transitions to Screen 2. No visible content. Platform handles routing.

---

## SCREEN 2: Landing / Entry

- **Kind:** Step — Landing page, no question
- **Progress bar:** None

---

**VISUAL ELEMENTS:**

- **Top badge (pill, #FF2A6D border, pink text):**
  > STYLE FORMULA QUIZ

- **Headline (36–40px, bold, #1E1E1E):**
  > **You used to know exactly what to wear.**
  > **Let's find that again.**

- **Subheadline (18px, #6B6B6B):**
  > Answer 5 minutes of honest questions and we'll match you with the outfit formulas that reconnect you with your style DNA — using clothes you already own.

- **Social proof badge:**
  > ⭐⭐⭐⭐⭐ Taken by 147,000+ women

- **CTA Button (full-width, #FF2A6D, white text, bold, 12px radius):**
  > Find My Formula →

- **Trust line (small, #6B6B6B):**
  > Free · 5 minutes · No shopping required

---

**Design notes:**
- Background: soft cream (#FFF8F5)
- The headline uses past tense intentionally — "you used to know" triggers the nostalgia loop immediately
- No mention of Outfit Formulas as a brand yet. This is "your quiz."
- The phrase "style DNA" signals this will be personalized, not generic

---

## SCREEN 3: Age

- **Kind:** Step
- **Progress bar:** ~4%

---

**Title (28px, bold):**
> How old are you?

**Subtitle (16px, #6B6B6B):**
> Style formulas shift with your life stage. We match to where you are right now.

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- Under 30
- 30–39
- 40–49
- 50–59
- 60+

---

**Design notes:**
- The subtitle does real work: "where you are right now" signals we're not going to tell her she should dress like she's 28 again. That's reassuring.

---

## SCREEN 4: Style History

- **Kind:** Step
- **Progress bar:** ~8%

---

**Title (28px, bold):**
> Which of these sounds most like you?

**Subtitle (16px, #6B6B6B):**
> Be honest — we're not judging.

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- I used to dress well. People noticed. I miss that version of me.
- I've always found style kind of confusing, honestly.
- I dress fine, but something feels off lately.
- I go through phases — sometimes I feel great, sometimes invisible.

---

**Design notes:**
- Option 1 is written to be immediately recognizable to the Style Relic. Clicking it is a relief, not a confession.
- All paths are valid — no shaming of any answer

---

## SCREEN 5: The Peak Era

- **Kind:** Step
- **Progress bar:** ~12%

---

**Title (28px, bold):**
> When did you feel most like yourself, style-wise?

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- In my 20s — I just knew what worked
- In my 30s — I had it figured out
- A specific season of my life (a job, a relationship, a city)
- I'm honestly not sure I've ever felt fully like myself
- I feel like myself now, most days

---

**Design notes:**
- This question is pure excavation. It asks her to locate the peak — which activates nostalgia without forcing it
- The "specific season" option is important: many Style Relics tie their peak to a life context, not an age

---

## SCREEN 6: The Compliment Question

- **Kind:** Step
- **Progress bar:** ~16%

---

**Title (28px, bold):**
> When was the last time someone complimented your outfit?

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- Recently — within the last month
- A while ago — maybe a few months
- It's been over a year
- Honestly, I can't remember
- People compliment my outfits pretty regularly

---

**Design notes:**
- This is the needle. The Style Relic almost always answers "it's been over a year" or "I can't remember"
- Clicking that option creates a pang — not shame, but recognition. "Yeah. It has been a while."
- The question doesn't say "you never get compliments." It asks. She fills in the answer herself.

---

## SCREEN 7: The Wardrobe Question

- **Kind:** Step
- **Progress bar:** ~20%

---

**Title (28px, bold):**
> Do you still own clothes from when you felt most like yourself?

**Subtitle (16px, #6B6B6B):**
> The dress you haven't worn in two years but can't throw away. The blazer from that job you loved.

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- Yes — I have a whole section of my closet I never touch
- A few pieces I keep for "someday"
- I've donated most of it — a clean slate
- Not really, my style has shifted

---

**Design notes:**
- The subtitle does the work — it gives her specific images to recognize herself in
- "A whole section I never touch" is the most common response from Style Relics — her "museum" closet
- This question plants the seed: the clothes are still there. The formula to wear them is findable.

---

## SCREEN 8: The Stopping Question

- **Kind:** Step
- **Progress bar:** ~24%

---

**Title (28px, bold):**
> What's stopping you from wearing those clothes now?

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- My body has changed and I'm not sure they'll fit the same
- They feel too "fancy" for my everyday life now
- I don't know what to pair them with anymore
- I'm saving them for when I feel ready
- Nothing — I do wear them

---

**Design notes:**
- Every option here is a real block. No wrong answer.
- "Saving them for when I feel ready" is the Style Relic's deepest trap — it names what she's actually doing
- "I don't know what to pair them with anymore" is the OF solution in plain English — this is EXACTLY what Outfit Formulas solves

---

## SCREEN 9: Social Proof Interstitial

- **Kind:** Interstitial — info screen (no question)
- **Progress bar:** ~28%

---

**Background:** Warm cream (#FFF8F5)
**Card (white, soft shadow, 16px radius):**

**Stat (bold, #FF2A6D, 32px):**
> 73%

**Copy (18px, #1E1E1E):**
> of women say they have "nothing to wear" — even with a full closet.

**Divider**

**Smaller copy (16px, #6B6B6B):**
> But the real number is this: the average woman wears only **20% of what she owns**.
>
> Which means 80% of your closet — including the pieces you love but "can't figure out" — is sitting there waiting.

**CTA Button:**
> Keep Going →

---

**Design notes:**
- This interstitial comes after the wardrobe questions to land the stat at maximum impact
- She just told us she has clothes she's not wearing. Now she learns that's extremely common — and fixable.

---

## SCREEN 10: Current Morning Routine

- **Kind:** Step
- **Progress bar:** ~32%

---

**Title (28px, bold):**
> Describe your getting-dressed routine right now.

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- I try on 3–5 things and go back to the same default
- I already know what I'm wearing — the same rotation
- I spend a lot of time and still feel wrong
- I genuinely don't think about it anymore, I just grab something
- I actually enjoy getting dressed most days

---

**Design notes:**
- "The same rotation" is the Style Relic's current prison — this names it
- "I just grab something" signals she's stopped trying — that's a deeper form of giving up

---

## SCREEN 11: How She Used to Get Dressed

- **Kind:** Step
- **Progress bar:** ~36%

---

**Title (28px, bold):**
> How did you get dressed back when you felt most like yourself?

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- I had a feel for it — it just came together
- I had certain combinations I knew worked and built from there
- I shopped intentionally and knew exactly what I was adding
- I had a signature look and owned it
- Honestly, it was a bit chaotic even then

---

**Design notes:**
- This question surfaces her old formula without using the word "formula"
- "Certain combinations I knew worked" = outfit formulas in her own words
- The question activates positive memory — a counterweight to the grief

---

## SCREEN 12: The Agreement Barrage (Likert 1)

- **Kind:** Step — Likert 5-point scale
- **Progress bar:** ~39%

---

**Title (24px, bold):**
> "I sometimes avoid plans because I don't feel good about how I'll look."

**Scale:** Strongly Disagree / Disagree / Neutral / Agree / Strongly Agree

**Design notes:**
- Written as a first-person statement the user rates — feels diagnostic, not accusatory
- This is the avoidance behaviour that costs her real life: events skipped, connections missed

---

## SCREEN 13: The Agreement Barrage (Likert 2)

- **Kind:** Step — Likert 5-point scale
- **Progress bar:** ~42%

---

**Title (24px, bold):**
> "I look at old photos and feel like a stranger compared to how I look now."

**Scale:** Strongly Disagree / Disagree / Neutral / Agree / Strongly Agree

**Design notes:**
- Old photos are the Style Relic's recurring moment of grief — she sees evidence of who she was
- "A stranger" is the identity loss language. This is not about weight. It's about feeling unrecognizable to herself.

---

## SCREEN 14: The Agreement Barrage (Likert 3)

- **Kind:** Step — Likert 5-point scale
- **Progress bar:** ~45%

---

**Title (24px, bold):**
> "I keep buying things that never quite work, then wearing the same 5 things anyway."

**Scale:** Strongly Disagree / Disagree / Neutral / Agree / Strongly Agree

**Design notes:**
- The shopping cycle of hope-and-disappointment. She buys things optimistically and they join the unused section.
- "Wearing the same 5 things anyway" is the punchline every Style Relic recognizes immediately

---

## SCREEN 15: The Agreement Barrage (Likert 4)

- **Kind:** Step — Likert 5-point scale
- **Progress bar:** ~48%

---

**Title (24px, bold):**
> "Getting dressed used to feel good. Now it mostly feels like a chore I just want to be done with."

**Scale:** Strongly Disagree / Disagree / Neutral / Agree / Strongly Agree

**Design notes:**
- The past/present contrast is the emotional center of this funnel. "Used to feel good." Now it's a chore.
- Agreeing with this statement = explicitly naming the loss. That makes the solution feel more urgent.

---

## SCREEN 16: Multi-Select Frustrations

- **Kind:** Step — multi-select
- **Progress bar:** ~51%

---

**Title (24px, bold):**
> What does a hard morning in front of the closet actually look like for you?

**Subtitle (16px, #6B6B6B):**
> Select everything that fits.

---

**Question Type:** Multi-select, list with checkboxes, "Continue" button

**Answer Options:**
- I try on things and they don't look the way I imagined
- I end up feeling frumpy no matter what I pick
- I reach for the leggings because they're the path of least resistance
- I'm late because I couldn't commit to an outfit
- I feel worse after getting dressed than before I started
- I avoid mirrors when I'm getting dressed
- I think about it for a while, then give up and wear whatever
- I end up wearing the same outfit I wore two days ago

---

**Design notes:**
- "Frumpy" is her word — it's specific and real and doesn't require translation
- "Path of least resistance" captures the resignation without judgment
- Multi-select creates a cumulative effect: every box she checks adds weight to the problem

---

## SCREEN 17: Event Avoidance

- **Kind:** Step
- **Progress bar:** ~54%

---

**Title (28px, bold):**
> Have you ever made an excuse not to go somewhere because you didn't feel good about what you'd wear?

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- Yes — more than once
- Once or twice
- I've considered it but went anyway
- No, I just wear something and deal
- Not recently, but I used to

---

**Design notes:**
- This surfaces the real cost: her life is being contracted by her getting-dressed problem
- Events avoided = connections not made, memories not created. This isn't about clothes. It's about her life.

---

## SCREEN 18: The Shopping Cycle

- **Kind:** Step
- **Progress bar:** ~57%

---

**Title (28px, bold):**
> When you buy something new, what usually happens?

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- I wear it once or twice, then it joins the pile of things I never reach for
- I get excited, but can never figure out what to wear it with
- I love it in the store, then hate it the second I'm home
- I buy things that are "safe" and feel boring in them
- I don't really shop much anymore

---

**Design notes:**
- The shopping cycle of hope and disappointment. Each option is a version of the same story.
- "I don't really shop much anymore" = she's given up on shopping as a solution. Which is actually correct — the solution isn't more shopping.

---

## SCREEN 19: Reframe Interstitial — The Buried Identity

- **Kind:** Interstitial — info screen (no question)
- **Progress bar:** ~60%

---

**Background:** #FF2A6D (vibrant pink)
**Text:** White

**Headline (28px, bold, white):**
> Your style isn't gone.
> It's buried under leggings and life.

**Body copy (18px, white, slightly transparent):**
> You haven't lost the ability to get dressed well. You've lost the formulas.
>
> The combinations that used to just work. The pieces you used to know how to build around. The instinct for what goes with what.
>
> That's not some magical gift you had and lost. It's a skill. And skills come back.

**CTA Button (white background, #FF2A6D text):**
> Show Me My Formula →

---

**Design notes:**
- This is the emotional pivot. Everything before was pain. This is the reframe.
- Pink background marks the moment — this looks and feels different from the rest of the quiz
- No product mention yet. This is still about HER, not about selling anything.

---

## SCREEN 20: What She Wants Back

- **Kind:** Step
- **Progress bar:** ~63%

---

**Title (28px, bold):**
> What would "getting dressed well again" actually look like for you?

**Subtitle (16px, #6B6B6B):**
> Not how you'd look. How you'd feel.

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- Walking out the door and feeling like myself again
- Not dreading the closet first thing in the morning
- Getting compliments without it being a surprise
- Knowing I look put-together without spending an hour on it
- Feeling excited about getting dressed again — like I used to

---

**Design notes:**
- "How you'd feel" — the subtitle explicitly shifts from appearance to identity
- Every option is identity language: "like myself," "put-together," "excited"
- "Like I used to" is the Style Relic's specific version of hope

---

## SCREEN 21: Style Vocabulary

- **Kind:** Step
- **Progress bar:** ~66%

---

**Title (28px, bold):**
> How would you describe the style you used to have — or wish you had now?

**Subtitle (16px, #6B6B6B):**
> Not fancy terms. Just what comes to mind.

---

**Question Type:** Multi-select, up to 3 options, "Continue" button

**Answer Options:**
- Clean and simple — things that just work together
- Feminine but not fussy
- Relaxed but intentional — casual that actually looks good
- Classic — things that aren't trendy but are always right
- A bit bold — I liked a statement piece
- Comfortable but not frumpy (yes, there's a difference)
- Pulled-together — like I had my life sorted

---

**Design notes:**
- "Not fancy terms" signals this is a no-judgment, real-person vocabulary exercise
- "Comfortable but not frumpy (yes, there's a difference)" — the parenthetical is a small knowing joke she'll appreciate
- The selections feed directly into the Formula Match result

---

## SCREEN 22: Colour Relationship

- **Kind:** Step
- **Progress bar:** ~69%

---

**Title (28px, bold):**
> When it comes to colour, which of these is you?

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- I live in neutrals — black, white, grey, navy
- I love colour but I can never make it work
- I have a couple of colours that always feel like "me"
- I used to wear colour more. Now I play it safe.
- I gravitate toward warm tones — rust, camel, olive

---

**Design notes:**
- Colour is a key formula input — this data shapes the result
- "I used to wear colour more. Now I play it safe." — the Style Relic's colour relationship has often shifted with her confidence

---

## SCREEN 23: Life Context

- **Kind:** Step
- **Progress bar:** ~72%

---

**Title (28px, bold):**
> What does most of your day actually look like?

**Subtitle (16px, #6B6B6B):**
> Be realistic — not aspirational.

---

**Question Type:** Multi-select, "Continue" button

**Answer Options:**
- Working from home most days
- In an office or workplace
- Running errands, kids, appointments — always on the go
- A mix of everything — no two days look the same
- Mostly at home right now
- Lots of social events, dinners, occasions

---

**Design notes:**
- "Realistic, not aspirational" — she won't be given formulas for a life she doesn't have
- OF works with HER actual life context, not a fantasy version

---

## SCREEN 24: The Goal — How Long

- **Kind:** Step
- **Progress bar:** ~75%

---

**Title (28px, bold):**
> How long have you felt like you've lost your style?

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- About a year
- Two to three years
- Five years or more
- I honestly couldn't pinpoint when it happened
- It comes and goes — some stretches are better than others

---

**Design notes:**
- Duration matters for the Formula Match framing — "you've been waiting 5 years. Let's make this the year."
- "I couldn't pinpoint when it happened" is extremely common — the slide into invisibility is usually gradual

---

## SCREEN 25: Email Capture

- **Kind:** Step — email input
- **Progress bar:** ~82%

---

**Title (28px, bold):**
> Where should we send your Formula Match?

**Subtitle (16px, #6B6B6B):**
> We're building your results now. Enter your email and we'll send your full Formula Match — including which outfit formulas match your style DNA.

---

**Input field:**
> Your email address

**CTA Button:**
> Show My Formula Match →

**Trust line (small, #6B6B6B):**
> No spam. Unsubscribe anytime. We never sell your data.

---

## SCREEN 26: Name Capture

- **Kind:** Step — text input
- **Progress bar:** ~86%

---

**Title (28px, bold):**
> One more thing — what's your name?

**Subtitle (16px, #6B6B6B):**
> Your Formula Match is personalised. We'd like to address it to you.

---

**Input field:**
> First name

**CTA Button:**
> See My Results →

---

## SCREEN 27: Loading / Results Build Screen

- **Kind:** Interstitial — animated loading screen
- **Progress bar:** ~92%

---

**Background:** Warm cream (#FFF8F5)

**Headline (24px, bold, #1E1E1E):**
> Building your Formula Match, {{firstName}}...

**Animated progress bar (pink, #FF2A6D):**
> [███████████░░] 78%

**Rotating copy beneath bar (one line at a time, fades in/out):**
> "Analysing your style history..."
> "Matching your wardrobe to formula types..."
> "Identifying your signature combinations..."
> "Finding the outfits already hiding in your closet..."

**Social proof strip (scrolls below loading bar):**
> ⭐⭐⭐⭐⭐ *"I cried a little when I saw my results. They described exactly the person I'd been missing."* — Renée M., 47
>
> ⭐⭐⭐⭐⭐ *"It felt like someone had gone through my closet with me. I wore something I'd owned for three years and got compliments."* — Diane K., 52
>
> ⭐⭐⭐⭐⭐ *"I used to know how to dress. Outfit Formulas helped me remember."* — Patricia W., 44

---

**Design notes:**
- Loading screen is never boring — it shows her the quiz is "doing work" on her behalf
- Testimonials are written in Style Relic voice: real emotion, specific details, past-tense recognition
- "Cried a little" — permission to feel something real about this

---

## SCREEN 28: PAYWALL — HYPNOZIO MODEL
### No Trial. 3 Duration Plans. Conditional Guarantee.

- **Kind:** Custom HTML paywall screen (full-screen, cream background #FFF8F5 with pink accents)
- **Paywall Architecture:** HYPNOZIO — No free trial. Three duration-based plans with 50% slashed prices. Conditional guarantee. Middle option pre-selected.
- **Checkout URL:** `https://app.outfitformulas.com/checkout/find-your-formula`

---

### RESULTS HEADER (above paywall, same page)

**Pre-headline (small caps, #FF2A6D, 14px):**
> YOUR FORMULA MATCH IS READY, {{firstName}}

**Main Headline (36px, bold, #1E1E1E):**
> **Your Style DNA is intact.**
> **Here's how to wear it again.**

**Sub-headline (18px, #6B6B6B):**
> Based on your answers, we've matched you with the outfit formulas that align with how you used to dress — and how you want to dress now. These aren't generic suggestions. They're built from your style history.

---

### FORMULA MATCH REVEAL (results card)

**Card (white background, #FF2A6D left border accent, soft shadow):**

**Formula Type Label (bold, #FF2A6D, 20px):**
> Your Formula Type: **The Grounded Classic**

**Description (16px, #1E1E1E):**
> You build outfits from a reliable foundation — clean lines, pieces that work across contexts. Your instinct was always to reach for something that felt considered without being fussy. You haven't lost that instinct. You've just been dressing around it instead of from it.

**Your Formula Stack:**
> ✓ The Foundation Layer Formula — how to anchor any outfit
> ✓ The Piece De Résistance Rule — the one piece that makes the rest work
> ✓ The Transition Formula — the same outfit, three different contexts
> ✓ The Colour Anchor Formula — your 3 colours that tie everything together

**Unlock note (small, italic, #6B6B6B):**
> *These formulas are built into the app. Each one is tailored to your answers.*

---

### PAYWALL SECTION HEADER

**Divider line**

**Section headline (28px, bold, #1E1E1E, center-aligned):**
> Your style comeback starts here.

**Sub-headline (16px, #6B6B6B, center-aligned):**
> Choose a plan. No trial period — because you don't need to be convinced. You already know what you're missing.

---

### PLAN SELECTOR (3 interactive cards)

**Section label:** "Choose your plan:"

---

**PLAN CARD 1 — 2-Month Plan** *(unselected)*

```
┌──────────────────────────────────────────────────┐
│  2 Months                                         │
│                                                   │
│  ~~$15.99/mo~~  →  $7.99/month                   │
│  Billed as $15.98 total                           │
│                                                   │
│  Best for: Trying the full formula system         │
└──────────────────────────────────────────────────┘
```

---

**PLAN CARD 2 — 6-Month Plan** *(PRE-SELECTED, pink border glow, badge)*

```
┌──────────────────────────────────────────────────┐
│  ⭐ MOST POPULAR                                  │
│                                                   │
│  6 Months                                         │
│                                                   │
│  ~~$9.99/mo~~  →  $4.99/month                    │
│  Billed as $29.94 total                           │
│                                                   │
│  Best for: Building your full formula wardrobe    │
│  ← Recommended based on your quiz answers        │
└──────────────────────────────────────────────────┘
```

---

**PLAN CARD 3 — 4-Month Plan** *(unselected)*

```
┌──────────────────────────────────────────────────┐
│  4 Months                                         │
│                                                   │
│  ~~$11.99/mo~~  →  $5.99/month                   │
│  Billed as $23.96 total                           │
│                                                   │
│  Best for: A full seasonal wardrobe reset         │
└──────────────────────────────────────────────────┘
```

---

### PRIMARY CTA BUTTON (large, full-width, #FF2A6D, white bold text)

```
[ Start My Style Comeback → ]
```

*Sub-copy beneath button:* "Secure checkout. Cancel anytime. Your formula match unlocks immediately."

---

### "ALL PLANS INCLUDE" FEATURE LIST

**Section header (bold, 20px, #1E1E1E):**
> Every plan includes:

**Feature list (icon + text, left-aligned):**
- ✓ Daily outfit suggestions from your actual wardrobe
- ✓ Your full Formula Match library (30+ formulas)
- ✓ Closet audit tool — find the outfits you've been walking past
- ✓ "What goes with what" formula guides
- ✓ New formula drops every week
- ✓ Style comeback tracker — see your progress
- ✓ Access on all devices

---

### CONDITIONAL GUARANTEE BLOCK

**Card (cream background, #FF2A6D border, center-aligned):**

```
🛡️ THE COMEBACK GUARANTEE

Try 6 or more outfit formulas in your first 30 days.
If you've done that — actually used the formulas, not just
browsed them — and you still feel stuck, you get 100% back.

No arguing. No hoops. We back this because we know the
formulas work when you use them.

The guarantee is conditional because it requires one thing:
that you show up for your own comeback.
```

**Design notes:**
- The conditional nature is framed as empowering, not restrictive
- "Show up for your own comeback" — identity language, not product language
- This isn't a typical money-back guarantee. It's a challenge.

---

### SOCIAL PROOF — STYLE RELIC VOICES

**Three testimonials (stacked cards), each in Style Relic voice:**

> ⭐⭐⭐⭐⭐
> *"I hadn't felt like myself in probably six years. I thought I'd just aged out of caring. But it wasn't that. I just didn't know how to wear what I already owned. Week two with Outfit Formulas and I wore a blouse I'd had for four years for the first time. My sister asked if it was new."*
> — **Carol J.**, 51, London

> ⭐⭐⭐⭐⭐
> *"I used to be known for having good style. I lost it somewhere in my late 40s and kind of accepted it. The quiz identified my style DNA better than I would have myself. I've gotten more compliments in the last month than I have in years."*
> — **Miriam A.**, 53, Manchester

> ⭐⭐⭐⭐⭐
> *"I was saving my 'good clothes' for when I felt ready. I've been waiting four years. These formulas taught me what I was missing — it wasn't confidence, it was just not knowing what to pair with what. Now I wear things I love. Every day."*
> — **Sarah L.**, 48, Edinburgh

---

### TRUST FOOTER

**Payment logos + security:**
> 🔒 SSL Encrypted Checkout

**Small legal copy (#6B6B6B, 12px):**
> Plans auto-renew at the listed rate. Cancel any time from your account settings. Guarantee applies to accounts with 6+ formula logs in 30 days.

---

**Design notes for Screen 28:**
- No countdown timer — this is NOT Hypnozio's fake urgency play. The no-trial commitment IS the urgency mechanic.
- The guarantee is the conversion engine: conditional = she has to do something to earn the refund = she has to actually engage = the engagement makes her not need the refund
- Pre-selected middle plan (6-month, $4.99/mo) is the decoy mechanic: 2-month feels short, 4-month feels almost-as-good, 6-month feels committed and smart
- "Start My Style Comeback" — the CTA language is identity-led, not feature-led
- Background stays cream, not dark — this funnel is warm and emotional, not high-pressure
- No sticky timer. The Style Relic doesn't respond to FOMO. She responds to recognition.

---

# SUMMARY OF SCREEN TYPES — FUNNEL E

| Type | Count | Screens |
|------|-------|---------|
| Single-choice list | 10 | 3, 4, 5, 6, 7, 8, 10, 11, 17, 24 |
| Single-choice grid (Likert 5-point) | 4 | 12, 13, 14, 15 |
| Multi-select list | 3 | 16, 21, 23 |
| Text input (Email) | 1 | 25 |
| Text input (Name) | 1 | 26 |
| Interstitials (no question) | 3 | 9, 19, 27 |
| Landing screen | 1 | 2 |
| Paywall (custom HTML) | 1 | 28 |
| Start node | 1 | 1 |

**Total: 28 screens** ✅

---

# KEY THEMES ASSESSED — FUNNEL E

1. **Demographics** — Screen 3
2. **Style History / Identity** (Style self-label, peak era, compliment recency) — Screens 4, 5, 6
3. **Wardrobe Archaeology** (Kept clothes, what's stopping her) — Screens 7, 8
4. **Current State** (Morning routine, shopping cycle) — Screens 10, 18
5. **Old Formula Recall** (How she used to dress) — Screen 11
6. **Self-Diagnosis Confirmation** (4 Likert statements) — Screens 12–15
7. **Concrete Pain** (Frustrations multi-select, event avoidance) — Screens 16, 17
8. **Future Vision** (What she wants back) — Screen 20
9. **Style DNA Data** (Vocabulary, colour, life context) — Screens 21, 22, 23
10. **Duration of Loss** — Screen 24

---

# COPY RULES — FUNNEL E

1. **Never say "revamp"** — say "remember" or "reconnect with"
2. **Never say "transform your wardrobe"** — she doesn't want a transformation. She wants herself back.
3. **Past-tense language is power here** — "you used to," "you had it," "you knew"
4. **Never imply she was wrong to stop trying** — she had real reasons. Validate them.
5. **Specific over generic** — "the blazer from the job you loved" not "your favourite items"
6. **Identity language throughout** — "feel like yourself," not "look your best"
7. **"Comeback" is the frame** — this is her return, not her makeover
8. **No countdown timer on paywall** — the commitment mechanic is the sell, not the clock

---

---
---

# FUNNEL F: "Your Personal Closet Makeover"
## Closet Makeover Score for the Closet Paralytic + Scroll Comparer
**Target Archetypes:** The Closet Paralytic ("full closet, nothing to wear") + The Scroll Comparer ("847 Pinterest pins, nothing works")
**Architecture:** Sofa Yoga — Countdown Timer + Personalized Promo Code + Free Bonus Stack (TRIPLE URGENCY)
**Quiz Length:** 30 screens
**Paywall:** Screen 30 (Sofa Yoga model)
**Brand:** #FF2A6D pink, #FFF8F5 cream, Inter font

---

# WHY THIS FUNNEL WORKS FOR THE CLOSET PARALYTIC + SCROLL COMPARER

## The Core Insight

She has too much — and none of it works.

The Closet Paralytic has a full closet and a completely empty sense of her own style. She buys things hopefully and then they join a pile of "I'll figure out what to wear it with eventually." She's not disorganised. She's formula-less. Without a formula, clothes are just individual items that don't speak to each other. Every morning becomes an audition that nobody passes.

The Scroll Comparer has a different symptom of the same disease. She's done her research. She's consumed more style content than most fashion editors. She can describe exactly what she likes. She just can't make it happen on her own body, in her own life, with her own clothes. The inspiration-reality gap is the cruelest thing Pinterest ever invented: here is a beautiful outfit that someone is wearing beautifully, and here is you, unable to replicate it, wondering what's wrong with you.

Nothing is wrong with her. She doesn't need more content. She needs formulas.

The Sofa Yoga paywall works for this audience because they respond to value stacking. These are women who shop smart, who love a deal, who would rather know they got the best option than pay full price for anything. The personalized promo code makes this feel like HER deal. The bonus stack makes the math irrational not to act.

---

## Stage-by-Stage Psychology Breakdown

### Stage 1 — The Closet Inventory
**What it does:** Maps the specific shape of her closet problem. Gets her to self-diagnose whether she's a Paralytic, a Comparer, or both.

**Why it works for this blend specifically:**

Both archetypes share a common shame: they feel like they should have this figured out by now. The Closet Paralytic has tried. The Scroll Comparer has really, really tried. Neither one wants to admit that the closet is a problem — it feels like a failure of imagination or discipline.

Asking her about her closet in concrete terms (how often she actually wears things, how her mornings go, whether she shops more than she wears) normalises the problem before asking her to feel bad about it. She's not broken. Her closet just doesn't have a formula system.

---

### Stage 2 — The Scroll Habit Excavation
**What it does:** Gets the Scroll Comparer to quantify how much time and hope she's invested in content that hasn't worked.

**Why it works for this blend specifically:**

Pinterest and Instagram have made her feel inadequate in a very specific way. She's seen beautiful outfits. She's saved them. She's tried to recreate them. And something is always off — the proportions, the context, the way it photographs vs. how it looks in a real mirror. The quiz asks about this honestly, and she feels seen for the first time.

The reframe is critical: the problem isn't her body. The problem is that inspiration-based dressing is fundamentally broken. You can't replicate someone else's outfit on your body and your life. You need formulas that were built for the way you actually dress.

---

### Stage 3 — The Shopping Guilt
**What it does:** Surfaces the guilt cycle of buying things that don't work, and connects it to a financial cost she hasn't done the math on.

**Why it works for this blend specifically:**

The Closet Paralytic shops from hope. She buys a blouse because it's beautiful and she imagines wearing it with something that turns out not to exist in her closet. The Scroll Comparer shops from reference. She tries to buy "the thing she saw on Instagram" and it's never quite right in person.

Both end up with a closet full of things that don't go together and a quiet sense that they wasted money. The stat — "the average woman has $2,000 in unworn clothes" — lands like a gut punch when it follows a series of questions about her own shopping habit.

---

### Stage 4 — The Reframe: You Don't Need More Inspiration
**What it does:** Explicitly repudiates the content-consumption approach and positions formula-based dressing as the alternative.

**Why it works for this blend specifically:**

For the Scroll Comparer, this is the most important moment in the funnel. She has been told, implicitly, by every Instagram account she follows that more content = better style. This funnel tells her the opposite: you don't need more inspiration. You need formulas that work on YOUR body.

For the Closet Paralytic, the equivalent reframe is: you don't have a wardrobe problem. You have a visibility problem. The outfits are there. You just can't see them without the formulas.

---

### Stage 5 — The Closet Makeover Score
**What it does:** Quantifies the opportunity in her existing wardrobe. Shows her how much potential she's been sitting on.

**Why it works for this blend specifically:**

The "Closet Makeover Score" is the quiz's conversion mechanic. A number that represents how many outfit combinations she doesn't know she has. This number is always higher than expected — which creates immediate urgency: "I have all these outfits I can't see?"

The name capture for the personalized promo code feeds directly into the Sofa Yoga paywall. By this point, she's invested 8–10 minutes in the quiz. The promo code makes it feel like she earned something specific. The countdown timer says: this deal is for right now, for you, for this moment.

---

## The Central Conversion Mechanism

By the time the paywall appears, she has:
1. Named the specific shape of her closet problem (Stage 1)
2. Admitted how much content she's consumed without results (Stage 2)
3. Confronted the financial cost of a closet that doesn't work (Stage 3)
4. Heard the reframe that repositions formulas over inspiration (Stage 4)
5. Seen her own Closet Makeover Score with its potential (Stage 5)

The Sofa Yoga architecture closes because:
- The personalized code makes her feel this deal was reserved for her
- The bonus stack adds $56.96 in perceived value at zero cost
- The countdown says "this specific offer goes away"
- The math becomes irrational NOT to act

---

# THE COMPLETE 30-SCREEN FUNNEL

---

## SCREEN 1: Start (Entry Node)
- **Kind:** Start — invisible entry node
- **Notes:** Automatically transitions to Screen 2. No visible content. Platform handles routing.

---

## SCREEN 2: Landing / Entry

- **Kind:** Step — Landing page, no question
- **Progress bar:** None

---

**VISUAL ELEMENTS:**

- **Top badge (pill, #FF2A6D border, pink text):**
  > CLOSET MAKEOVER QUIZ

- **Headline (36–40px, bold, #1E1E1E):**
  > **You have a closet full of clothes.**
  > **So why is there nothing to wear?**

- **Subheadline (18px, #6B6B6B):**
  > Answer 5 minutes of questions and we'll calculate your Closet Makeover Score — how many outfits are hiding in your wardrobe right now. Then we'll show you how to wear them.

- **Social proof badge:**
  > ⭐⭐⭐⭐⭐ 147,000+ women have found outfits they didn't know they had

- **CTA Button (full-width, #FF2A6D, white text, bold, 12px radius):**
  > Calculate My Score →

- **Trust line (small, #6B6B6B):**
  > Free · 5 minutes · No shopping required

---

**Design notes:**
- Background: soft cream (#FFF8F5)
- The headline is the Closet Paralytic's exact internal monologue. Reading it feels like being caught.
- "Outfits hiding in your wardrobe right now" — the promise is specific and activating
- "No shopping required" — addresses the Scroll Comparer's fear that this will just push her to buy more stuff she can't use

---

## SCREEN 3: Age

- **Kind:** Step
- **Progress bar:** ~4%

---

**Title (28px, bold):**
> How old are you?

**Subtitle (16px, #6B6B6B):**
> This shapes which formulas we match you with.

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- Under 30
- 30–39
- 40–49
- 50–59
- 60+

---

## SCREEN 4: The Closet Reality Check

- **Kind:** Step
- **Progress bar:** ~8%

---

**Title (28px, bold):**
> How would you describe your closet situation?

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- Stuffed. And I still feel like I have nothing to wear.
- Decent amount of stuff, but I wear the same 5–6 things on rotation
- I own a lot and genuinely don't know what half of it goes with
- I've cleared it out but still struggle with outfit ideas
- It's manageable but mornings are still hard

---

**Design notes:**
- Every option is a different version of the same underlying problem
- Option 1 ("Stuffed. And I still feel like I have nothing to wear.") is the Closet Paralytic's defining statement — clicking it feels cathartic

---

## SCREEN 5: The Morning Routine

- **Kind:** Step
- **Progress bar:** ~12%

---

**Title (28px, bold):**
> Walk me through a typical getting-dressed morning.

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- I try on several things, hate them all, and go back to what I always wear
- I know what I'm wearing before I even open the closet — the same things
- I spend way too long and still leave feeling like something's off
- I've streamlined it by just... giving up on looking interesting
- It depends on the day, but it's rarely easy

---

**Design notes:**
- "I've streamlined it by just giving up on looking interesting" — this one lands like a gut-punch. The resignation is real.
- "Feeling like something's off" — the Scroll Comparer's morning state: she's assembled an outfit but it doesn't look like the reference image she had in her head

---

## SCREEN 6: The Pinterest/Instagram Question

- **Kind:** Step
- **Progress bar:** ~16%

---

**Title (28px, bold):**
> How much style content do you consume? Pinterest, Instagram, TikTok...

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- A lot. I've saved hundreds of pins and posts.
- Some — I follow a few accounts and take note of things I like
- I used to a lot, but I've mostly stopped — it made me feel worse
- Not really my thing
- Occasionally, when I'm looking for a specific event or occasion

---

**Design notes:**
- Option 3 ("I used to a lot, but I've mostly stopped — it made me feel worse") — this is the advanced Scroll Comparer who's already figured out the inspiration-reality gap. She needs validation.
- Option 1 is the entry point for the full Scroll Comparer experience

---

## SCREEN 7: The Saved-But-Never-Worn

- **Kind:** Step
- **Progress bar:** ~20%

---

**Title (28px, bold):**
> When you save an outfit idea, what usually happens next?

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- I try to recreate it and it never looks the same on me
- I buy something to try and make it work — and it doesn't
- I save it and never try — it feels out of reach somehow
- I occasionally pull it off, but it's inconsistent
- I don't really save outfit ideas

---

**Design notes:**
- Option 1 is the Scroll Comparer's defining frustration: "it never looks the same on me"
- Option 2 surfaces the shopping spiral that feeds the overstuffed closet
- These answers connect the content-consumption habit directly to the closet problem

---

## SCREEN 8: Social Proof Interstitial — The 847 Pins Problem

- **Kind:** Interstitial — info screen (no question)
- **Progress bar:** ~24%

---

**Background:** Warm cream (#FFF8F5)
**Card (white, soft shadow, 16px radius):**

**Headline (24px, bold, #1E1E1E):**
> You don't need more inspiration.

**Body copy (18px, #1E1E1E):**
> The average Outfit Formulas member had saved **200+ pins** before she found us.
>
> She wasn't missing inspiration. She was missing **formulas**.
>
> Inspiration tells you what looks good on someone else's body, in someone else's life. Formulas tell you what works on **yours**.

**Divider**

**Smaller stat (#FF2A6D, bold, 24px):**
> 50+

**Stat copy (16px, #6B6B6B):**
> That's the average number of outfits hiding in a woman's wardrobe right now.

**CTA Button:**
> Keep Going →

---

**Design notes:**
- This interstitial is the conceptual pivot from inspiration-model to formula-model
- The stat "50+ hidden outfits" primes her for the Closet Makeover Score result
- No product sell yet. This is still pure education / reframe.

---

## SCREEN 9: The Shopping Habit

- **Kind:** Step
- **Progress bar:** ~27%

---

**Title (28px, bold):**
> How often do you buy new clothes?

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- Pretty regularly — I love shopping but feel guilty about it
- Only when I desperately need something
- I browse a lot but don't buy much anymore
- I've stopped shopping because nothing ever works anyway
- A few times a year, deliberately

---

**Design notes:**
- "I love shopping but feel guilty about it" — the Closet Paralytic's specific guilt: she keeps adding things that don't solve the problem
- "I've stopped shopping because nothing ever works anyway" — resignation state; she's lost faith in the shopping process

---

## SCREEN 10: Shopping Outcome

- **Kind:** Step
- **Progress bar:** ~30%

---

**Title (28px, bold):**
> When you buy something new, what usually happens to it?

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- I wear it a few times and then it disappears into the rotation I never touch
- It sits unworn because I can't figure out what to pair it with
- I love it in the store and feel something's wrong when I get home
- I buy things that are "safe" but feel boring in them
- I'm pretty selective — what I buy usually gets worn

---

**Design notes:**
- "I can't figure out what to pair it with" — this is the formula gap, named in her words
- "Something's wrong when I get home" — the context shift: what works on the mannequin doesn't work in her actual life

---

## SCREEN 11: The Financial Reality Check

- **Kind:** Interstitial — info screen (no question)
- **Progress bar:** ~33%

---

**Background:** Deep charcoal (#1E1E1E)
**Text:** White / cream

**Headline (28px, bold, white):**
> The average woman has **$2,000**
> in clothes she never wears.

**Body copy (18px, #FFF8F5):**
> Not because she made bad choices.
>
> Because she was shopping without formulas.
>
> When you don't have a system for what works with what, every new thing is a gamble. And most gambles lose.

**Pink accent line (#FF2A6D, 20px, bold):**
> You're not a bad shopper. You're an unsupported one.

**CTA Button (#FF2A6D, white text):**
> That's About To Change →

---

**Design notes:**
- Dark background marks the emotional weight of this screen — this is a real financial cost
- "Unsupported" — reframe. Not broken. Not bad at this. Just without a system.
- The stat is from the established key statistics in the context file and hits hard after her answers about unworn clothes

---

## SCREEN 12: Multi-Select — Morning Frustrations

- **Kind:** Step — multi-select
- **Progress bar:** ~36%

---

**Title (24px, bold):**
> What does a hard morning actually look like for you?

**Subtitle (16px, #6B6B6B):**
> Check everything that happens.

---

**Question Type:** Multi-select, checkboxes, "Continue" button

**Answer Options:**
- I try on five things and hate them all
- I end up wearing the same thing I wore two days ago
- I feel good about the outfit leaving the house, then regret it by 10am
- Nothing in my closet seems to go together
- I know I have "good stuff" but I can't see how to wear it
- I scroll through my wardrobe app (or closet) looking for something obvious
- I give up and just put on whatever requires the fewest decisions
- I'm late because I can't commit

---

**Design notes:**
- "Nothing goes together" — the core Closet Paralytic feeling in four words
- Multi-select compounds the weight: every box checked is another dimension of the problem
- "Give up and put on whatever requires the fewest decisions" — this is resignation without bitterness. It's just exhausted.

---

## SCREEN 13: The Likert Battery (1)

- **Kind:** Step — Likert 5-point scale
- **Progress bar:** ~39%

---

**Title (24px, bold):**
> "I own things I love but I never wear because I can't figure out what they go with."

**Scale:** Strongly Disagree / Disagree / Neutral / Agree / Strongly Agree

---

## SCREEN 14: The Likert Battery (2)

- **Kind:** Step — Likert 5-point scale
- **Progress bar:** ~42%

---

**Title (24px, bold):**
> "I could look at beautiful outfit content for hours and still feel stuck when I open my own closet."

**Scale:** Strongly Disagree / Disagree / Neutral / Agree / Strongly Agree

**Design notes:**
- This is the Scroll Comparer's defining sentence. She's lived this. Clicking "Strongly Agree" feels like relief — someone else sees it.

---

## SCREEN 15: The Likert Battery (3)

- **Kind:** Step — Likert 5-point scale
- **Progress bar:** ~45%

---

**Title (24px, bold):**
> "I've bought things specifically because I thought they'd 'finally fix' my wardrobe — and they didn't."

**Scale:** Strongly Disagree / Disagree / Neutral / Agree / Strongly Agree

**Design notes:**
- The "magic piece" fallacy — the belief that one new thing will make everything work. It never does without a formula.

---

## SCREEN 16: The Likert Battery (4)

- **Kind:** Step — Likert 5-point scale
- **Progress bar:** ~48%

---

**Title (24px, bold):**
> "My closet makes me feel worse about myself than if I just had fewer, better options."

**Scale:** Strongly Disagree / Disagree / Neutral / Agree / Strongly Agree

**Design notes:**
- The cruel paradox of the overstuffed closet: more options = more paralysis = more shame
- "Fewer, better options" is the intuition she has without the system to execute it

---

## SCREEN 17: Event Avoidance

- **Kind:** Step
- **Progress bar:** ~51%

---

**Title (28px, bold):**
> Have you ever made an excuse not to go somewhere because you didn't know what you'd wear?

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- Yes — multiple times
- Yes — once or twice
- I've considered it but talked myself into going
- No, I just accept feeling "not quite right" and go anyway
- Not really

---

**Design notes:**
- This surfaces the real-world cost: her social life is being contracted by the closet problem
- Events avoided = connections not made. The stakes rise.

---

## SCREEN 18: The Body-Formulas Question

- **Kind:** Step
- **Progress bar:** ~54%

---

**Title (28px, bold):**
> When you see a great outfit on Instagram, what gets in the way of wearing something similar?

---

**Question Type:** Multi-select, "Continue" button

**Answer Options:**
- It looks different on my body than it does on the person wearing it
- I don't have the exact pieces they're wearing
- I'm not sure how to adapt it to my actual life
- I can recreate the pieces but somehow the overall look is off
- I try it and it works — I'm good at this
- I don't really try to recreate outfit ideas

---

**Design notes:**
- "Looks different on my body" — the Scroll Comparer's most painful realisation, named explicitly
- "I can recreate the pieces but somehow the overall look is off" — formula gap: she has the ingredients but not the method
- Selecting multiple options = naming the compound frustration

---

## SCREEN 19: Reframe Interstitial — The Formula Key

- **Kind:** Interstitial — info screen (no question)
- **Progress bar:** ~57%

---

**Background:** #FF2A6D (vibrant pink)
**Text:** White

**Headline (28px, bold, white):**
> You don't need more inspiration.
> You need formulas that work on YOUR body.

**Body copy (18px, white, slightly transparent):**
> The reason those outfits don't translate isn't your body.
>
> It's that every outfit that works has a formula underneath it.
> A specific combination of proportions, colours, and anchors
> that makes the pieces speak to each other.
>
> Once you know YOUR formulas — the ones built around your shape,
> your wardrobe, your life — getting dressed changes completely.
>
> Not "today I look okay." More like: "oh, this is what I've been missing."

**CTA Button (white background, #FF2A6D text):**
> Build My Formula →

---

**Design notes:**
- Pink background = the pivot moment, same as Funnel E
- This is the most important copy in the funnel for the Scroll Comparer
- No product mention. This is an idea, not a pitch.

---

## SCREEN 20: Life Context

- **Kind:** Step
- **Progress bar:** ~60%

---

**Title (28px, bold):**
> What does most of your week actually look like?

**Subtitle (16px, #6B6B6B):**
> This helps us match formulas to your real life, not an imaginary one.

---

**Question Type:** Multi-select, "Continue" button

**Answer Options:**
- Working from home
- In an office or workplace
- Always on the go — errands, school runs, appointments
- A mix — varies week to week
- Lots of social stuff — dinners, events, weekends out
- Mostly home right now

---

## SCREEN 21: Wardrobe Inventory

- **Kind:** Step
- **Progress bar:** ~63%

---

**Title (28px, bold):**
> Roughly how many items of clothing do you own that you actually wear?

**Subtitle (16px, #6B6B6B):**
> Not total items. Just the ones you actually reach for.

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- Fewer than 10 things, honestly
- 10–20 go-tos
- 20–30 pieces I rotate through
- More than 30 pieces I wear regularly
- I genuinely have no idea

---

**Design notes:**
- The distinction "that you actually wear" forces her to acknowledge the gap between total wardrobe and active wardrobe
- "I genuinely have no idea" is common — and telling

---

## SCREEN 22: The 20% Stat Interstitial

- **Kind:** Interstitial — info screen (no question)
- **Progress bar:** ~66%

---

**Background:** Warm cream (#FFF8F5)
**Card (white, soft shadow):**

**Stat (bold, #FF2A6D, 36px):**
> 20%

**Copy (18px, #1E1E1E):**
> That's what the average woman wears of her wardrobe.

**Smaller copy (16px, #6B6B6B):**
> The other 80%? Unworn. Unseen. Unloved.
>
> Most of it isn't unwearable. It just doesn't have a formula to go with it.
>
> We're about to calculate how many outfits are hiding in yours.

**CTA Button:**
> Calculate My Score →

---

## SCREEN 23: Colour Awareness

- **Kind:** Step
- **Progress bar:** ~69%

---

**Title (28px, bold):**
> How confident are you with colour combinations?

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- Not at all — I stick to black and navy because it's safe
- Some basic combinations I know work, but I don't go further
- I love colour but I can't make my colour purchases connect
- Pretty confident — colour is actually a strength
- I've saved colour combination ideas but can never execute them

---

**Design notes:**
- Option 5 is the Scroll Comparer's colour version: saved ideas, no execution
- The Color Combinations Cheat Sheet in the bonus stack directly solves this pain point

---

## SCREEN 24: The Goal Statement

- **Kind:** Step
- **Progress bar:** ~72%

---

**Title (28px, bold):**
> What would "finally having this sorted" actually mean for you?

**Subtitle (16px, #6B6B6B):**
> Not the fashion version. The real version.

---

**Question Type:** Single-choice, list layout, auto-advance on click

**Answer Options:**
- Getting out the door in 5 minutes and feeling genuinely good
- Knowing my wardrobe actually works — not just hoping
- Stopping the Sunday-night dread about what I'll wear Monday
- Actually wearing the things I love, not saving them
- Looking like someone who has her act together, without it taking an hour

---

**Design notes:**
- "The real version" — not aspirational fashion goals. Functional life improvement.
- "Sunday-night dread" is a specific emotional reference point many women recognize
- "Someone who has her act together" — this is her actual aspiration. Identity.

---

## SCREEN 25: Name Capture

- **Kind:** Step — text input
- **Progress bar:** ~80%

---

**Title (28px, bold):**
> Almost done — what's your name?

**Subtitle (16px, #6B6B6B):**
> We're generating your Closet Makeover Score and a personalised promo code. We need your name for both.

---

**Input field:**
> First name

**CTA Button:**
> Calculate My Score →

**Design notes:**
- The "personalised promo code" mention here seeds the paywall mechanic — she knows something is coming for her specifically
- This is the key data point for the Sofa Yoga paywall: {{firstName}} populates the promo code

---

## SCREEN 26: Email Capture

- **Kind:** Step — email input
- **Progress bar:** ~84%

---

**Title (28px, bold):**
> Where should we send your Closet Makeover Score?

**Subtitle (16px, #6B6B6B):**
> We'll email you your full results — including the formulas hiding in your wardrobe right now.

---

**Input field:**
> Your email address

**CTA Button:**
> Send My Results →

**Trust line (small, #6B6B6B):**
> No spam. Unsubscribe anytime. We never sell your data.

---

## SCREEN 27: Email Consent

- **Kind:** Step — consent/GDPR screen
- **Progress bar:** ~86%

---

**Title (24px, bold):**
> One quick thing, {{firstName}}

**Copy (16px, #1E1E1E):**
> By continuing, you agree to receive your Closet Makeover Score and personalised outfit formula recommendations from Outfit Formulas. You can unsubscribe at any time.

**Checkbox (pre-checked, user can uncheck):**
> I agree to receive my results and occasional style tips by email.

**CTA Button:**
> Show My Score →

**Legal line (12px, #6B6B6B):**
> By continuing, you accept our Terms of Use and Privacy Policy.

---

## SCREEN 28: Loading / Score Build Screen

- **Kind:** Interstitial — animated loading screen
- **Progress bar:** ~91%

---

**Background:** Warm cream (#FFF8F5)

**Headline (24px, bold, #1E1E1E):**
> Calculating your Closet Makeover Score, {{firstName}}...

**Animated circular score reveal (pink arc, #FF2A6D):**
> Score animating from 0 → final number (68/100 example)

**Rotating copy beneath bar (fades in/out):**
> "Counting your unworn outfit combinations..."
> "Identifying your formula gaps..."
> "Matching your wardrobe to proven formulas..."
> "Calculating your hidden outfit potential..."
> "Generating your personalised promo code..."

**Final reveal line (bold, #FF2A6D):**
> Your personalised code is ready, {{firstName}}.

**Social proof strip (scrolls below):**
> ⭐⭐⭐⭐⭐ *"I had 47 outfits in my wardrobe I hadn't figured out. In three weeks I'd worn most of them."* — Louise B., 39
>
> ⭐⭐⭐⭐⭐ *"I've saved so many Pinterest boards. Nothing ever worked. These formulas are the actual missing piece."* — Joanna K., 42
>
> ⭐⭐⭐⭐⭐ *"Getting dressed used to take 40 minutes of trying things on. Now it's 5 minutes and I actually like what I'm wearing."* — Rachel T., 37

---

**Design notes:**
- The "generating your personalised promo code" line in the loading sequence builds anticipation for the paywall
- Testimonials written in both Closet Paralytic and Scroll Comparer voice
- The score reveal is the emotional hook: "my closet makeover score is 68/100" — meaning 32 points of untapped potential

---

## SCREEN 29: Results Screen — Closet Makeover Score

- **Kind:** Custom HTML results screen (transitions into paywall on same page)
- **Progress bar:** 100%

---

**Background:** Warm cream (#FFF8F5)

**Pre-headline (small caps, #FF2A6D, 14px):**
> YOUR CLOSET MAKEOVER SCORE, {{firstName}}

**Score display (large, circular, #FF2A6D):**
> **68 / 100**

**Score interpretation (20px, bold, #1E1E1E):**
> High Potential — Most Of Your Wardrobe Is Untapped

**Score explanation (16px, #6B6B6B):**
> Based on your answers, you have a wardrobe with significant hidden outfit potential. The formulas to unlock those combinations are specific to how you dress, what you already own, and what your life actually looks like.
>
> You don't need to shop. You need a system.

**Gap analysis (card, white background, soft shadow):**

> **What's holding your score back:**
> - No clear formula framework for combining pieces ✗
> - Colour combinations not mapped to your specific palette ✗
> - Morning routine has no anchor formula ✗
> - High-potential pieces isolated without pairing context ✗
>
> **What's working:**
> - You already own the pieces ✓
> - Your wardrobe has variety — the raw material is there ✓
> - You know what you like — you just can't execute it yet ✓

---

**Design notes:**
- The gap analysis mirrors her quiz answers back — it feels specific, not generic
- "You don't need to shop. You need a system." — the core OF promise, stated plainly
- The results screen flows directly into the paywall below (no separate screen)

---

## SCREEN 30: PAYWALL — SOFA YOGA MODEL
### Countdown Timer + Personalized Promo Code + Free Bonus Stack

- **Kind:** Custom HTML paywall screen (continues below results, cream background with pink/dark accents)
- **Paywall Architecture:** SOFA YOGA — Triple urgency (countdown timer + personalized promo code + free bonus stack)
- **Checkout URL:** `https://app.outfitformulas.com/checkout/closet-makeover`

---

### STICKY URGENCY HEADER (pinned to top of viewport, #FF2A6D background, white text)

```
⏱ Price reserved for: [14:53]   |   Your code: {{firstName}}_STYLE   |   Offer expires when timer hits zero
```

- Countdown ticks in real time (MM:SS format)
- Resets on page refresh — intentional FOMO design
- #FF2A6D background, white bold text, centered

---

### HEADLINE SECTION

**Pre-headline (small caps, #FF2A6D, 14px):**
> YOUR CLOSET MAKEOVER PLAN IS READY

**Main Headline (36px, bold, #1E1E1E):**
> **{{firstName}}, your code is reserved.**
> **Here's what's waiting in your closet.**

**Sub-headline (18px, #6B6B6B):**
> 147,000+ women have found outfits they didn't know they had. Your Closet Makeover Score says you have serious potential. These formulas are how you unlock it.

---

### PERSONALIZED PROMO CODE BLOCK

**Styled card (white background, #FF2A6D border, subtle glow):**

```
🎁 YOUR EXCLUSIVE DISCOUNT CODE

┌──────────────────────────────────┐
│         {{firstName}}_STYLE      │
│   [Copy Code]        ✓ Applied   │
└──────────────────────────────────┘

Generated for your quiz profile.
Expires when your timer hits 00:00.
```

- Code auto-applies at checkout — user sees "Discount Applied ✓"
- Monospace font for code, glowing border, subtle pulse animation
- The personalized code makes this feel like a SPECIAL deal reserved for her specifically, not a generic promo

---

### PLAN SELECTOR (interactive cards, Annual pre-selected)

**Section header:** "Choose your plan — your code is already applied:"

---

**PLAN CARD 1 — Annual Plan** *(default selected, #FF2A6D border glow, bold BEST VALUE badge)*

```
┌──────────────────────────────────────────────────┐
│  🏆 BEST VALUE — SAVE 60%                         │
│                                                   │
│  Annual Plan                                      │
│  ~~$49.99~~ → $19.99 / year                       │
│  Just $0.05/day                                   │
│  Less than a cup of tea.                          │
│                                                   │
│  ✓ Full access, all formulas, 12 months          │
│  ✓ Includes ALL free bonuses below               │
│  ✓ Cancel anytime                                │
└──────────────────────────────────────────────────┘
```

---

**PLAN CARD 2 — Monthly Plan** *(unselected)*

```
┌──────────────────────────────────────────────────┐
│  ⭐ MOST POPULAR                                  │
│                                                   │
│  Monthly Plan                                     │
│  ~~$9.99~~ → $7.99 / month                        │
│  Just $0.27/day                                   │
│                                                   │
│  ✓ Full access, billed monthly                   │
│  ✓ Cancel anytime                                │
└──────────────────────────────────────────────────┘
```

---

### PRIMARY CTA BUTTON (large, full-width, #FF2A6D, white bold text)

```
[ Unlock My Closet Makeover with {{firstName}}_STYLE → ]
```

*Sub-copy beneath button:* "Your code is applied. Secure checkout. Access your formulas immediately."

---

### FREE BONUS STACK

**Section header (bold, #1E1E1E, 24px):**
> 🎁 {{firstName}}, you also get **$56.96 in FREE gifts** — included with your plan today:

**Individual bonus items:**

---

**BONUS 1**
> 📄 **"The 10 Outfits Hiding in Every Closet" Guide**
> *The 10 most universally hidden outfit combinations — and how to find yours. Works with what you already own.*
> ~~$14.99~~ **FREE**

---

**BONUS 2**
> 🎨 **"Color Combinations Cheat Sheet"**
> *The combinations that always work — mapped to real wardrobes, not mood boards. Stop guessing with colour.*
> ~~$19.99~~ **FREE**

---

**BONUS 3**
> ⏰ **"5-Minute Morning Formula" Printable**
> *One formula. Every morning. Stick it on your mirror. Never stand there for 30 minutes again.*
> ~~$9.99~~ **FREE**

---

**BONUS 4**
> 🗂 **"The 'What to Wear to...' Decision Tree"**
> *Wedding? Dinner? Work event? School run? A simple decision tree that tells you exactly what to wear for every occasion.*
> ~~$12.99~~ **FREE**

---

**Bonus total line (bold, #FF2A6D, 20px):**
```
Total bonus value: ~~$56.96~~  →  FREE with your plan today
```

---

### SECONDARY CTA (repeated)

```
[ Claim My Closet Makeover + FREE Bonuses → ]
```

---

### SECURITY & TRUST BADGES

**Badge row (horizontal, center-aligned):**

```
[🔒 Norton Secured]  [✓ McAfee SECURE]  [SSL Encrypted]  [🛡️ 30-Day Guarantee]
```

- Norton and McAfee badge graphics (standard web trust badge assets)
- "SSL Encrypted Checkout" with padlock icon
- "30-Day Money-Back Guarantee" with shield icon

---

### SOCIAL PROOF — CLOSET PARALYTIC + SCROLL COMPARER VOICES

**Three testimonials (stacked cards):**

> ⭐⭐⭐⭐⭐
> *"I had an overstuffed closet and genuinely nothing to wear. I know how that sounds. But I'd open it, go blank, and reach for the same jeans and the same top. After two weeks with Outfit Formulas I found 23 combinations I'd never thought of. From stuff I already owned."*
> — **Gemma R.**, 38, Leeds

> ⭐⭐⭐⭐⭐
> *"I had 847 Pinterest pins. Not an exaggeration. And I'd try on things that looked exactly like my pins and something would always be wrong. The formulas fixed this in a way no amount of scrolling ever did. Now I barely use Pinterest."*
> — **Natalie W.**, 41, Bristol

> ⭐⭐⭐⭐⭐
> *"Sunday nights I used to dread Monday morning because I had no idea what I was going to wear. I know that sounds small but it was genuinely affecting my mood. This fixed it. I feel like I finally have a system."*
> — **Amanda S.**, 36, Birmingham

---

### 30-DAY MONEY-BACK GUARANTEE

**Guarantee block (white card, #FF2A6D left border, center-aligned):**

```
🛡️ 30-DAY MONEY-BACK GUARANTEE

Try Outfit Formulas for 30 days.
If you haven't found outfits you didn't know you had,
we'll give you every penny back. No questions.

You have nothing to lose. Except the morning
where nothing goes together.
```

---

### STICKY COUNTDOWN FOOTER (visible while scrolling, always at bottom of viewport)

```
⏱ {{firstName}}_STYLE expires in [14:53]   [ Claim My Closet Makeover → ]
```

- Full-width sticky bar at bottom
- #FF2A6D background, white text, bold CTA button
- Countdown synced with header timer
- CTA scrolls to plan selector or triggers checkout

---

**Design notes for Screen 30:**
- The sticky header AND sticky footer mean urgency is ALWAYS visible — at the top when she first arrives, at the bottom while she scrolls
- The personalized code ({{firstName}}_STYLE) is the emotional anchor — she feels this deal was generated for her, not blasted to a list
- Bonus stack math: $56.96 in perceived free value against a $19.99/year price = irrational not to act
- Annual plan default-selected because the math ($0.05/day) is the most powerful price anchor
- The Color Combinations Cheat Sheet directly addresses her specific stated pain (Screens 23) — the bonus stack should feel like it read her answers
- "The 'What to Wear to...' Decision Tree" solves event avoidance (Screen 17) — again, it should feel like the bonus was built for her quiz specifically
- Testimonials are written explicitly in the voices of both archetypes: the Closet Paralytic (Gemma, Amanda) and the Scroll Comparer (Natalie — 847 pins is a direct echo of the context file language)
- Visual flow: results (score reveal) → promo code block → plan selector → CTA → bonuses → trust → testimonials → guarantee → sticky footer

---

# SUMMARY OF SCREEN TYPES — FUNNEL F

| Type | Count | Screens |
|------|-------|---------|
| Single-choice list | 8 | 3, 4, 5, 6, 7, 9, 10, 21, 23, 24 |
| Multi-select list | 3 | 12, 18, 20 |
| Single-choice grid (Likert 5-point) | 4 | 13, 14, 15, 16 |
| Text input (Name) | 1 | 25 |
| Text input (Email) | 1 | 26 |
| Consent screen | 1 | 27 |
| Interstitials (no question) | 4 | 8, 11, 19, 22 |
| Loading/Results screen | 2 | 28, 29 |
| Paywall (custom HTML) | 1 | 30 |
| Landing screen | 1 | 2 |
| Start node | 1 | 1 |

**Total: 30 screens** ✅

---

# KEY THEMES ASSESSED — FUNNEL F

1. **Demographics** — Screen 3
2. **Closet Reality** (Closet situation, morning routine) — Screens 4, 5
3. **Content Consumption** (Pinterest/Instagram habits, save-but-never-wear) — Screens 6, 7
4. **Shopping Patterns** (Shopping frequency, outcome) — Screens 9, 10
5. **Morning Frustrations** (Multi-select) — Screen 12
6. **Self-Diagnosis Confirmation** (4 Likert statements) — Screens 13–16
7. **Real-World Cost** (Event avoidance, body-formula gap) — Screens 17, 18
8. **Life Context** (Daily life context) — Screen 20
9. **Wardrobe Data** (Active wardrobe size, colour confidence) — Screens 21, 23
10. **Goal Statement** — Screen 24

---

# COPY RULES — FUNNEL F

1. **Use her words verbatim** — "nothing goes together," "I've saved 847 Pinterest pins," "frumpy"
2. **Validate the scroll habit before repudiating it** — she's not stupid for trying Pinterest. It's just the wrong tool.
3. **Never tell her to shop** — the entire funnel is built on "you already have what you need"
4. **The promo code is personal** — every reference to it ("your code," "reserved for you") reinforces that this isn't a generic deal
5. **Bonus stack copy should echo her quiz answers** — the cheat sheet solves her colour problem, the decision tree solves her event avoidance
6. **Countdown is always visible** — both sticky header and sticky footer. The timer is the funnel's skeleton.
7. **Identity language** — "feel like someone who has her act together" not "look stylish"
8. **$0.05/day framing** — the annual plan price anchor. Make the math impossible to argue with.

---

*End of Outfit Formulas Funnels E & F. Total: 28 screens (Funnel E) + 30 screens (Funnel F) = 58 screens across both funnels.*
